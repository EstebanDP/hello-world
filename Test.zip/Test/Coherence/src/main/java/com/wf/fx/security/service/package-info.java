@javax.xml.bind.annotation.XmlSchema(namespace = "http://service.security.fx.wf.com/")
package com.wf.fx.security.service;
