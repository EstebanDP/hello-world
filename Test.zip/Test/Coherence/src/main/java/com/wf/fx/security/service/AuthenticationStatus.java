
package com.wf.fx.security.service;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for authenticationStatus.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="authenticationStatus">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="FAILURE"/>
 *     &lt;enumeration value="SUCCESS"/>
 *     &lt;enumeration value="USER_NOT_FOUND"/>
 *     &lt;enumeration value="PASSWORD_INVALID"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "authenticationStatus")
@XmlEnum
public enum AuthenticationStatus {

    FAILURE,
    SUCCESS,
    USER_NOT_FOUND,
    PASSWORD_INVALID;

    public String value() {
        return name();
    }

    public static AuthenticationStatus fromValue(String v) {
        return valueOf(v);
    }

}
