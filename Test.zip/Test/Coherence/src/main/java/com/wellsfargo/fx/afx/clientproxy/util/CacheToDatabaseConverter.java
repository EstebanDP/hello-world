package com.wellsfargo.fx.afx.clientproxy.util;

import java.util.ArrayList;
import java.util.List;

import com.wellsfargo.fx.afx.common.persistence.model.Configuration;
import com.wellsfargo.fx.afx.common.persistence.model.CurrencyPair;
import com.wellsfargo.fx.afx.common.persistence.model.CurrencyPairThresholdsConfig;
import com.wellsfargo.fx.afx.common.persistence.model.Strategy;

public class CacheToDatabaseConverter {
	
	public static Strategy convert(com.wellsfargo.fx.afx.common.valueobject.coherence.ThresholdStrategy coherenceThresholdStrategy) {
		Strategy strategy = new Strategy();
		strategy.setStrategyName(coherenceThresholdStrategy.getStrategyName().trim());
		strategy.setUpdateUser(coherenceThresholdStrategy.getUpdateUser().trim());
		strategy.setDeletable(coherenceThresholdStrategy.isDeletable());
		strategy.setUpdateDate(coherenceThresholdStrategy.getUpdateDate());
		strategy.setNotes(coherenceThresholdStrategy.getNotes().trim());
		
		List<CurrencyPairThresholdsConfig> currencyPairThresholdsConfigList = new ArrayList<CurrencyPairThresholdsConfig>();
		
		for (com.wellsfargo.fx.afx.common.valueobject.coherence.CurrencyPairThresholdsConfig coherenceCurrencyPairThresholdsConfig 
				: coherenceThresholdStrategy.getCcyPairThresholdsConfig()) {
			CurrencyPairThresholdsConfig currencyPairThresholdsConfig = new CurrencyPairThresholdsConfig();
			currencyPairThresholdsConfig.setStrategyName(coherenceThresholdStrategy.getStrategyName().trim());
			currencyPairThresholdsConfig.setEnabled(coherenceCurrencyPairThresholdsConfig.isEnabled());
			currencyPairThresholdsConfig.setUpdatedByUser(coherenceCurrencyPairThresholdsConfig.getUserName().trim());
			currencyPairThresholdsConfig.setCurrencyPair(coherenceCurrencyPairThresholdsConfig.getCurrencyPair().trim());
			currencyPairThresholdsConfig.setShortThreshold(coherenceCurrencyPairThresholdsConfig.getShortThreshold());
			currencyPairThresholdsConfig.setLongThreshold(coherenceCurrencyPairThresholdsConfig.getLongThreshold());
			currencyPairThresholdsConfig.setUpdated(coherenceCurrencyPairThresholdsConfig.isUpdated());
	
			currencyPairThresholdsConfigList.add(currencyPairThresholdsConfig);
		}
		
		strategy.setCcyPairThresholdsConfig(currencyPairThresholdsConfigList);
		return strategy;
	}

	public static Configuration convert(com.wellsfargo.fx.afx.common.valueobject.coherence.Configuration coherenceConfiguration) {
		Configuration configuration = new Configuration();
		configuration.setConfigName(coherenceConfiguration.getConfigurationName());
		configuration.setConfigType(coherenceConfiguration.getConfigType());
		configuration.setConfigValue(coherenceConfiguration.getConfigurationValue());
		configuration.setUpdateUser(coherenceConfiguration.getUserName());
		configuration.setUpdateDate(coherenceConfiguration.getUpdateDate());
		
		return configuration;
	}

	public static CurrencyPair convert(com.wellsfargo.fx.afx.common.valueobject.coherence.CurrencyPair coherenceCurrencyPair) {
		CurrencyPair currencyPair = new CurrencyPair();
		currencyPair.setCcy1(coherenceCurrencyPair.getFirstCurrency().getName());
		currencyPair.setCcy2(coherenceCurrencyPair.getSecondCurrency().getName());
		currencyPair.setPrecision(coherenceCurrencyPair.getScale());
		currencyPair.setEnabled(coherenceCurrencyPair.isEnabled());
		currencyPair.setUpdateUser(coherenceCurrencyPair.getUpdateUser());
		currencyPair.setUpdateDate(coherenceCurrencyPair.getUpdateDate());

		return currencyPair;
	}
}
