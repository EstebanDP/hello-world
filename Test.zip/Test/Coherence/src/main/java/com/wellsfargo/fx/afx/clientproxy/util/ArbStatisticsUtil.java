package com.wellsfargo.fx.afx.clientproxy.util;

import com.wellsfargo.fx.afx.common.valueobject.OrderStatus;
import com.wellsfargo.fx.afx.common.valueobject.OrderType;
import com.wellsfargo.fx.afx.common.valueobject.coherence.CurrencyPairStatistics;
import com.wellsfargo.fx.afx.common.valueobject.coherence.StrategyStatistics;
import com.wellsfargo.fx.afx.common.valueobject.coherence.Transaction;

public class ArbStatisticsUtil {

    private static ArbStatisticsUtil self;

    private StrategyStatistics strategyStats;
    private CurrencyPairStatistics currencyPairStats;
    private boolean modified;

    static {
        self = new ArbStatisticsUtil();
    }

    private ArbStatisticsUtil() {
        strategyStats = new StrategyStatistics();
        currencyPairStats = new CurrencyPairStatistics();
    }

    public static ArbStatisticsUtil getInstance() {
        return self;
    }

    public void addTransaction(Transaction transaction) {
        if (transaction.isCompleted()) {
            synchronized (this) {
                modified = true;
                boolean filledTransaction = true;
                int strategyId = transaction.getStrategyId();

                for (Transaction.Order order : transaction.getOrders()) {
                    String currencyPair = order.getCurrencyPair();

                    if (order.getOrderType() != OrderType.INTERNAL) { // not dummy orders
                        strategyStats.incrementOrderTotal(strategyId, 1);
                        currencyPairStats.incrementOrderTotal(currencyPair, 1);
                        OrderStatus orderStatus = order.getOrderStatus();
                        if (orderStatus == OrderStatus.FILLED) {
                            strategyStats.incrementOrderFilled(strategyId, 1);
                            currencyPairStats.incrementOrderFilled(currencyPair, 1);
                        } else {
                            filledTransaction = false;
                            if (orderStatus == OrderStatus.CANCELLED) {
                                strategyStats.incrementOrderCancelled(strategyId, 1);
                                currencyPairStats.incrementOrderCancelled(currencyPair, 1);
                            } else if (orderStatus == OrderStatus.REJECTED_BECAUSE_OF_LATENCY_LIMIT) {
                                strategyStats.incrementOrderRejectedByLatency(strategyId, 1);
                                currencyPairStats.incrementOrderRejectedByLatency(currencyPair, 1);
                            } else if (orderStatus == OrderStatus.REJECTED_BECAUSE_THROUGHPUT_LIMIT_REACHED) {
                                strategyStats.incrementOrderRejectedByThroughput(strategyId, 1);
                                currencyPairStats.incrementOrderRejectedByThroughput(currencyPair, 1);
                            } else if (orderStatus == OrderStatus.REJECTED_BY_EXCHANGE) {
                                strategyStats.incrementOrderRejectedByExchange(strategyId, 1);
                                currencyPairStats.incrementOrderRejectedByExchange(currencyPair, 1);
                            } else if (orderStatus == OrderStatus.REJECTED_INTERNAL_VALIDATION) {
                                strategyStats.incrementOrderRejectedByValidation(strategyId, 1);
                                currencyPairStats.incrementOrderRejectedByValidation(currencyPair, 1);
                            }
                        }
                    }
                }

                strategyStats.incrementTransactionTotal(strategyId, 1);
                if (filledTransaction) {
                    strategyStats.incrementTransactionFilled(strategyId, 1);
                }

            }
        }
    }

    public StrategyStatistics getStrategyStatistics() {
        return strategyStats;
    }

    public CurrencyPairStatistics getCurrencyPairStatistics() {
        return currencyPairStats;
    }

    public boolean isModified() {
        return modified;
    }

    public void setModified(boolean modified) {
        this.modified = modified;
    }

}
