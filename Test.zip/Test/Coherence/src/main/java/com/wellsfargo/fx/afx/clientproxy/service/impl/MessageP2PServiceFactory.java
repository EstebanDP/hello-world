package com.wellsfargo.fx.afx.clientproxy.service.impl;

import com.wellsfargo.fx.afx.clientproxy.service.CacheService;
import com.wellsfargo.fx.afx.clientproxy.service.MessageP2PService;

public class MessageP2PServiceFactory {
	
	private static volatile MessageP2PService instance;

	public static MessageP2PService getMessageP2PService(CacheService cacheService) throws Exception {
		if (instance == null) {
			synchronized (MessageP2PServiceFactory.class) {
				if (instance == null) {
					instance = new MessageP2PServiceImpl(cacheService);
				}	
			}
		}
		return instance;
	}

}
