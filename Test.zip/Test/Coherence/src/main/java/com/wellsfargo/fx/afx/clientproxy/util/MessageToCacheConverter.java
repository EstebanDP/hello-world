package com.wellsfargo.fx.afx.clientproxy.util;

import java.util.ArrayList;
import java.util.List;

import com.wellsfargo.fx.afx.common.log.Logger;
import com.wellsfargo.fx.afx.common.log.impl.LoggerFactory;
import com.wellsfargo.fx.afx.common.log.utils.LoggerConstants;
import com.wellsfargo.fx.afx.common.util.CommonConstants;
import com.wellsfargo.fx.afx.common.valueobject.Currency;
import com.wellsfargo.fx.afx.common.valueobject.CurrencyPair;
import com.wellsfargo.fx.afx.common.valueobject.JVMStatus;
import com.wellsfargo.fx.afx.common.valueobject.coherence.BuffetTrade;
import com.wellsfargo.fx.afx.common.valueobject.coherence.Configuration;
import com.wellsfargo.fx.afx.common.valueobject.coherence.CurrencyPairThresholdsConfig;
import com.wellsfargo.fx.afx.common.valueobject.coherence.JvmStatus;
import com.wellsfargo.fx.afx.common.valueobject.coherence.MarketSnapshot;
import com.wellsfargo.fx.afx.common.valueobject.coherence.OrderFill;
import com.wellsfargo.fx.afx.common.valueobject.coherence.PositionEcom;
import com.wellsfargo.fx.afx.common.valueobject.coherence.PositionTransfer;
import com.wellsfargo.fx.afx.common.valueobject.coherence.StrategyStatus;
import com.wellsfargo.fx.afx.common.valueobject.coherence.ThresholdStrategy;
import com.wellsfargo.fx.afx.common.valueobject.coherence.Transaction;
import com.wellsfargo.fx.afx.common.valueobject.coherence.ValueDate;
import com.wellsfargo.fx.afx.common.valueobject.gui.CurrencyDates;
import com.wellsfargo.fx.afx.common.valueobject.orderdata.Order;
import com.wellsfargo.fx.afx.common.valueobject.orderdata.TransactionRequest;
import com.wellsfargo.fx.afx.common.valueobject.serverproxy.StrategyState;
import com.wellsfargo.fx.afx.ecom.common.valueobject.PositionVo;
import com.wellsfargo.fx.afx.ecom.common.valueobject.buffet.BuffetTradeStatus;
import com.wellsfargo.fx.afx.ecom.common.valueobject.marketdata.CurrencyPairRateDisplay;

public class MessageToCacheConverter {

    private static final Logger logger = LoggerFactory.getLogger(LoggerConstants.CLIENT_PROXY);

    public static MarketSnapshot convert(CurrencyPairRateDisplay currencyPairRateDisplay) {
        MarketSnapshot marketSnapshot = new MarketSnapshot();
        String bestBid;
        String bestAsk;
        for (CurrencyPair currencyPair : currencyPairRateDisplay.getCurrencyPairs()) {
            bestBid = Float.compare(currencyPairRateDisplay.getBestBid(currencyPair), CommonConstants.CONST_NA) == 0 ? "-" : currencyPair
                    .getFormattedString(currencyPairRateDisplay.getBestBid(currencyPair));
            bestAsk = Float.compare(currencyPairRateDisplay.getBestOffer(currencyPair), CommonConstants.CONST_NA) == 0 ? "-" : currencyPair
                    .getFormattedString(currencyPairRateDisplay.getBestOffer(currencyPair));

            marketSnapshot.addRates(currencyPair.toString(), bestBid, bestAsk);
        }

        return marketSnapshot;
    }

    public static OrderFill convert(com.wellsfargo.fx.afx.common.valueobject.orderdata.OrderFill orFilled) {
    	logger.debug("Server-->User (Order Fill) " + orFilled.toString());
        OrderFill orderFill = new OrderFill();
        orderFill.setCurrencyPair(orFilled.getCurrencyPair().toString());
        orderFill.setEcnTradeId(orFilled.getEcnTradeId());
        orderFill.setOrderId(orFilled.getOrderId());
        orderFill.setPrice(orFilled.getCurrencyPair().getFormattedString(orFilled.getPrice()));
        orderFill.setQuantity(orFilled.getQuantity());
        orderFill.setSide(orFilled.getSide());
        orderFill.setExchange(orFilled.getExchange());
        orderFill.setExecutionTime(orFilled.getExecutionTime());
        orderFill.setAfxTime(orFilled.getAfxTime());

        return orderFill;
    }

    public static BuffetTrade convert(com.wellsfargo.fx.afx.ecom.common.valueobject.buffet.BuffetTrade bt) {
    	logger.debug("Server-->User (Buffet Trade) " + bt.toString());
        BuffetTrade buffetTrade = new BuffetTrade();
        buffetTrade.setTransactionId(bt.getBuffetTradeId());
        buffetTrade.setBuffetTradeStatus(bt.getBuffetTradeStatus());
        buffetTrade.setSource(bt.getSource());
        buffetTrade.setUserId(bt.getUserId());
        buffetTrade.setQuantity(bt.getQuantity());
        buffetTrade.setDuplicateTrade(bt.isDuplicateTrade());
        buffetTrade.setBuffetSentTime(bt.getBuffetSentTime());
        buffetTrade.setBuffetTradeId(bt.getBuffetTradeId());
        buffetTrade.setCurrencyPair(bt.getCurrencyPair());
        buffetTrade.setSide(bt.getSide().toString());
        buffetTrade.setSourceExecutionTime(bt.getSourceExecutionTime());
        buffetTrade.setAfxTime(bt.getAfxTime());
        buffetTrade.setSourceTradeId(bt.getSourceTradeId());
        buffetTrade.setInitialPosition(bt.isInitialPosition());
        buffetTrade.setReasonForReject(bt.getReasonForReject());
        
        CurrencyPair currencyPair;
        if ((currencyPair = CurrencyPair.getByName(bt.getCurrencyPair())) != null) {
        	buffetTrade.setRate(currencyPair.getFormattedString(bt.getRate()));
        } else {
        	buffetTrade.setRate(Float.toString(bt.getRate()));
        }

        if (bt.getBuffetTradeStatus().equals(BuffetTradeStatus.NEW)) {
        	String marketRateBid = currencyPair == null ? Float.toString(bt.getMarketRateBid()) : currencyPair.getFormattedString(bt.getMarketRateBid());
        	String marketRateOffer= currencyPair == null ? Float.toString(bt.getMarketRateOffer()) : currencyPair.getFormattedString(bt.getMarketRateOffer());
        	buffetTrade.setMarketRateBid(Float.compare(bt.getMarketRateBid(), CommonConstants.CONST_NA) == 0 ? CommonConstants.CONST_NA_STRING : marketRateBid);
            buffetTrade.setMarketRateOffer(Float.compare(bt.getMarketRateOffer(), CommonConstants.CONST_NA) == 0 ? CommonConstants.CONST_NA_STRING : marketRateOffer);
        }
        
        return buffetTrade;
    }
    
    public static PositionTransfer convert(com.wellsfargo.fx.afx.ecom.common.valueobject.buffet.PositionTransfer pt) {
    	logger.debug("Server-->User (Position Transfer) " + pt.toString());
    	PositionTransfer positionTransfer = new PositionTransfer();
        positionTransfer.setSource(pt.getSource());
        positionTransfer.setQuantity(pt.getQuantity());
        positionTransfer.setCtrQuantity(pt.getCtrQuantity());
        positionTransfer.setPositionTransferBuffetId(pt.getPositionTransferBuffetId());
        positionTransfer.setCurrencyPair(pt.getCurrencyPair());
        positionTransfer.setBookFrom(pt.getBookFrom());
        positionTransfer.setBookTo(pt.getBookTo());
        positionTransfer.setPortfolio(pt.getPortfolio());
        positionTransfer.setUserId(pt.getUserId());
        positionTransfer.setRejectedTransfer(pt.isRejectedTransfer());
        positionTransfer.setSide(pt.getSide());
        positionTransfer.setReason(pt.getReason());
        positionTransfer.setReasonForReject(pt.getReasonForReject());
        positionTransfer.setTransferCreationTime(pt.getTransferCreationTime());
        positionTransfer.setAfxTime(pt.getAfxTime());
        
        CurrencyPair currencyPair;
        if ((currencyPair = CurrencyPair.getByName(positionTransfer.getCurrencyPair())) != null) {
        	positionTransfer.setRate(currencyPair.getFormattedString(pt.getRate()));
        } else {
        	positionTransfer.setRate(Float.toString(pt.getRate()));
        }

        return positionTransfer;
    }

    public static ValueDate convert(CurrencyDates date) {
        logger.debug("Server-->User (value date) " + date.toString());
        ValueDate valueDate = new ValueDate();
        valueDate.setCurrencyPair(date.getCurrencyPair());
        valueDate.setTradeDate(date.getTradeDate());
        valueDate.setValueDate(date.getValueDate());
        return valueDate;
    }

    public static PositionEcom convert(PositionVo position, Currency currency) {
        PositionEcom positionEcom = new PositionEcom();
        positionEcom.setCurrency(currency.toString());
        positionEcom.setPosition(position.getPosition(currency));
        positionEcom.setUsdEquivalentPosition(position.getUsdEquivalentPosition(currency));
        positionEcom.setPnl(position.getPnl());

        return positionEcom;
    }

    public static JvmStatus convert(JVMStatus jvmStatus) {
        logger.debug("Server-->User (JVM) " + jvmStatus.getComponentName().toString() + " : " + jvmStatus.getJVMStatusEnum().toString() + " : " + jvmStatus.getReason());
        JvmStatus status = new JvmStatus();
        status.setComponentName(jvmStatus.getComponentName());
        status.setJvmStatus(jvmStatus.getJVMStatusEnum());
        status.setUserAttentionNeeded(jvmStatus.isUserAttentionNeeded());
        status.setResendStatusEvenIfSame(jvmStatus.isResendStatusEvenIfSame());
        status.setReason(jvmStatus.getReason());
        return status;
    }

    public static StrategyStatus convert(StrategyState strategyState) {
        logger.debug("Server-->User (pause) Strategy " + strategyState.getStrategyId() + " is paused? [" + strategyState.isPaused() + "]"
                + ", reason: " + strategyState.getReasonForPause());
        StrategyStatus status = new StrategyStatus();
        status.setStrategyId(strategyState.getStrategyId());
        status.setPaused(strategyState.isPaused());
        status.setStopped(strategyState.isStopped());
        status.setReasonForPause(strategyState.getReasonForPause());
        return status;
    }

    public static Transaction convert(TransactionRequest transactionRequest) {
        logger.debug("Server-->User (transaction) " + transactionRequest.toString());
        Transaction transaction = new Transaction();
        transaction.setAction(transactionRequest.getAction());
        transaction.setCompleted(transactionRequest.iscomplete());
        transaction.setExecutionType(transactionRequest.getExecutionType());
        transaction.setExpectedPnL(transactionRequest.getExpectedPnL());
        transaction.setActualPnL(transactionRequest.getActualPnL());
        transaction.setInitialArbPoints(transactionRequest.getInitialArbPoints());
        transaction.setExpectedArbPoints(transactionRequest.getExpectedArbPoints());
        transaction.setActualArbPoints(transactionRequest.getActualArbPoints());
        transaction.setGroupId(transactionRequest.getGroupId());
        transaction.setSnapshotTime(transactionRequest.getSnapshotTime());
        transaction.setStrategyId(transactionRequest.getStrategyId());
        transaction.setShowInGui(transactionRequest.showInGui());

        for (Order transactionOrder : transactionRequest.getOrderList()) {
            Transaction.Order order = transaction.new Order();
            order.setAction(transactionOrder.getAction());
            order.setCurrencyPair(transactionOrder.getCurrencyPair().toString());
            order.setExchange(transactionOrder.getExchange());
            order.setFilledPrice(transactionOrder.getFilledPrice());
            order.setFillQuantity(transactionOrder.getFillQuantity());
            order.setGroupId(transactionOrder.getGroupId());
            order.setMarketPrice(transactionOrder.getMarketPrice());
            int orderID = -1;
            try {
                orderID = transactionOrder.getOrderId();
            } catch (Exception e) {
            }
            order.setOrderId(orderID);
            order.setOrderQuantity(transactionOrder.getOrderQuantity());
            order.setOrderStatus(transactionOrder.getOrderStatus());
            order.setOrderType(transactionOrder.getOrderType());
            order.setSide(transactionOrder.getSide());
            order.setStrategyId(transactionOrder.getStrategyId());
            order.setTargetPrice(transactionOrder.getTargetPrice());
            order.setTimeInForce(transactionOrder.getTimeInForce());
            order.setIntentionalMatching(transactionOrder.isIntentionalMatching());
            order.setReferenceTransaction(transactionOrder.getReferenceTransaction());
            transaction.addOrder(order);
        }

        for (TransactionRequest childTransaction : transactionRequest.getChildTransactionRequests()) {
            for (Order childOrder : childTransaction.getOrderList()) {
                Transaction.Order order = transaction.new Order();
                order.setAction(childOrder.getAction());
                order.setCurrencyPair(childOrder.getCurrencyPair().toString());
                order.setExchange(childOrder.getExchange());
                order.setFilledPrice(childOrder.getFilledPrice());
                order.setFillQuantity(childOrder.getFillQuantity());
                order.setGroupId(childOrder.getParentGroupId());
                order.setMarketPrice(childOrder.getMarketPrice());
                order.setOrderId(childOrder.getOrderId());
                order.setOrderQuantity(childOrder.getOrderQuantity());
                order.setOrderStatus(childOrder.getOrderStatus());
                order.setOrderType(childOrder.getOrderType());
                order.setSide(childOrder.getSide());
                order.setStrategyId(childOrder.getParentStrategyId());
                order.setTargetPrice(childOrder.getTargetPrice());
                order.setTimeInForce(childOrder.getTimeInForce());
                order.setReferenceTransaction(childOrder.getReferenceTransaction());
                transaction.addOrder(order);
            }
        }

        return transaction;
    }

    public static Configuration convert(com.wellsfargo.fx.afx.common.valueobject.Configuration configurationVO) {
    	Configuration configuration = new Configuration();
    	configuration.setComponentName(configurationVO.getComponentName());
    	configuration.setConfigType(configurationVO.getConfigType());
    	configuration.setConfigurationName(configurationVO.getConfigurationName());
    	configuration.setConfigurationValue(configurationVO.getConfigurationValue());
    	configuration.setSaveToDatabase(configurationVO.isSaveToDatabase());
    	configuration.setUserName(configurationVO.getUserName());
    	configuration.setDescription(configurationVO.getDescription());
    	configuration.setUpdateDate(configurationVO.getUpdateDate());

        return configuration;
    }

	public static ThresholdStrategy convert(
			com.wellsfargo.fx.afx.ecom.common.valueobject.ThresholdStrategy thresholdStrategyVO) {
		ThresholdStrategy coherenceCCYPairThresholdStrategy = new ThresholdStrategy();
		coherenceCCYPairThresholdStrategy.setStrategyName(thresholdStrategyVO.getStrategyName());
		coherenceCCYPairThresholdStrategy.setAppliedByUser(thresholdStrategyVO.getAppliedByUser());
		coherenceCCYPairThresholdStrategy.setUpdateUser(thresholdStrategyVO.getUpdateUser());
		coherenceCCYPairThresholdStrategy.setActiveStrategy(thresholdStrategyVO.isActiveStrategy());
		coherenceCCYPairThresholdStrategy.setDeletable(thresholdStrategyVO.isDeletable());
		coherenceCCYPairThresholdStrategy.setUpdateCache(thresholdStrategyVO.isUpdateCache());
		coherenceCCYPairThresholdStrategy.setUpdateDate(thresholdStrategyVO.getUpdateDate());
		coherenceCCYPairThresholdStrategy.setNotes(thresholdStrategyVO.getNotes());
		
		List<CurrencyPairThresholdsConfig> ccyPairThresholdsConfig = new ArrayList<CurrencyPairThresholdsConfig>();
		
		for (com.wellsfargo.fx.afx.ecom.common.valueobject.CurrencyPairThresholdsConfig ccyConfig :
			thresholdStrategyVO.getCcyPairThresholdsConfig()) {
			CurrencyPairThresholdsConfig currencyPairThresholdsConfig = new CurrencyPairThresholdsConfig();
			currencyPairThresholdsConfig.setCurrencyPair(ccyConfig.getCurrencyPair().toString());
			currencyPairThresholdsConfig.setEnabled(ccyConfig.isEnabled());
			currencyPairThresholdsConfig.setUserName(ccyConfig.getUserName());
			currencyPairThresholdsConfig.setShortThreshold(ccyConfig.getShortThreshold());
			currencyPairThresholdsConfig.setLongThreshold(ccyConfig.getLongThreshold());

			ccyPairThresholdsConfig.add(currencyPairThresholdsConfig);
		}
		
		coherenceCCYPairThresholdStrategy.setCcyPairThresholdsConfig(ccyPairThresholdsConfig);
		return coherenceCCYPairThresholdStrategy;
	}
	
	public static com.wellsfargo.fx.afx.common.valueobject.coherence.CurrencyPair convert(
			com.wellsfargo.fx.afx.common.valueobject.CurrencyPair currencyPair) {
	    com.wellsfargo.fx.afx.common.valueobject.coherence.CurrencyPair cpCoherence = 
	    	new com.wellsfargo.fx.afx.common.valueobject.coherence.CurrencyPair();
	    
	    cpCoherence.setName(currencyPair.getName());
	    cpCoherence.setOrdinal(currencyPair.ordinal());
	    cpCoherence.setScale(currencyPair.getScale());
	    cpCoherence.setEnabled(currencyPair.isEnabled());
	    cpCoherence.setUpdateUser(currencyPair.getUpdateUser());
	    cpCoherence.setUpdateDate(currencyPair.getUpdateDate());
	    
	    com.wellsfargo.fx.afx.common.valueobject.coherence.Currency currency =
	    	new com.wellsfargo.fx.afx.common.valueobject.coherence.Currency();
	    
	    currency.setName(currencyPair.getFirstCurrency().getName());
	    currency.setOrdinal(currencyPair.getFirstCurrency().ordinal());
	    currency.setBaseCcyForUsd(currencyPair.getFirstCurrency().isBaseCcyForUsd());
	    cpCoherence.setFirstCurrency(currency);
	    
	    currency = new com.wellsfargo.fx.afx.common.valueobject.coherence.Currency();
	    currency.setName(currencyPair.getSecondCurrency().getName());
	    currency.setOrdinal(currencyPair.getSecondCurrency().ordinal());
	    currency.setBaseCcyForUsd(false);
	    cpCoherence.setSecondCurrency(currency);
	    
		return cpCoherence;
	}

	public static com.wellsfargo.fx.afx.common.valueobject.coherence.Currency convert(Currency ccy) {
	    com.wellsfargo.fx.afx.common.valueobject.coherence.Currency ccyCoherence = 
	    	new com.wellsfargo.fx.afx.common.valueobject.coherence.Currency();
	    
	    ccyCoherence.setName(ccy.getName());
	    ccyCoherence.setOrdinal(ccy.ordinal());
	    ccyCoherence.setBaseCcyForUsd(ccy.isBaseCcyForUsd());

		return ccyCoherence;
	}
}
