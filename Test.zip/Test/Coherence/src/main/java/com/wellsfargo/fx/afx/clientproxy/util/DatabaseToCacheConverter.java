package com.wellsfargo.fx.afx.clientproxy.util;

import java.util.ArrayList;
import java.util.List;

import com.wellsfargo.fx.afx.common.persistence.model.Strategy;
import com.wellsfargo.fx.afx.common.valueobject.ComponentName;
import com.wellsfargo.fx.afx.common.valueobject.coherence.Configuration;
import com.wellsfargo.fx.afx.common.valueobject.coherence.CurrencyPairThresholdsConfig;
import com.wellsfargo.fx.afx.common.valueobject.coherence.ThresholdStrategy;

public class DatabaseToCacheConverter {

	public static ThresholdStrategy convert(Strategy strategy) {
		ThresholdStrategy thresholdStrategy = new ThresholdStrategy();
		thresholdStrategy.setStrategyName(strategy.getStrategyName().trim());
		thresholdStrategy.setUpdateUser(strategy.getUpdateUser().trim());
		thresholdStrategy.setUpdateDate(new java.util.Date(strategy.getUpdateDate().getTime()));
		thresholdStrategy.setDeletable(strategy.isDeletable());
		thresholdStrategy.setNotes(strategy.getNotes().trim());
		
		List<CurrencyPairThresholdsConfig> ccyPairThresholdConfigList = new ArrayList<CurrencyPairThresholdsConfig>();
		for (com.wellsfargo.fx.afx.common.persistence.model.CurrencyPairThresholdsConfig dbCcyConfig : 
			strategy.getCcyPairThresholdsConfig()) {
			CurrencyPairThresholdsConfig ccyConfig = new CurrencyPairThresholdsConfig();
			ccyConfig.setCurrencyPair(dbCcyConfig.getCurrencyPair().trim());
			ccyConfig.setEnabled(dbCcyConfig.isEnabled());
			ccyConfig.setShortThreshold(dbCcyConfig.getShortThreshold());
			ccyConfig.setLongThreshold(dbCcyConfig.getLongThreshold());
			ccyConfig.setUserName(dbCcyConfig.getUpdatedByUser().trim());
			ccyPairThresholdConfigList.add(ccyConfig);
		}
			
		thresholdStrategy.setCcyPairThresholdsConfig(ccyPairThresholdConfigList);
		return thresholdStrategy;
	}

	public static Configuration convert(com.wellsfargo.fx.afx.common.persistence.model.Configuration configDB,
			ComponentName componentName) {
		Configuration configuration = new Configuration();
		configuration.setComponentName(componentName);
		configuration.setConfigType(configDB.getConfigType().trim());
		configuration.setConfigurationName(configDB.getConfigName().trim());
		configuration.setConfigurationValue(configDB.getConfigValue().trim());
		configuration.setUserName(configDB.getUpdateUser().trim());
		configuration.setUpdateDate(configDB.getUpdateDate());
		configuration.setDescription(new String());

		return configuration;
	}
}
