package com.wellsfargo.fx.afx.clientproxy.util;

import java.net.InetAddress;

import com.tangosol.util.Filter;
import com.wellsfargo.fx.afx.common.log.Logger;
import com.wellsfargo.fx.afx.common.log.impl.LoggerFactory;
import com.wellsfargo.fx.afx.common.log.utils.LoggerConstants;

/**
 * This class authenticates if a Coherence node can join the cluster.  
 * This class only validates against UAT IP/hostname.
 */
public class CacheSecurityManagerUat implements Filter {
	
	private static final Logger logger = LoggerFactory.getLogger(LoggerConstants.CLIENT_PROXY);

	@Override
	public boolean evaluate(Object obj) {
		String hostname = ((InetAddress)obj).getHostName();
		if (hostname == null || hostname.equals("")) {
			return false;
		}
		if (hostname.toLowerCase().startsWith("wupra01a0009") || hostname.toLowerCase().startsWith("wupra02a0009") || hostname.toLowerCase().startsWith("mcib1gsrt002")) {
			return true;
		} else if (System.getProperty("tangosol.coherence.ignore.security").equalsIgnoreCase("true")) {
			logger.info("[Caution] " + hostname + " joined coherence cluster by skipping security check!");
			return true;
		}
		return false;
	}

}
