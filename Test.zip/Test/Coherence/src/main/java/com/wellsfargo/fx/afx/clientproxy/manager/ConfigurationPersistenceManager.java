package com.wellsfargo.fx.afx.clientproxy.manager;

import java.util.List;

import com.wellsfargo.fx.afx.common.valueobject.coherence.Configuration;

public interface ConfigurationPersistenceManager {
	
	public void insertConfiguration(Configuration configuration);
	
	public void updateConfiguration(Configuration configuration);
	
	public List<Configuration> getConfigurations(String tableName);
	
}
