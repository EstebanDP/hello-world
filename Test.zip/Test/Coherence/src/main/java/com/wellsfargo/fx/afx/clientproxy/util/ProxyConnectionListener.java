package com.wellsfargo.fx.afx.clientproxy.util;

import java.util.concurrent.atomic.AtomicInteger;

import com.tangosol.coherence.component.net.extend.connection.TcpConnection;
import com.tangosol.net.messaging.ConnectionEvent;
import com.wellsfargo.fx.afx.common.log.Logger;
import com.wellsfargo.fx.afx.common.log.impl.LoggerFactory;
import com.wellsfargo.fx.afx.common.log.utils.LoggerConstants;
import com.wellsfargo.fx.afx.common.util.JVMUtils;

public class ProxyConnectionListener implements com.tangosol.net.messaging.ConnectionListener {
	
	 private static final Logger logger = LoggerFactory.getLogger(LoggerConstants.CLIENT_PROXY);
	 static private AtomicInteger liveGUICounts = new AtomicInteger(0);
	
	@Override
	public void connectionClosed(ConnectionEvent event) {
		TcpConnection tcpConnection = (TcpConnection) event.getSource();
		String memberName = tcpConnection.getMember().getMemberName();
		
		try {
			if (liveGUICounts.decrementAndGet() >= 0) {
				logger.debug(memberName + " left, currently there are " + liveGUICounts.get() + " GUIs running.");
    			return;
    		} else {
    			logger.debug(memberName + " left, GUI count is below zero, please check the logs, currently there are " + liveGUICounts.get() + " GUIs running.");
    			return;
    		}
    	} catch(Exception e) {
    		e.printStackTrace();
    		JVMUtils.killJVM(logger, false, false, e);
    	}
	}

	@Override
	public void connectionError(ConnectionEvent event) {
		TcpConnection tcpConnection = (TcpConnection) event.getSource();
		String memberName = tcpConnection.getMember().getMemberName();
		
		if (liveGUICounts.decrementAndGet() >= 0) {
			logger.debug(memberName + " left, currently there are " + liveGUICounts.get() + " GUIs running.");
			return;
		} else {
			logger.debug(memberName + " left, GUI count is below zero, please check the logs, currently there are " + liveGUICounts.get() + " GUIs running.");
			return;
		}
	}

	@Override
	public void connectionOpened(ConnectionEvent event) {
		TcpConnection tcpConnection = (TcpConnection) event.getSource();
		String memberName = tcpConnection.getMember().getMemberName();
		logger.debug(memberName + " joined, currently there are " + liveGUICounts.incrementAndGet() + " GUIs running.");
	}
	
	public static int getLiveGUICounts() {
		return liveGUICounts.get();
	}

	public static void setLiveGUICounts(int liveGUICounts) {
		ProxyConnectionListener.liveGUICounts.set(liveGUICounts);
	}
}
