package com.wellsfargo.fx.afx.clientproxy;

import java.lang.Thread.UncaughtExceptionHandler;

import com.wellsfargo.fx.afx.clientproxy.service.CacheService;
import com.wellsfargo.fx.afx.clientproxy.service.MessageP2PService;
import com.wellsfargo.fx.afx.clientproxy.service.impl.CacheServiceFactory;
import com.wellsfargo.fx.afx.clientproxy.service.impl.MessageP2PServiceFactory;
import com.wellsfargo.fx.afx.clientproxy.util.ClientProxyConstants;
import com.wellsfargo.fx.afx.common.log.Logger;
import com.wellsfargo.fx.afx.common.log.impl.LoggerFactory;
import com.wellsfargo.fx.afx.common.log.utils.LoggerConstants;
import com.wellsfargo.fx.afx.common.util.ConfigurationLoader;
import com.wellsfargo.fx.afx.common.util.JVMUtils;

public class ClientProxy { 
	private static final Logger log = LoggerFactory.getLogger(LoggerConstants.CLIENT_PROXY);
	
	private CacheService cacheService;
	private MessageP2PService messageP2PService;

	public static void main(String[] args) {
		ConfigurationLoader.getInstance().validateConfigurations(ClientProxyConstants.class);
		Thread.currentThread().setUncaughtExceptionHandler(new UncaughtExceptionHandler() {
            public void uncaughtException(Thread t, Throwable e) {
                log.setEnableLogging(true);
                log.debug("[" + t + "] -- " + e);
                JVMUtils.killJVM(log, false, false, (Exception) e);
            }
        });
		
		try {
			new ClientProxy().start();
		} catch (Exception e) {
			log.setEnableLogging(true);
            JVMUtils.killJVM(log, false, false, e);
		}
	}

	public ClientProxy() throws Exception {
		cacheService = CacheServiceFactory.getCacheService();
		messageP2PService = MessageP2PServiceFactory.getMessageP2PService(cacheService);
		cacheService.setMessageP2PService(messageP2PService);
	}

	public void start() {
		cacheService.start();
		messageP2PService.start();
	}

}
