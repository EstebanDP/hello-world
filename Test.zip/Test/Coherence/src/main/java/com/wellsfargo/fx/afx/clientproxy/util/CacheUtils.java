package com.wellsfargo.fx.afx.clientproxy.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.tangosol.net.CacheFactory;
import com.tangosol.net.NamedCache;
import com.wellsfargo.fx.afx.common.log.Logger;
import com.wellsfargo.fx.afx.common.log.impl.LoggerFactory;
import com.wellsfargo.fx.afx.common.persistence.dao.ConfigurationDAO;
import com.wellsfargo.fx.afx.common.persistence.dao.StrategyDAO;
import com.wellsfargo.fx.afx.common.persistence.model.Strategy;
import com.wellsfargo.fx.afx.common.util.CacheName;
import com.wellsfargo.fx.afx.common.util.CommonConstants;
import com.wellsfargo.fx.afx.common.util.ConfigurationLoader;
import com.wellsfargo.fx.afx.common.util.JVMUtils;
import com.wellsfargo.fx.afx.common.util.Util;
import com.wellsfargo.fx.afx.common.valueobject.ComponentName;
import com.wellsfargo.fx.afx.common.valueobject.ComponentType;
import com.wellsfargo.fx.afx.common.valueobject.CurrencyPair;
import com.wellsfargo.fx.afx.common.valueobject.JVMStatusEnum;
import com.wellsfargo.fx.afx.common.valueobject.coherence.Configuration;
import com.wellsfargo.fx.afx.common.valueobject.coherence.JvmStatus;
import com.wellsfargo.fx.afx.common.valueobject.coherence.ThresholdStrategy;

public class CacheUtils {

	private static CacheUtils self;
	private static final Logger logger = LoggerFactory.getLogger("");
	
	private final boolean isRunningAsEcom;
	
	private NamedCache jvmCache;
	
    private List<String> marketDataGatewayList;
    private List<String> orderRoutingGatewayList;

	static {
        self = new CacheUtils();
    }

    public static CacheUtils getInstance() {
        return self;
    }
    
    private CacheUtils() {
    	isRunningAsEcom = ConfigurationLoader.getInstance().getString(CommonConstants.CONST_COMPONENT_TYPE).equalsIgnoreCase(ComponentType.ECOM.toString());
    	jvmCache = CacheFactory.getCache(CacheName.CACHE_JVM_STATUS);
    	loadConfiguration();
    }
    
    private void loadConfiguration() {
    	marketDataGatewayList = ClientProxyConstants.VALUE_MARKET_DATA_GATEWAY_LIST;
        List<String> mdgList = new ArrayList<String>();
        for (String marketDataGateway : marketDataGatewayList) {
        	mdgList.add(Util.getComponentName(marketDataGateway).toString());
        }
        marketDataGatewayList = mdgList;
        
        orderRoutingGatewayList = ClientProxyConstants.VALUE_ORDER_ROUTING_GATEWAY_LIST;
        List<String> orgList = new ArrayList<String>();
        for (String orderRoutingGateway : orderRoutingGatewayList) {
        	orgList.add(Util.getComponentName(orderRoutingGateway).toString());
        }
        orderRoutingGatewayList = orgList;
	}
    

	public JvmStatus getUpdatedGlobalJVMStatus() {
        JvmStatus jvmGlobalStatus = new JvmStatus(ComponentName.GLOBAL_STATUS, JVMStatusEnum.DOWN);
        jvmGlobalStatus.setUserAttentionNeeded(true);
        
		if (isRunningAsEcom) {
			JvmStatus gfxApi = (JvmStatus) jvmCache.get(ComponentName.GFX_API.toString());
			
			if (gfxApi == null) {
				jvmGlobalStatus.setReason(Util.getJVMNameByComponent(ComponentName.GFX_API) + " is NULL");
				return jvmGlobalStatus;
			}
			
			if (!gfxApi.getJvmStatus().equals(JVMStatusEnum.RUNNING)) {
				jvmGlobalStatus.setReason(Util.getJVMNameByComponent(ComponentName.GFX_API) + " is " + gfxApi.getJvmStatus().toString());
				return jvmGlobalStatus;
			}
			
			JvmStatus serverProxy = (JvmStatus) jvmCache.get(ComponentName.SERVER_PROXY.toString());
			
			if (serverProxy == null) {
				jvmGlobalStatus.setReason(Util.getJVMNameByComponent(ComponentName.SERVER_PROXY) + " is NULL");
				return jvmGlobalStatus;
			}
			
			JvmStatus jvmPmEcom = (JvmStatus) jvmCache.get(ComponentName.POSITION_MANAGER_ECOM.toString());
			if(jvmPmEcom == null) {
				jvmGlobalStatus.setReason(Util.getJVMNameByComponent(ComponentName.POSITION_MANAGER_ECOM) + " is NULL");
				return jvmGlobalStatus;
	    	}
			
	    	JVMStatusEnum jvmStatusPmEcom = jvmPmEcom.getJvmStatus();
	    	
	    	if (jvmStatusPmEcom.equals(JVMStatusEnum.DOWN)) {
	    		jvmGlobalStatus.setResendStatusEvenIfSame(jvmPmEcom.isResendStatusEvenIfSame());
	    		jvmGlobalStatus.setReason(Util.getJVMNameByComponent(ComponentName.POSITION_MANAGER_ECOM) + " is " + jvmStatusPmEcom.toString());
				return jvmGlobalStatus;
	    	}
	    	
	    	JVMStatusEnum jvmStatusMdg = getGatewayStatus(marketDataGatewayList);
	    	JVMStatusEnum jvmStatusOrg = getGatewayStatus(orderRoutingGatewayList);
	    	
	    	jvmGlobalStatus.setResendStatusEvenIfSame(resendStatusEvenIfSame(marketDataGatewayList) || jvmPmEcom.isResendStatusEvenIfSame() || resendStatusEvenIfSame(orderRoutingGatewayList));
	    	
	    	if (jvmStatusMdg.equals(JVMStatusEnum.DOWN)) {
	    		jvmGlobalStatus.setReason("MDG is " + jvmStatusMdg.toString());
				return jvmGlobalStatus;
	    	}
	    	
	    	if (jvmStatusOrg.equals(JVMStatusEnum.DOWN)) {
	    		jvmGlobalStatus.setReason("ORG is " + jvmStatusMdg.toString());
				return jvmGlobalStatus;
	    	}
	    	
	    	// If all components are conected and ready to warm up...
	    	if (jvmStatusMdg.equals(JVMStatusEnum.READY_TO_WARM_UP) && jvmStatusPmEcom.equals(JVMStatusEnum.READY_TO_WARM_UP) && jvmStatusOrg.equals(JVMStatusEnum.READY_TO_WARM_UP)) {
	    		jvmGlobalStatus.setReason("Components are READY TO WARM UP");
				return jvmGlobalStatus;
	    	}
	    	
	    	if (jvmStatusMdg.equals(JVMStatusEnum.UP) && jvmStatusPmEcom.equals(JVMStatusEnum.UP) && jvmStatusOrg.equals(JVMStatusEnum.UP)) {
	    		jvmGlobalStatus.setReason("Components are UP");
				return jvmGlobalStatus;
	    	}
	    	
	    	if (jvmStatusMdg.equals(JVMStatusEnum.STANDBY) && (jvmStatusPmEcom.equals(JVMStatusEnum.UP) || jvmStatusPmEcom.equals(JVMStatusEnum.STANDBY)) 
	    			&& jvmStatusOrg.equals(JVMStatusEnum.STANDBY)) {
	    		jvmGlobalStatus.setReason("MDG and ORG are on STANDBY, PM is either UP or STANDBY");
				return jvmGlobalStatus;
	    	}
	    	
	    	if (jvmStatusMdg.equals(JVMStatusEnum.RUNNING) && jvmStatusPmEcom.equals(JVMStatusEnum.UP) && jvmStatusOrg.equals(JVMStatusEnum.RUNNING)) {
	    		jvmGlobalStatus.setReason("MDG and ORG are on RUNNING, PM is UP");
	    		jvmGlobalStatus.setJvmStatus(JVMStatusEnum.UP);
				return jvmGlobalStatus;
	    	}
	    	
	    	if (jvmStatusMdg.equals(JVMStatusEnum.RUNNING) && jvmStatusPmEcom.equals(JVMStatusEnum.STANDBY) && jvmStatusOrg.equals(JVMStatusEnum.RUNNING)) {
	    		jvmGlobalStatus.setUserAttentionNeeded(false);
	    		jvmGlobalStatus.setJvmStatus(JVMStatusEnum.STANDBY);
	    		jvmGlobalStatus.setReason("MDG and ORG are on RUNNING, PM is STANDBY");
				return jvmGlobalStatus;
	    	}
	    	
	    	if (jvmStatusMdg.equals(JVMStatusEnum.RUNNING) && jvmStatusPmEcom.equals(JVMStatusEnum.RUNNING) && jvmStatusOrg.equals(JVMStatusEnum.RUNNING)) {
	    		jvmGlobalStatus.setUserAttentionNeeded(false);
	    		jvmGlobalStatus.setJvmStatus(JVMStatusEnum.RUNNING);
	    		jvmGlobalStatus.setReason("All components are on RUNNING");
				return jvmGlobalStatus;
	    	}
		}

		return jvmGlobalStatus;
	}
	
	private boolean resendStatusEvenIfSame(List<String> list) {
		boolean resend = false;
		
		for (String str : list) {
			JvmStatus jvm = (JvmStatus) jvmCache.get(str);
			
			if (jvm != null) {
				resend = resend || jvm.isResendStatusEvenIfSame();
			}
        }
		return resend;
	}

	private JVMStatusEnum getGatewayStatus(List<String> list) {
		JVMStatusEnum jvmStatus = null;
		
		for (String str : list) {
			JvmStatus jvmGateway = (JvmStatus) jvmCache.get(str);
			
			if (jvmGateway == null) {
				return JVMStatusEnum.DOWN;
			} else {
				if (jvmStatus == null) {
					jvmStatus = jvmGateway.getJvmStatus();
				}
				
				if (jvmStatus.compareTo(jvmGateway.getJvmStatus()) > 0) {
					jvmStatus = jvmGateway.getJvmStatus();
				}
			}
        }
		
		if (jvmStatus != null) {
			return jvmStatus;
		}
		
		return JVMStatusEnum.DOWN;
	}

	public void loadInitConfigurationAndStrategies() {
		try {			
			// Load Currency Pairs
			NamedCache currencyPairCache = CacheFactory.getCache(CacheName.CACHE_CURRENCY_PAIR);
			for (CurrencyPair currencyPair : CurrencyPair.values()) {
				com.wellsfargo.fx.afx.common.valueobject.coherence.CurrencyPair cp = MessageToCacheConverter.convert(currencyPair);
				currencyPairCache.put(cp.getName(), cp);
			}
			
			// Load Strategies
			NamedCache strategyCache = CacheFactory.getCache(CacheName.CACHE_STRATEGY);
			for (Strategy strategy : new StrategyDAO().getStrategies()) {
				ThresholdStrategy thresholdStrategy = DatabaseToCacheConverter.convert(strategy);
				strategyCache.put(thresholdStrategy.getStrategyName(), thresholdStrategy);
			}
			
			// Load default configurations...
			loadConfigurations();
			
		  } catch (Exception exception) {
			JVMUtils.killJVM(logger, false, false, exception);
		  }
	}

	private void loadConfigurations() {
		try {
			NamedCache configCache = CacheFactory.getCache(CacheName.CACHE_APPLIED_CONFIGURATION);
			ConfigurationDAO configurationDAO = new ConfigurationDAO();
			HashMap<ComponentName, ArrayList<com.wellsfargo.fx.afx.common.persistence.model.Configuration>> configMap 
			= configurationDAO.getConfigurationsForAllComponents();
			
			for (ComponentName componentName : configMap.keySet()) {
				HashMap<String, Configuration> map = new HashMap<String, Configuration>();
				
				for (com.wellsfargo.fx.afx.common.persistence.model.Configuration configDB : configMap.get(componentName)) {
					Configuration config = DatabaseToCacheConverter.convert(configDB, componentName);
					map.put(config.getConfigurationName(), config);
				}
				
				configCache.put(componentName, map);
			}
		} catch (Exception exception) {
			logger.info(exception);
		}
	}
}
