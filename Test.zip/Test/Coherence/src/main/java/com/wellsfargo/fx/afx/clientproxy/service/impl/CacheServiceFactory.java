package com.wellsfargo.fx.afx.clientproxy.service.impl;

import com.wellsfargo.fx.afx.clientproxy.service.CacheService;

public class CacheServiceFactory {
	
	private static volatile CacheService instance;

	public static CacheService getCacheService() throws Exception {
		if (instance == null) {
			synchronized (CacheServiceFactory.class) {
				if (instance == null) {
					instance = new CacheServiceImpl();
				}	
			}
		}
		return instance;
	}

}
