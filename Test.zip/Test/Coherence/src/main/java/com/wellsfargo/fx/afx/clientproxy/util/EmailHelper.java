package com.wellsfargo.fx.afx.clientproxy.util;

import java.util.Date;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import com.wellsfargo.fx.afx.common.log.Logger;
import com.wellsfargo.fx.afx.common.log.impl.LoggerFactory;
import com.wellsfargo.fx.afx.common.log.utils.LoggerConstants;

public class EmailHelper {
    private static final Logger logger = LoggerFactory.getLogger(LoggerConstants.CLIENT_PROXY);
    private static EmailHelper self;

    static {
        self = new EmailHelper();
    }
    
    public static EmailHelper getInstance() {
        return self;
    }

    private EmailHelper() {
    }
   
    public void sendEmail(String subject, String message) {
    	Properties props = new Properties();
        props.put("mail.smtp.host", ClientProxyConstants.VALUE_EMAIL_SMTP_URL);
        props.put("mail.smtp.port", ClientProxyConstants.VALUE_EMAIL_SMTP_PORT);
		Session session = Session.getInstance(props,null);
		
		if (session == null) {
			logger.info("Could not send mail as database might not be configured correctly.");
			return;
		}
		
        try {
            MimeMessage mimeMessage = new MimeMessage(session);
            mimeMessage.setFrom(new InternetAddress(ClientProxyConstants.VALUE_EMAIL_FROM));
            mimeMessage.setRecipients(Message.RecipientType.TO, "esteban.delpozo@wellsfargo.com");
            mimeMessage.setSubject(subject);
            
            Multipart multipart = new MimeMultipart();
            MimeBodyPart bodyPart = new MimeBodyPart();
            bodyPart.setContent(message, "text/html");
            multipart.addBodyPart(bodyPart);

            mimeMessage.setContent(multipart);
            mimeMessage.setSentDate(new Date());
            Transport.send(mimeMessage);
        } catch (MessagingException mex) {
            logger.info("Could not send mail, exception: " + mex);
        }
    }
}
