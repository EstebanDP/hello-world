package com.wellsfargo.fx.afx.clientproxy.manager;

import com.wellsfargo.fx.afx.common.valueobject.coherence.OrderFill;

public interface OrderFillPersistenceManager {
	
	public void ensureIndex();
	
	public void saveOrderFill(OrderFill orderFill);
	
}
