package com.wellsfargo.fx.afx.clientproxy.service;

public interface MessageP2PService {
	
	public void start();

    public void stop();
    
    public void sendToServerProxy(byte[] bytes);
    
    public void sendToGFXClient(byte[] bytes);
}
