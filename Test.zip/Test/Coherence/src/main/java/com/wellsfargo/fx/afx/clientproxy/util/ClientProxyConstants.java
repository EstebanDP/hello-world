package com.wellsfargo.fx.afx.clientproxy.util;

import java.math.BigDecimal;
import java.util.List;

import com.wellsfargo.fx.afx.common.util.CommonConstants;
import com.wellsfargo.fx.afx.common.util.ConfigurationLoader;

public interface ClientProxyConstants {
	
	public static final String VALUE_SEND_TO_SERVER_PROXY_TOPIC = ConfigurationLoader.getInstance().getString(CommonConstants.CONST_SEND_TO_SERVER_PROXY_TOPIC);
	
	public static final String VALUE_SEND_TO_GFX_API_TOPIC = ConfigurationLoader.getInstance().getString("messaging.topic.send.to.gfx");
	
	public static final String VALUE_RECEIVE_FROM_GFX_API_TOPIC = ConfigurationLoader.getInstance().getString("messaging.topic.receive.from.gfx");
	
	public static final String CONST_APPLICATION_ID = "AFX";
	
	public static final String VALUE_RECEIVE_FROM_SERVER_PROXY_TOPIC = ConfigurationLoader.getInstance().getString(CommonConstants.CONST_RECEIVE_FROM_SERVER_PROXY_TOPIC);
	
	public static final String VALUE_SECUREFX_URL = ConfigurationLoader.getInstance().getString("securefx.url");
	
	public static final String VALUE_SECUREFX_USER = ConfigurationLoader.getInstance().getString("securefx.user");
	
	public static final String VALUE_SECUREFX_PASSWORD = ConfigurationLoader.getInstance().getString("securefx.password");
	
	public static final List<String> VALUE_SECUREFX_ROLE_PRIVILEDGES = ConfigurationLoader.getInstance().getList("securefx.roles.priviledges");
	
	public static final String VALUE_EMAIL_SMTP_URL = ConfigurationLoader.getInstance().getString("email.smtp.url");
	
	public static final String VALUE_EMAIL_SMTP_PORT = ConfigurationLoader.getInstance().getString("email.smtp.port");
	
	public static final String VALUE_EMAIL_FROM = ConfigurationLoader.getInstance().getString("email.from");
	
	public static final String VALUE_EMAIL_TO = ConfigurationLoader.getInstance().getString("email.to");
	
	public static final BigDecimal VALUE_MACRO_THRESHOLD_MIN_AMOUNT = ConfigurationLoader.getInstance().getBigDecimal(CommonConstants.CONST_MACRO_THRESHOLD_MIN_AMOUNT);
	
	public static final List<String> VALUE_MARKET_DATA_GATEWAY_LIST = ConfigurationLoader.getInstance().getList(CommonConstants.CONST_MARKET_DATA_GATEWAY_LIST);
	
	public static final List<String> VALUE_ORDER_ROUTING_GATEWAY_LIST = ConfigurationLoader.getInstance().getList(CommonConstants.CONST_ORDER_ROUTING_GATEWAY_LIST);
}