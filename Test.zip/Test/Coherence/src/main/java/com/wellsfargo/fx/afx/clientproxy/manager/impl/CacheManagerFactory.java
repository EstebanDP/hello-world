package com.wellsfargo.fx.afx.clientproxy.manager.impl;

import com.wellsfargo.fx.afx.clientproxy.manager.CacheManager;

public class CacheManagerFactory {
	
	private static volatile CacheManager instance;

	public static CacheManager getCacheManager() throws Exception {
		if (instance == null) {
			synchronized (CacheManagerFactory.class) {
				if (instance == null) {
					instance = new CacheManagerCoherence();
				}
			}
		}
		return instance;
	}
}
