package com.wellsfargo.fx.afx.clientproxy.manager;


public interface CacheManager {

	public void registerCacheListener();
	
	public void unregisterCacheListener();
	
	public void destroy();
	
	
}
