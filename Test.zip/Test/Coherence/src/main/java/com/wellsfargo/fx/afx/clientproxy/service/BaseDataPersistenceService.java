package com.wellsfargo.fx.afx.clientproxy.service;

public interface BaseDataPersistenceService {
	
	public void start();

    public void stop();

}
