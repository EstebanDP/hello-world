package com.wellsfargo.fx.afx.clientproxy.service.impl;

import java.math.BigDecimal;

import com.wellsfargo.fx.afx.clientproxy.manager.CacheManager;
import com.wellsfargo.fx.afx.clientproxy.manager.impl.CacheManagerFactory;
import com.wellsfargo.fx.afx.clientproxy.service.BaseDataPersistenceService;
import com.wellsfargo.fx.afx.clientproxy.service.CacheService;
import com.wellsfargo.fx.afx.clientproxy.service.MessageP2PService;
import com.wellsfargo.fx.afx.common.valueobject.coherence.BuffetTrade;
import com.wellsfargo.fx.afx.common.valueobject.coherence.Configuration;
import com.wellsfargo.fx.afx.common.valueobject.coherence.CurrencyPairStatistics;
import com.wellsfargo.fx.afx.common.valueobject.coherence.ThresholdStrategy;
import com.wellsfargo.fx.afx.common.valueobject.coherence.JvmStatus;
import com.wellsfargo.fx.afx.common.valueobject.coherence.MarketSnapshot;
import com.wellsfargo.fx.afx.common.valueobject.coherence.OrderFill;
import com.wellsfargo.fx.afx.common.valueobject.coherence.PositionEcom;
import com.wellsfargo.fx.afx.common.valueobject.coherence.PositionTransfer;
import com.wellsfargo.fx.afx.common.valueobject.coherence.StrategyStatistics;
import com.wellsfargo.fx.afx.common.valueobject.coherence.StrategyStatus;
import com.wellsfargo.fx.afx.common.valueobject.coherence.Transaction;
import com.wellsfargo.fx.afx.common.valueobject.coherence.ValueDate;

public class CacheServiceImpl implements CacheService {

    private CacheManager cacheManager;

    public CacheServiceImpl() throws Exception {
        cacheManager = CacheManagerFactory.getCacheManager();
    }

    @Override
    public void start() {
    	// TODO (Esteban): This is where we populate the initial configurations and strategies to cache from database
        cacheManager.registerCacheListener();
    }

    @Override
    public void stop() {
        cacheManager.unregisterCacheListener();
        cacheManager.destroy();
    }

    @Override
    public void saveValueDate(ValueDate valueDate) {
        cacheManager.saveValueDate(valueDate);
    }

    @Override
    public ValueDate getValueDate(String ccyPair) {
        return cacheManager.getValueDate(ccyPair);
    }

	@Override
	public void savePositionEcom(PositionEcom positionEcom) {
		cacheManager.savePositionEcom(positionEcom);
	}

    @Override
    public void saveTransaction(Transaction transaction) {
        cacheManager.saveTransaction(transaction);
    }
    
	@Override
	public void saveBuffetTrade(BuffetTrade buffetTrade) {
		cacheManager.saveBuffetTrade(buffetTrade);
	}

    @Override
    public void saveTotalPnl(BigDecimal pnl) {
        cacheManager.saveTotalPnL(pnl);
    }

    @Override
    public void saveGrossAggregatePosition(BigDecimal combinedPosition) {
        cacheManager.saveGrossAggregatePosition(combinedPosition);
    }

    @Override
    public void saveJvmStatus(JvmStatus status) {
        cacheManager.saveJvmStatus(status);
    }

    @Override
    public void saveStrategyStatus(StrategyStatus status) {
        cacheManager.saveStrategyStatus(status);
    }

    @Override
    public void saveCurrencyPairStatistics(String id, CurrencyPairStatistics currencyPairStatistics) {
        cacheManager.saveCurrencyPairStatistics(id, currencyPairStatistics);
    }

    @Override
    public void saveStrategyStatistics(String id, StrategyStatistics strategyStats) {
        cacheManager.saveStrategyStatistics(id, strategyStats);
    }
    
	@Override
	public void saveMarketSnapshot(MarketSnapshot marketSnapshot) {
		cacheManager.saveMarketSnapshot(marketSnapshot);
	}
	
	@Override
	public void saveOrderFill(OrderFill orderFill) {
		cacheManager.saveOrderFill(orderFill);
	}
	
	@Override
	public void savePositionTransfer(PositionTransfer positionTransfer) {
		cacheManager.savePositionTransfer(positionTransfer);
	}

	@Override
	public void saveCofiguration(Configuration configuration) {
		cacheManager.saveCofiguration(configuration);
	}
	
	@Override
	public void saveThresholdStrategy(ThresholdStrategy thresholdStrategy) {
		cacheManager.saveThresholdStrategy(thresholdStrategy);
	}
	
	@Override
	public void resetCaches() {
		cacheManager.resetCaches();
	}
	
    @Override
    public void setDataPersistenceService(BaseDataPersistenceService dataPersistenceService) {
        cacheManager.setDataPersistenceService(dataPersistenceService);
    }

    @Override
    public void setMessageP2PService(MessageP2PService messageP2PService) {
        cacheManager.setMessageP2PService(messageP2PService);
    }

	@Override
	public JvmStatus getGlobalJVMStatus() {
		return cacheManager.getGlobalJVMStatus();
	}

	@Override
	public void clearJVMCache() {
		cacheManager.clearJVMCache();
	}
}
