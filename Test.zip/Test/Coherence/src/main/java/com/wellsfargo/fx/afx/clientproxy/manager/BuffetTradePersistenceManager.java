package com.wellsfargo.fx.afx.clientproxy.manager;

import com.wellsfargo.fx.afx.common.valueobject.coherence.BuffetTrade;

public interface BuffetTradePersistenceManager {
	
	public void ensureIndex();
	
	public void saveBuffetTrade(BuffetTrade buffetTrade);
	
}
