package com.wellsfargo.fx.afx.clientproxy.service.impl;

import java.util.concurrent.atomic.AtomicInteger;

import com.latencybusters.lbm.LBM;
import com.latencybusters.lbm.LBMSourceEvent;
import com.latencybusters.lbm.LBMSourceEventCallback;
import com.wellsfargo.fx.afx.clientproxy.service.CacheService;
import com.wellsfargo.fx.afx.clientproxy.service.MessageP2PService;
import com.wellsfargo.fx.afx.clientproxy.util.ArbStatisticsUtil;
import com.wellsfargo.fx.afx.clientproxy.util.ClientProxyConstants;
import com.wellsfargo.fx.afx.clientproxy.util.ClientProxyUtil;
import com.wellsfargo.fx.afx.clientproxy.util.EcomStatisticsUtil;
import com.wellsfargo.fx.afx.clientproxy.util.MessageToCacheConverter;
import com.wellsfargo.fx.afx.common.log.Logger;
import com.wellsfargo.fx.afx.common.log.impl.LoggerFactory;
import com.wellsfargo.fx.afx.common.log.utils.LoggerConstants;
import com.wellsfargo.fx.afx.common.messaging.MessageListener;
import com.wellsfargo.fx.afx.common.messaging.MessageReceiver;
import com.wellsfargo.fx.afx.common.messaging.MessageSender;
import com.wellsfargo.fx.afx.common.messaging.impl.MessagingManagerFactory;
import com.wellsfargo.fx.afx.common.util.AFXThread;
import com.wellsfargo.fx.afx.common.util.CommonConstants;
import com.wellsfargo.fx.afx.common.util.ConfigurationLoader;
import com.wellsfargo.fx.afx.common.valueobject.ComponentName;
import com.wellsfargo.fx.afx.common.valueobject.ComponentType;
import com.wellsfargo.fx.afx.common.valueobject.Configuration;
import com.wellsfargo.fx.afx.common.valueobject.Currency;
import com.wellsfargo.fx.afx.common.valueobject.DefaultMessageDecoder;
import com.wellsfargo.fx.afx.common.valueobject.JVMStatus;
import com.wellsfargo.fx.afx.common.valueobject.JVMStatusEnum;
import com.wellsfargo.fx.afx.common.valueobject.MessageType;
import com.wellsfargo.fx.afx.common.valueobject.UserControlMessage;
import com.wellsfargo.fx.afx.common.valueobject.UserControlMessage.UserControlMessageEnum;
import com.wellsfargo.fx.afx.common.valueobject.coherence.JvmStatus;
import com.wellsfargo.fx.afx.common.valueobject.coherence.Transaction;
import com.wellsfargo.fx.afx.common.valueobject.coherence.ValueDate;
import com.wellsfargo.fx.afx.common.valueobject.gui.CurrencyDates;
import com.wellsfargo.fx.afx.common.valueobject.gui.UsdEquivalentPositionInfo;
import com.wellsfargo.fx.afx.common.valueobject.orderdata.OrderFill;
import com.wellsfargo.fx.afx.common.valueobject.orderdata.TransactionRequest;
import com.wellsfargo.fx.afx.common.valueobject.serverproxy.StrategyState;
import com.wellsfargo.fx.afx.ecom.common.valueobject.PositionVo;
import com.wellsfargo.fx.afx.ecom.common.valueobject.ThresholdStrategy;
import com.wellsfargo.fx.afx.ecom.common.valueobject.buffet.AFXStatus;
import com.wellsfargo.fx.afx.ecom.common.valueobject.buffet.AFXStatus.AFXStatusEnum;
import com.wellsfargo.fx.afx.ecom.common.valueobject.buffet.BuffetTrade;
import com.wellsfargo.fx.afx.ecom.common.valueobject.buffet.PositionTransfer;
import com.wellsfargo.fx.afx.ecom.common.valueobject.marketdata.CurrencyPairRateDisplay;

public class MessageP2PServiceImpl implements MessageP2PService {

	private static Logger logger = LoggerFactory.getLogger(LoggerConstants.CLIENT_PROXY);
	
    private MessageSender serverProxySender;
    private MessageReceiver serverProxyReceiver;
    private MessageSender gfxClientSender;
    private MessageReceiver gfxClientReceiver;

    private CacheService cacheService;

    private ArbFillRatioPublisher arbFillRatioPublisher;
    private EcomFillRatioPublisher ecomFillRatioPublisher;
    private final boolean isRunningAsArb;
    private final boolean isRunningAsEcom;
    protected AtomicInteger currentNumberOfReceiversServerProxy;
    protected AtomicInteger currentNumberOfReceiversGFXApi;
    
    public MessageP2PServiceImpl(CacheService cacheService) {
    	currentNumberOfReceiversServerProxy = new AtomicInteger(0);
    	currentNumberOfReceiversGFXApi = new AtomicInteger(0);
    	
    	isRunningAsArb = ConfigurationLoader.getInstance().getString(CommonConstants.CONST_COMPONENT_TYPE).equalsIgnoreCase(ComponentType.ARB.toString());
    	isRunningAsEcom = ConfigurationLoader.getInstance().getString(CommonConstants.CONST_COMPONENT_TYPE).equalsIgnoreCase(ComponentType.ECOM.toString());
        this.cacheService = cacheService;
        arbFillRatioPublisher = new ArbFillRatioPublisher();
        ecomFillRatioPublisher = new EcomFillRatioPublisher();
        
        serverProxySender = MessagingManagerFactory.getMessagingManager().getSenderForTopic(ClientProxyConstants.VALUE_SEND_TO_SERVER_PROXY_TOPIC, new ServerProxyConnectionListener());
        serverProxyReceiver = MessagingManagerFactory.getMessagingManager().getReceiverForTopic(ClientProxyConstants.VALUE_RECEIVE_FROM_SERVER_PROXY_TOPIC, new ServerProxyListener());
        
        gfxClientSender = MessagingManagerFactory.getMessagingManager().getSenderForTopic(ClientProxyConstants.VALUE_SEND_TO_GFX_API_TOPIC, new GfxAPIConnectionListener());
        gfxClientReceiver = MessagingManagerFactory.getMessagingManager().getReceiverForTopic(ClientProxyConstants.VALUE_RECEIVE_FROM_GFX_API_TOPIC, new GfxAPIListener());
    }

    @Override
    public void start() {
    	if (isRunningAsArb) {
    		arbFillRatioPublisher.start();
    	} else if (isRunningAsEcom) {
    		ecomFillRatioPublisher.start();
    	}

        if (serverProxyReceiver != null) {
            serverProxyReceiver.start();
        }
        
        if (gfxClientReceiver != null) {
        	gfxClientReceiver.start();
        }
    }

	@Override
    public void stop() {
        if (serverProxyReceiver != null) {
            serverProxyReceiver.stop();
        }
        
        if (gfxClientReceiver != null) {
        	gfxClientReceiver.stop();
        }
    }

    @Override
    public void sendToServerProxy(byte[] bytes) {
        serverProxySender.send(bytes);
    }
    
    @Override
    public void sendToGFXClient(byte[] bytes) {
    	gfxClientSender.send(bytes);
    }

    private ValueDate mergeValueDates(ValueDate newDate, ValueDate oldDate) {
        if (newDate.getTradeDate() != null && newDate.getTradeDate().length() > 0) {
            oldDate.setTradeDate(newDate.getTradeDate());
        }
        if (newDate.getValueDate() != null && newDate.getValueDate().length() > 0) {
            oldDate.setValueDate(newDate.getValueDate());
        }
        return oldDate;
    }
    
	class ServerProxyListener implements MessageListener {

        private DefaultMessageDecoder decoder = new DefaultMessageDecoder();

        @Override
        public void onMessage(byte[] bytes) {
            switch (bytes[0]) {
            case MessageType.CURRENCY_DATES:
                ValueDate newDate = MessageToCacheConverter.convert((CurrencyDates) decoder.decode(bytes));
                ValueDate oldDate = cacheService.getValueDate(newDate.getCurrencyPair().toString());

                if (oldDate != null) {
                    newDate = mergeValueDates(newDate, oldDate);
                }

                cacheService.saveValueDate(newDate);
                break;

            case MessageType.USD_EQUIVALENT_POSITION_INFO:
                UsdEquivalentPositionInfo positionInfo = (UsdEquivalentPositionInfo) decoder.decode(bytes);
                cacheService.saveTotalPnl(positionInfo.getPnL());
                // cacheService.saveGrossAggregatePosition(positionInfo.getGrossAggregatePosition());
                break;
                
            case MessageType.POSITION_VO:
            	PositionVo positions = (PositionVo) decoder.decode(bytes);

            	for (Currency currency : positions.getCurrencies()) {
            		cacheService.savePositionEcom(MessageToCacheConverter.convert(positions, currency));
            	}
            	break;

            case MessageType.TRANSACTION_REQUEST:
                Transaction transaction = MessageToCacheConverter.convert((TransactionRequest) decoder.decode(bytes));
                if (isRunningAsArb) {
                	ArbStatisticsUtil.getInstance().addTransaction(transaction);
                } else if (isRunningAsEcom) {
                	EcomStatisticsUtil.getInstance().addTransaction(transaction);
                }
                cacheService.saveTransaction(transaction);
                break;
                
            case MessageType.JVM_STATUS:
            	JVMStatus jvmStatus = (JVMStatus) decoder.decode(bytes);
                cacheService.saveJvmStatus(MessageToCacheConverter.convert(jvmStatus));
                
                if (!ClientProxyUtil.isMacroApplied(jvmStatus.getReason())) {
                	gfxClientSender.send(getGlobalJVMStatus().toBytes());
                }
                break;

            case MessageType.STRATEGY_STATE:
                cacheService.saveStrategyStatus(MessageToCacheConverter.convert((StrategyState) decoder.decode(bytes)));
                break;
                
            case MessageType.CONFIGURATION:
            	cacheService.saveCofiguration(MessageToCacheConverter.convert((Configuration) decoder.decode(bytes)));
            	break;
            	
            case MessageType.TRESHOLD_STRATEGY:
            	cacheService.saveThresholdStrategy(MessageToCacheConverter.convert((ThresholdStrategy) decoder.decode(bytes)));
            	break;

            case MessageType.CURRENCY_PAIR_RATE_DISPLAY:
            	cacheService.saveMarketSnapshot(MessageToCacheConverter.convert((CurrencyPairRateDisplay) decoder.decode(bytes)));
            	break;
            	
            case MessageType.BUFFET_TRADE:
            	BuffetTrade buffetTrade = (BuffetTrade) decoder.decode(bytes);
            	cacheService.saveBuffetTrade(MessageToCacheConverter.convert(buffetTrade));
            	if (buffetTrade.isAckNeededBySource()) {
            		gfxClientSender.send(bytes);
            	}
            	break;
            	
            case MessageType.ORDER_FILL:
            	cacheService.saveOrderFill(MessageToCacheConverter.convert((OrderFill) decoder.decode(bytes)));
            	gfxClientSender.send(bytes);
            	break;
            	
            case MessageType.POSITION_TRANSFER:
                cacheService.savePositionTransfer(MessageToCacheConverter.convert((PositionTransfer) decoder.decode(bytes)));
                break;
                
            default:
                break;
            }
        }
	}
	
	private AFXStatus getGlobalJVMStatus() {
		JvmStatus jvmStatus = cacheService.getGlobalJVMStatus();
		AFXStatus afxStatus = new AFXStatus();
    	
		if (jvmStatus == null || jvmStatus.getJvmStatus().equals(JVMStatusEnum.DOWN)) {
    		afxStatus.setResendStatusEvenIfSame(true);
    		afxStatus.setAfxStatusEnum(AFXStatusEnum.DOWN);
    	} else if (jvmStatus.getJvmStatus().equals(JVMStatusEnum.UP)) {
    		afxStatus.setResendStatusEvenIfSame(jvmStatus.isResendStatusEvenIfSame());
    		afxStatus.setAfxStatusEnum(AFXStatusEnum.UP);
    	} else if (jvmStatus.getJvmStatus().equals(JVMStatusEnum.STANDBY)) {
    		afxStatus.setResendStatusEvenIfSame(jvmStatus.isResendStatusEvenIfSame());
    		afxStatus.setAfxStatusEnum(AFXStatusEnum.STANDBY);
    	} else if (jvmStatus.getJvmStatus().equals(JVMStatusEnum.RUNNING)) {
    		afxStatus.setResendStatusEvenIfSame(jvmStatus.isResendStatusEvenIfSame());
    		afxStatus.setAfxStatusEnum(AFXStatusEnum.RUNNING);
    	}
		
		return afxStatus;
	}

    class ServerProxyConnectionListener implements LBMSourceEventCallback {

        @Override
        public int onSourceEvent(Object obj, LBMSourceEvent event) {
            JvmStatus jvmStatus = null;
            switch (event.type()) {
            case LBM.SRC_EVENT_DISCONNECT:
            	currentNumberOfReceiversServerProxy.decrementAndGet();
            	jvmStatus = new JvmStatus();
                jvmStatus.setComponentName(ComponentName.SERVER_PROXY);
                jvmStatus.setJvmStatus(JVMStatusEnum.DOWN);
                jvmStatus.setReason("Server Proxy Disconnected to Client Proxy");
                cacheService.saveJvmStatus(jvmStatus);
                logger.debug("[" + currentNumberOfReceiversServerProxy + "] Receiver DISCONNECTED on Topic " + CommonConstants.CONST_SEND_TO_SERVER_PROXY_TOPIC + " [" + event.dataString() + "]");
                // Clear status cache if Server proxy disconnects
                cacheService.clearJVMCache();
                new sendGlobalAFXStatusToGFX().start();
                break;
            case LBM.SRC_EVENT_CONNECT:
            	currentNumberOfReceiversServerProxy.incrementAndGet();
            	jvmStatus = new JvmStatus();
                jvmStatus.setComponentName(ComponentName.SERVER_PROXY);
                jvmStatus.setJvmStatus(JVMStatusEnum.RUNNING);
                jvmStatus.setReason("Server Proxy Connected to Client Proxy");
                cacheService.saveJvmStatus(jvmStatus);
                logger.debug("[" + currentNumberOfReceiversServerProxy + "] Receiver CONNECTED on Topic " + CommonConstants.CONST_SEND_TO_SERVER_PROXY_TOPIC + " [" + event.dataString() + "]");
                break;
            default:
                break;
            }
            return 0;
        }
    }
    
    class GfxAPIListener implements MessageListener {

        @Override
        public void onMessage(byte[] bytes) {
        	switch (bytes[0]) {
	            case MessageType.BUFFET_TRADE:
	            	sendToServerProxy(bytes);
	            	break;
	            case MessageType.AMENDED_BUFFET_TRADES:
	            	sendToServerProxy(bytes);
	            	break;
	            case MessageType.POSITION_TRANSFER:
	            	sendToServerProxy(bytes);
	            	break;
	            case MessageType.USER_CONTROL_MESSAGE:
	            	sendToServerProxy(bytes);
	            	break;
	            default:
	            	logger.debug("Unknown message type received from GFX");
	            	break;
        	}
        }
    }

    class GfxAPIConnectionListener implements LBMSourceEventCallback {

        @Override
        public int onSourceEvent(Object obj, LBMSourceEvent event) {
        	JvmStatus jvmStatus = null;
            switch (event.type()) {
            case LBM.SRC_EVENT_DISCONNECT:
            	currentNumberOfReceiversGFXApi.decrementAndGet();
            	jvmStatus = new JvmStatus();
            	jvmStatus.setComponentName(ComponentName.GFX_API);
                jvmStatus.setJvmStatus(JVMStatusEnum.DOWN);
                jvmStatus.setReason("Buffet Disconnected from Client Proxy");
                cacheService.saveJvmStatus(jvmStatus);
                logger.debug("[" + currentNumberOfReceiversGFXApi + "] Receiver DISCONNECTED on Topic " + ClientProxyConstants.VALUE_SEND_TO_GFX_API_TOPIC + " [" + event.dataString() + "]");
                new sendUserControlMsgToPM().start(UserControlMessageEnum.PAUSE, jvmStatus.getReason());
                break;
            case LBM.SRC_EVENT_CONNECT:
            	currentNumberOfReceiversGFXApi.incrementAndGet();
            	jvmStatus = new JvmStatus();
            	jvmStatus.setComponentName(ComponentName.GFX_API);
                jvmStatus.setJvmStatus(JVMStatusEnum.RUNNING);
                jvmStatus.setReason("Buffet Connected to Client Proxy");
                cacheService.saveJvmStatus(jvmStatus);
                logger.debug("[" + currentNumberOfReceiversGFXApi + "] Receiver CONNECTED on Topic " + ClientProxyConstants.VALUE_SEND_TO_GFX_API_TOPIC + " [" + event.dataString() + "]");
                new sendGlobalAFXStatusToGFX().start();
                break;
            default:
            	logger.debug("Unknown Event, type =  " + event.type());
            	break;
            }
            
            return 0;
        }
    }

    class ArbFillRatioPublisher extends AFXThread {
        public void run() {
            while (true) {
                if (ArbStatisticsUtil.getInstance().isModified()) {
                    synchronized (ArbStatisticsUtil.getInstance()) {
                        cacheService.saveStrategyStatistics(CommonConstants.CONST_STRATEGY_STATISTICS, ArbStatisticsUtil.getInstance().getStrategyStatistics());
                        cacheService.saveCurrencyPairStatistics(CommonConstants.CONST_CURRENCY_PAIR_STATISTICS, ArbStatisticsUtil.getInstance().getCurrencyPairStatistics());
                        ArbStatisticsUtil.getInstance().setModified(false);
                    }
                }
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }
    
    class EcomFillRatioPublisher extends AFXThread {
    	public void run() {
    		while (true) {
                if (EcomStatisticsUtil.getInstance().isModified()) {
                    synchronized (EcomStatisticsUtil.getInstance()) {
                        cacheService.saveCurrencyPairStatistics(CommonConstants.CONST_CURRENCY_PAIR_STATISTICS, EcomStatisticsUtil.getInstance().getCurrencyPairStatistics());
                        EcomStatisticsUtil.getInstance().setModified(false);
                    }
                }
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
    	}
    }
    
    class sendGlobalAFXStatusToGFX implements Runnable {
        private AFXThread thread;

        public void start() {
            thread = new AFXThread(this);
            thread.start();
        }
		@Override
		public void run() {
			gfxClientSender.send(getGlobalJVMStatus().toBytes());
		}
    }
    
    class sendUserControlMsgToPM implements Runnable {
        private AFXThread thread;
        UserControlMessage userControlMessage;

        public void start(UserControlMessageEnum scm, String reason) {
        	userControlMessage = new UserControlMessage();
        	userControlMessage.setUserControlMessage(scm);
    		userControlMessage.setReason(reason);
    		userControlMessage.setUserAttentionNeeded(true);
    		userControlMessage.setUserId("BUFFET");
        	
            thread = new AFXThread(this);
            thread.start();
        }
		@Override
		public void run() {
    		sendToServerProxy(userControlMessage.toBytes());
		}
    }
}
