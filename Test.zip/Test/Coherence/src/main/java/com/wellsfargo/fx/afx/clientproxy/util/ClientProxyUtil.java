package com.wellsfargo.fx.afx.clientproxy.util;

import com.wellsfargo.fx.afx.common.util.CommonConstants;

public class ClientProxyUtil {
	
	public static boolean isMacroApplied(String reason) {
		return reason.equalsIgnoreCase(CommonConstants.CONST_PAUSING_AFX_MACRO_RECEIVED) || reason.contains(CommonConstants.CONST_RESTARTING_AFX_MACRO_APPLIED_BY);
	}

}
