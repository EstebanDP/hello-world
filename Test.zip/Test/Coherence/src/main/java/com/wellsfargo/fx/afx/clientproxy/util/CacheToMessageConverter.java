package com.wellsfargo.fx.afx.clientproxy.util;

import java.util.ArrayList;
import java.util.List;

import com.wellsfargo.fx.afx.common.log.Logger;
import com.wellsfargo.fx.afx.common.log.impl.LoggerFactory;
import com.wellsfargo.fx.afx.common.log.utils.LoggerConstants;
import com.wellsfargo.fx.afx.common.valueobject.Configuration;
import com.wellsfargo.fx.afx.common.valueobject.CurrencyPair;
import com.wellsfargo.fx.afx.common.valueobject.UserControlMessage;
import com.wellsfargo.fx.afx.ecom.common.valueobject.ThresholdStrategy;
import com.wellsfargo.fx.afx.ecom.common.valueobject.CurrencyPairThresholdsConfig;
import com.wellsfargo.fx.afx.ecom.common.valueobject.buffet.BuffetTradeDetailInquiry;

public class CacheToMessageConverter {

    private static final Logger logger = LoggerFactory.getLogger(LoggerConstants.CLIENT_PROXY);

    public static Configuration convert(com.wellsfargo.fx.afx.common.valueobject.coherence.Configuration configurationVO) {
    	Configuration configuration = new Configuration();
    	configuration.setComponentName(configurationVO.getComponentName());
    	configuration.setConfigType(configurationVO.getConfigType());
    	configuration.setConfigurationName(configurationVO.getConfigurationName());
    	configuration.setConfigurationValue(configurationVO.getConfigurationValue());
    	configuration.setUserName(configurationVO.getUserName());
    	configuration.setUpdateDate(configurationVO.getUpdateDate());
    	configuration.setDescription(configurationVO.getDescription());
    	configuration.setSaveToDatabase(configurationVO.isSaveToDatabase());
    
        logger.debug("User-->Server (configuration) " + configuration.getComponentName() + " : " + configuration.toString());
        return configuration;
    }
    
    public static BuffetTradeDetailInquiry convert(com.wellsfargo.fx.afx.common.valueobject.coherence.BuffetTradeDetailInquiry coherenceBuffetTradeDetailInquiry) {
    	BuffetTradeDetailInquiry buffetTradeDetailInquiry = new BuffetTradeDetailInquiry();
    	buffetTradeDetailInquiry.setUserId(coherenceBuffetTradeDetailInquiry.getUserId());
    	buffetTradeDetailInquiry.setDomain(coherenceBuffetTradeDetailInquiry.getDomain());
    	buffetTradeDetailInquiry.setBuffetTradeId(coherenceBuffetTradeDetailInquiry.getBuffetTradeId());
    	buffetTradeDetailInquiry.setRequestTime(coherenceBuffetTradeDetailInquiry.getRequestTime());
    	
    	return buffetTradeDetailInquiry;
    }

   public static UserControlMessage convert(com.wellsfargo.fx.afx.common.valueobject.coherence.UserControlMessage coherenceUserControlMessage) {
	   UserControlMessage userControlMessage = new UserControlMessage();
	   userControlMessage.setUserControlMessage(coherenceUserControlMessage.getUserControlMessage());
	   userControlMessage.setReason(coherenceUserControlMessage.getReason());
	   userControlMessage.setForcePause(coherenceUserControlMessage.isForcePause());
	   userControlMessage.setUserAttentionNeeded(coherenceUserControlMessage.isUserAttentionNeeded());
	   userControlMessage.setUserId(coherenceUserControlMessage.getUserId());

	   logger.debug("User-->Server (UserControlMessage) " + userControlMessage.toString());
	   return userControlMessage;
   }

	public static ThresholdStrategy convert(com.wellsfargo.fx.afx.common.valueobject.coherence.ThresholdStrategy coherenceThresholdStrategy) {
		ThresholdStrategy thresholdStrategy = new ThresholdStrategy();
		
		thresholdStrategy.setStrategyName(coherenceThresholdStrategy.getStrategyName());
		thresholdStrategy.setAppliedByUser(coherenceThresholdStrategy.getAppliedByUser());
		thresholdStrategy.setUpdateUser(coherenceThresholdStrategy.getUpdateUser());
		thresholdStrategy.setActiveStrategy(coherenceThresholdStrategy.isActiveStrategy());
		thresholdStrategy.setUpdateCache(coherenceThresholdStrategy.isUpdateCache());
		thresholdStrategy.setDeletable(coherenceThresholdStrategy.isDeletable());
		thresholdStrategy.setUpdateDate(coherenceThresholdStrategy.getUpdateDate());
		thresholdStrategy.setNotes(coherenceThresholdStrategy.getNotes());
		
		List<CurrencyPairThresholdsConfig> currencyPairThresholdsConfigList = new ArrayList<CurrencyPairThresholdsConfig>();
		
		for (com.wellsfargo.fx.afx.common.valueobject.coherence.CurrencyPairThresholdsConfig coherenceCurrencyPairThresholdsConfig 
				: coherenceThresholdStrategy.getCcyPairThresholdsConfig()) {
			CurrencyPairThresholdsConfig currencyPairThresholdsConfig = new CurrencyPairThresholdsConfig();
			currencyPairThresholdsConfig.setEnabled(coherenceCurrencyPairThresholdsConfig.isEnabled());
			currencyPairThresholdsConfig.setUserName(coherenceCurrencyPairThresholdsConfig.getUserName());
			currencyPairThresholdsConfig.setCurrencyPair(CurrencyPair.valueOf(coherenceCurrencyPairThresholdsConfig.getCurrencyPair()));
			currencyPairThresholdsConfig.setShortThreshold(coherenceCurrencyPairThresholdsConfig.getShortThreshold());
			currencyPairThresholdsConfig.setLongThreshold(coherenceCurrencyPairThresholdsConfig.getLongThreshold());
	
			currencyPairThresholdsConfigList.add(currencyPairThresholdsConfig);
		}
		
		thresholdStrategy.setCcyPairThresholdsConfig(currencyPairThresholdsConfigList);
			
		return thresholdStrategy;
	}
}
