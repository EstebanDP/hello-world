package com.wellsfargo.fx.afx.clientproxy.service;

import java.util.List;

import com.wellsfargo.fx.afx.common.valueobject.coherence.Configuration;
import com.wellsfargo.fx.afx.common.valueobject.coherence.Transaction;
import com.wellsfargo.fx.afx.common.valueobject.coherence.User;

public interface ArbDataPersistenceService extends BaseDataPersistenceService {

    public void insertConfiguration(Configuration configuration);
    
    public void updateConfiguration(Configuration configuration);
    
    public void saveTransaction(Transaction transaction);
    
    public Transaction loadTransaction(String key);
    
    public List<Configuration> getConfigurations(String componentName, String location);
    
    public List<User> getUsers();
    
}
