package com.wellsfargo.fx.afx.clientproxy.manager;

import com.wellsfargo.fx.afx.common.valueobject.coherence.Transaction;

public interface TransactionPersistenceManager {
	
	public void ensureIndex();
	
	public void saveTransaction(Transaction transaction);
	
	public Transaction loadTransaction(String key);
	
}
