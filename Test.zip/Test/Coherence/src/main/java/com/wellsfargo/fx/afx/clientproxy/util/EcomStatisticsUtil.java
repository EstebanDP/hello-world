package com.wellsfargo.fx.afx.clientproxy.util;

import com.wellsfargo.fx.afx.common.valueobject.OrderStatus;
import com.wellsfargo.fx.afx.common.valueobject.coherence.CurrencyPairStatistics;
import com.wellsfargo.fx.afx.common.valueobject.coherence.Transaction;

public class EcomStatisticsUtil {

    private static EcomStatisticsUtil self;

    private CurrencyPairStatistics currencyPairStats;
    private boolean modified;

    static {
        self = new EcomStatisticsUtil();
    }

    public static EcomStatisticsUtil getInstance() {
        return self;
    }

    private EcomStatisticsUtil() {
        currencyPairStats = new CurrencyPairStatistics();
    }

    public void addTransaction(Transaction transaction) {
        synchronized (this) {
            modified = true;

            for (Transaction.Order order : transaction.getOrders()) {
                String currencyPair = order.getCurrencyPair();
                currencyPairStats.incrementOrderTotal(currencyPair, 1);
                OrderStatus orderStatus = order.getOrderStatus();
                if (orderStatus == OrderStatus.FILLED) {
                    currencyPairStats.incrementOrderFilled(currencyPair, 1);
                } else if (orderStatus == OrderStatus.CANCELLED) {
                    currencyPairStats.incrementOrderCancelled(currencyPair, 1);
                } else if (orderStatus == OrderStatus.PARTIALLY_FILLED) {
                    currencyPairStats.incrementOrderPartiallyFilled(currencyPair, 1);
                } else if (orderStatus == OrderStatus.REJECTED_BECAUSE_OF_LATENCY_LIMIT) {
                    currencyPairStats.incrementOrderRejectedByLatency(currencyPair, 1);
                } else if (orderStatus == OrderStatus.REJECTED_BECAUSE_THROUGHPUT_LIMIT_REACHED) {
                    currencyPairStats.incrementOrderRejectedByThroughput(currencyPair, 1);
                } else if (orderStatus == OrderStatus.REJECTED_BY_EXCHANGE) {
                    currencyPairStats.incrementOrderRejectedByExchange(currencyPair, 1);
                } else if (orderStatus == OrderStatus.REJECTED_INTERNAL_VALIDATION) {
                    currencyPairStats.incrementOrderRejectedByValidation(currencyPair, 1);
                }
            }
        }
    }

    public CurrencyPairStatistics getCurrencyPairStatistics() {
        return currencyPairStats;
    }

    public boolean isModified() {
        return modified;
    }

    public void setModified(boolean modified) {
        this.modified = modified;
    }

    public void resetStatistics() {
        currencyPairStats = new CurrencyPairStatistics();
    }
}
