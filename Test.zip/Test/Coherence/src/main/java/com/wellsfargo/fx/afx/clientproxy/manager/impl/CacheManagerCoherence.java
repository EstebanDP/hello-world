package com.wellsfargo.fx.afx.clientproxy.manager.impl;

import java.util.Date;
import java.util.concurrent.atomic.AtomicInteger;

import com.tangosol.coherence.component.util.SafeService;
import com.tangosol.coherence.component.util.daemon.queueProcessor.service.grid.ProxyService;
import com.tangosol.net.CacheFactory;
import com.tangosol.net.DefaultCacheServer;
import com.tangosol.net.Service;
import com.wellsfargo.fx.afx.clientproxy.manager.CacheManager;
import com.wellsfargo.fx.afx.clientproxy.service.MessageP2PService;
import com.wellsfargo.fx.afx.clientproxy.util.CacheUtils;
import com.wellsfargo.fx.afx.clientproxy.util.ProxyConnectionListener;
import com.wellsfargo.fx.afx.common.log.Logger;
import com.wellsfargo.fx.afx.common.log.impl.LoggerFactory;
import com.wellsfargo.fx.afx.common.log.utils.LoggerConstants;
import com.wellsfargo.fx.afx.common.util.CommonConstants;
import com.wellsfargo.fx.afx.common.util.ConfigurationLoader;
import com.wellsfargo.fx.afx.common.valueobject.ComponentName;
import com.wellsfargo.fx.afx.common.valueobject.JVMStatusEnum;
import com.wellsfargo.fx.afx.common.valueobject.coherence.JvmStatus;
import com.wellsfargo.fx.afx.common.valueobject.coherence.MonitorMessage;

public class CacheManagerCoherence implements CacheManager {

    private static final Logger logger = LoggerFactory.getLogger(LoggerConstants.CLIENT_PROXY);
    private static final String ENV = ConfigurationLoader.getInstance().getString("ENV");

    private MessageP2PService messageP2PService;

    static private AtomicInteger initialPositionReceivedCounter;
    static private AtomicInteger amendmentsReceivedCounter;
    static private AtomicInteger cancellationsReceivedCounter;
    static private AtomicInteger repairqReceivedCounter;
    static private AtomicInteger positionTransferReceivedCounter;
    static private AtomicInteger duplicateTradeReceivedCounter;
    static private AtomicInteger rejectedReceivedCounter;
    static private AtomicInteger monitorMessageCounter;
    
    //private NamedCache buffetTradeDetailInquiryCache;
    
    public CacheManagerCoherence() {
    	initializeCoherenceSystemProperties();
    	DefaultCacheServer.start();
    	
       	//Sometimes there are leftover GUIs from previous session still running before Client Proxy re-starts.
    	CacheFactory.ensureCluster();

    	ProxyService proxyService;
    	Service service = CacheFactory.getService("ExtendTcpProxyService");
    	if (service instanceof SafeService) {
    	    proxyService = (ProxyService) ((SafeService)service).getService();
    	} else {
    	    proxyService = (ProxyService) service;
    	}
    	
    	ProxyConnectionListener proxyConnectionListener = new ProxyConnectionListener();
    	ProxyConnectionListener.setLiveGUICounts(proxyService.getServiceLoad().getConnectionCount());
    	proxyService.getAcceptor().addConnectionListener(proxyConnectionListener);

    	initialPositionReceivedCounter = new AtomicInteger(0);
    	amendmentsReceivedCounter = new AtomicInteger(0);
    	cancellationsReceivedCounter =  new AtomicInteger(0);
    	repairqReceivedCounter =  new AtomicInteger(0);
    	positionTransferReceivedCounter = new AtomicInteger(0);
    	duplicateTradeReceivedCounter = new AtomicInteger(0);
    	rejectedReceivedCounter = new AtomicInteger(0);
    	monitorMessageCounter = new AtomicInteger(0);
    	
        loadInitConfigurationAndStrategies();

        // Save the Client Proxy initial state
        JvmStatus jvmStatus = new JvmStatus(ComponentName.CLIENT_PROXY, JVMStatusEnum.RUNNING);
        jvmStatus.setReason("Coherence Cache is Available");
        saveJvmStatus(jvmStatus);
    }
    
    private void initializeCoherenceSystemProperties() {
    	System.setProperty(CommonConstants.COHERENCE_EXTEND_ADDRESS, ConfigurationLoader.getInstance().getString(CommonConstants.COHERENCE_EXTEND_ADDRESS));
    	System.setProperty(CommonConstants.COHERENCE_EXTEND_PORT, ConfigurationLoader.getInstance().getString(CommonConstants.COHERENCE_EXTEND_PORT));
	}

	private void loadInitConfigurationAndStrategies() {
    	CacheUtils.getInstance().loadInitConfigurationAndStrategies();
	}

	@Override
    public void registerCacheListener() {

    }

    @Override
    public void unregisterCacheListener() {

    }
    
    @Override
    public void destroy() {
    	CacheFactory.shutdown();
    }
}
