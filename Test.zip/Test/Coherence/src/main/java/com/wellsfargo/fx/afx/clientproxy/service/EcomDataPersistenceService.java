package com.wellsfargo.fx.afx.clientproxy.service;

import com.wellsfargo.fx.afx.common.valueobject.coherence.BuffetTrade;
import com.wellsfargo.fx.afx.common.valueobject.coherence.OrderFill;
import com.wellsfargo.fx.afx.common.valueobject.coherence.Transaction;


public interface EcomDataPersistenceService extends BaseDataPersistenceService {

	public void saveTransaction(Transaction transaction);
	
	public void saveOrderFill(OrderFill orderFill);
	
	public void saveBuffetTransaction(BuffetTrade buffetTransaction);
}
