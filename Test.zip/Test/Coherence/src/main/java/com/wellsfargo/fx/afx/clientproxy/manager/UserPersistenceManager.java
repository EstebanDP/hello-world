package com.wellsfargo.fx.afx.clientproxy.manager;

import java.util.List;

import com.wellsfargo.fx.afx.common.valueobject.coherence.User;

public interface UserPersistenceManager {
	
	public List<User> getUsers();

}
