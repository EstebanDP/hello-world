package com.wellsfargo.fx.afx.clientproxy.service;

import java.math.BigDecimal;

import com.wellsfargo.fx.afx.common.valueobject.coherence.BuffetTrade;
import com.wellsfargo.fx.afx.common.valueobject.coherence.Configuration;
import com.wellsfargo.fx.afx.common.valueobject.coherence.CurrencyPairStatistics;
import com.wellsfargo.fx.afx.common.valueobject.coherence.ThresholdStrategy;
import com.wellsfargo.fx.afx.common.valueobject.coherence.JvmStatus;
import com.wellsfargo.fx.afx.common.valueobject.coherence.MarketSnapshot;
import com.wellsfargo.fx.afx.common.valueobject.coherence.OrderFill;
import com.wellsfargo.fx.afx.common.valueobject.coherence.PositionEcom;
import com.wellsfargo.fx.afx.common.valueobject.coherence.PositionTransfer;
import com.wellsfargo.fx.afx.common.valueobject.coherence.StrategyStatistics;
import com.wellsfargo.fx.afx.common.valueobject.coherence.StrategyStatus;
import com.wellsfargo.fx.afx.common.valueobject.coherence.Transaction;
import com.wellsfargo.fx.afx.common.valueobject.coherence.ValueDate;

public interface CacheService {

    public void start();

    public void stop();

    public void saveValueDate(ValueDate valueDate);

    public ValueDate getValueDate(String ccyPair);

    public void savePositionEcom(PositionEcom positionEcom);

    public void saveTransaction(Transaction transaction);

    public void saveTotalPnl(BigDecimal pnl);

    public void saveGrossAggregatePosition(BigDecimal combinedPosition);

    public void saveJvmStatus(JvmStatus status);

    public void saveStrategyStatus(StrategyStatus status);
    
    public void saveMarketSnapshot(MarketSnapshot marketSnapshot);
    
    public void saveBuffetTrade(BuffetTrade buffetTrade);
    
    public void saveOrderFill(OrderFill orderFill);
    
    public void savePositionTransfer(PositionTransfer positionTransfer);
    
    public void saveCofiguration(Configuration configuration);

    public void saveStrategyStatistics(String id, StrategyStatistics strategyStats);

    public void saveCurrencyPairStatistics(String id, CurrencyPairStatistics currencyPairStats);
    
    public void resetCaches();

    public void setDataPersistenceService(BaseDataPersistenceService dataPersistenceService);

    public void setMessageP2PService(MessageP2PService messageP2PService);
    
    public JvmStatus getGlobalJVMStatus();
    
    public void clearJVMCache();

	public void saveThresholdStrategy(ThresholdStrategy thresholdStrategy);
}
