#!/bin/bash

cd ClientProxy
args=("$@")
log_level="-Dlogging.level=debug"
optional_jvm_args="-DENV=${args[0]} -Dtangosol.coherence.override=./environment/tangosol-coherence-override.xml -Dtangosol.coherence.management=all -Dtangosol.coherence.management.remote=true -Dcom.sun.management.jmxremote -Dcom.sun.management.jmxremote.authenticate=false -Dcom.sun.management.jmxremote.ssl=false -Dcom.sun.management.jmxremote.port=9999 -Dcomponent.name=CLIENT_PROXY -DverifyNumberOfVariablesToLoad=32"
java_path="/apps/afxecom/java/jdk1.6.0_20/jre/bin"

today=$(date +"%Y%m%d_%H%M%S")
stdoutPath="./Logs/"

if [ ! -d $stdoutPath ]
then
	mkdir $stdoutPath
fi

echo "Copying "${args[0]}" property files..."
cp environment/${args[0]}/* environment/.

echo "Starting Client Proxy..."

#taskset -c 3 $java_path/java ${args[1]} ${args[2]} ${args[3]} ${args[4]} ${args[5]} ${args[6]} $optional_jvm_args $log_level -jar ClientProxy.jar >& cp_stdout.txt &
$java_path/java ${args[1]} ${args[2]} ${args[3]} ${args[4]} ${args[5]} ${args[6]} ${args[7]} ${args[8]} ${args[9]} $optional_jvm_args $log_level -jar ClientProxy.jar >& $stdoutPath/cp_stdout_$today.txt &
