#!/bin/bash

ps -ef | grep CNXMarketDataGateway | awk '{print $2}' | xargs kill -9
ps -ef | grep CNXOrderRoutingGateway | awk '{print $2}' | xargs kill -9
ps -ef | grep IntegralMarketDataGateway | awk '{print $2}' | xargs kill -9
ps -ef | grep IntegralOrderRoutingGateway | awk '{print $2}' | xargs kill -9
#ps -ef | grep PositionManagerEcom | awk '{print $2}' | xargs kill -9
#ps -ef | grep ServerProxy | awk '{print $2}' | xargs kill -9
ps -ef | grep ClientProxy | awk '{print $2}' | xargs kill -9

