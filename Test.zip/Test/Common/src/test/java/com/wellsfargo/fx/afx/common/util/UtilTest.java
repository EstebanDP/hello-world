package com.wellsfargo.fx.afx.common.util;

import junit.framework.Assert;

import org.junit.Test;

public class UtilTest {

	@Test
	public void testWriteLongToByteArray() {
		long value = 1234567890123456L;
		byte[] bytes = new byte[8];
		int pos = Util.writeLongToByteArray(value, bytes, 0);
		Assert.assertEquals(8, pos);

		long readValue = Util.readLongFromBytes(bytes, 0);

		Assert.assertEquals(value, readValue);
	}

	@Test
	public void testWriteIntToByteArray() {
		int value = 123456789;
		byte[] bytes = new byte[4];
		int pos = Util.writeIntToByteArray(value, bytes, 0);
		Assert.assertEquals(4, pos);

		int readValue = Util.readIntFromBytes(bytes, 0);

		Assert.assertEquals(value, readValue);
	}

	@Test
	public void testWriteStringToByteArray() {
		String s = "abcdfdfdrerer";
		byte[] bytes = new byte[s.length() + 1];
		int pos = Util.writeStringToByteArray(s, bytes, 0);
		Assert.assertEquals(s.length() + 1, pos);

		String readString = Util.readStringFromBytes(bytes, bytes[0], 1);
		Assert.assertEquals(s, readString);
	}

	@Test
	public void testWriteFloatToByteArray() {
		float value = 1234.56789012f;
		byte[] bytes = new byte[4];
		int pos = Util.writeFloatToByteArray(value, bytes, 0);
		Assert.assertEquals(4, pos);

		float readValue = Util.readFloatFromBytes(bytes, 0);

		Assert.assertEquals(value, readValue);
	}

}
