package com.wellsfargo.fx.afx.common.messaging;

public interface EOSMessageListener extends MessageListener {
	
	public void onEOSMessage(byte[] bytes);
}
