package com.wellsfargo.fx.afx.ecom.common.valueobject.buffet;

import java.io.ByteArrayOutputStream;

import com.wellsfargo.fx.afx.common.util.Util;
import com.wellsfargo.fx.afx.common.valueobject.DefaultMessageDecoder;
import com.wellsfargo.fx.afx.common.valueobject.MessageType;
import com.wellsfargo.fx.afx.common.valueobject.ValueObject;

public class AmendedBuffetTrades extends ValueObject {
    private static final byte messageType = MessageType.AMENDED_BUFFET_TRADES;
    private static final byte version = 1;

    private DefaultMessageDecoder defaultMessageDecoder = new DefaultMessageDecoder();
    private BuffetTrade originalBuffetTrade;
    private BuffetTrade amendedBuffetTrade;
    
    @Override
    public int readFrom(byte[] bytes) {
        int pos = 2;
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        
        int length = (int) Util.readFloatFromBytes(bytes, pos);
        pos += 4;
        byteArrayOutputStream.write(bytes, pos, length);
        originalBuffetTrade = (BuffetTrade) defaultMessageDecoder.decode(byteArrayOutputStream.toByteArray());
        pos = length + pos;

        length = (int) Util.readFloatFromBytes(bytes, pos);
        pos += 4;
        
        byteArrayOutputStream = new ByteArrayOutputStream();
        byteArrayOutputStream.write(bytes, pos, length);
        amendedBuffetTrade = (BuffetTrade) defaultMessageDecoder.decode(byteArrayOutputStream.toByteArray());
        pos = length + pos;
        
        return pos;
    }
    
	public void setOriginalBuffetTrade(BuffetTrade originalBuffetTrade) {
		this.originalBuffetTrade = originalBuffetTrade;
	}

	public BuffetTrade getOriginalBuffetTrade() {
		return originalBuffetTrade;
	}

	public void setAmendedBuffetTrade(BuffetTrade amendedBuffetTrade) {
		this.amendedBuffetTrade = amendedBuffetTrade;
	}

	public BuffetTrade getAmendedBuffetTrade() {
		return amendedBuffetTrade;
	}
	
	@Override
    public byte[] toBytes() {
		int pos = 0;
		byte[] originalBTBytes = originalBuffetTrade.toBytes();
		byte[] amendedBTBytes = amendedBuffetTrade.toBytes();
		byte[] bytes = new byte[2 + 4 + originalBTBytes.length + 4 + amendedBTBytes.length];
		
        bytes[pos++] = messageType;
        bytes[pos++] = version;
		pos = Util.writeFloatToByteArray(originalBTBytes.length, bytes, pos);
		for (int index = 0; index < originalBTBytes.length; index++) {
			bytes[pos++] = originalBTBytes[index];
		}
		
		pos = Util.writeFloatToByteArray(amendedBTBytes.length, bytes, pos);
		for (int index = 0; index < amendedBTBytes.length; index++) {
			bytes[pos++] = amendedBTBytes[index];
		}

		return bytes;
	}

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("[AmendedBuffetTrades]\n");
        sb.append("[ORIGINAL] ").append(originalBuffetTrade.toString()).append('\n');
        sb.append("[AMENDED]  ").append(amendedBuffetTrade.toString());

        return sb.toString();
    }
}