package com.wellsfargo.fx.afx.common.valueobject.coherence;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

@SuppressWarnings("serial")
public class ThresholdStrategy implements Serializable {
	
	private String strategyName;
	private String appliedByUser;
	private String updateUser;
	private List<CurrencyPairThresholdsConfig> ccyPairThresholdsConfig;
	private boolean activeStrategy;
	private boolean deletable;
	private boolean newStrategy;
	// To avoid loops with insertion to the cache
	private boolean updateCache;
	private Date updateDate;
	private String notes;
	
	public void setStrategyName(String strategyName) {
		this.strategyName = strategyName;
	}
	
	public String getStrategyName() {
		return strategyName;
	}
	
	public void setAppliedByUser(String appliedByUser) {
		this.appliedByUser = appliedByUser;
	}
	
	public String getAppliedByUser() {
		return appliedByUser;
	}

	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}

	public String getUpdateUser() {
		return updateUser;
	}

	public void setCcyPairThresholdsConfig(List<CurrencyPairThresholdsConfig> ccyPairThresholdsConfig) {
		this.ccyPairThresholdsConfig = ccyPairThresholdsConfig;
	}

	public List<CurrencyPairThresholdsConfig> getCcyPairThresholdsConfig() {
		return ccyPairThresholdsConfig;
	}

	public void setActiveStrategy(boolean activeStrategy) {
		this.activeStrategy = activeStrategy;
	}

	public boolean isActiveStrategy() {
		return activeStrategy;
	}

	public void setDeletable(boolean deletable) {
		this.deletable = deletable;
	}

	public boolean isDeletable() {
		return deletable;
	}
	
	public void setNewStrategy(boolean newStrategy) {
		this.newStrategy = newStrategy;
	}

	public boolean isNewStrategy() {
		return newStrategy;
	}

	public void setUpdateCache(boolean updateCache) {
		this.updateCache = updateCache;
	}

	public boolean isUpdateCache() {
		return updateCache;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	public Date getUpdateDate() {
		return updateDate;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public String getNotes() {
		return notes;
	}
	
	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("Strategy Name:").append(strategyName).append("\t");
		sb.append("Applied by User: ").append(appliedByUser).append("\t");
		sb.append("Updated by User: ").append(updateUser).append("\t");
		sb.append("Active: ").append(activeStrategy).append("\t");
		sb.append("Deletable: ").append(deletable).append("\t");
		sb.append("Date: ").append(updateDate.toString()).append("\t");
		sb.append("Notes: ").append(notes).append("\n");
		
		for (CurrencyPairThresholdsConfig currencyPairThresholdsConfig :  ccyPairThresholdsConfig) {
			sb.append(currencyPairThresholdsConfig.toString());
		}

		return sb.toString();
	}
}
