package com.wellsfargo.fx.afx.common.valueobject;

public enum JVMStatusEnum {
    DOWN, READY_TO_WARM_UP, UP, STANDBY, RUNNING;

    public static JVMStatusEnum valueOf(int ordinal) {
        if (ordinal == DOWN.ordinal()) {
            return DOWN;
        } else if (ordinal == READY_TO_WARM_UP.ordinal()) {
            return READY_TO_WARM_UP;
        } else if (ordinal == UP.ordinal()) {
            return UP;
        } else if (ordinal == STANDBY.ordinal()) {
            return STANDBY;
        } else if (ordinal == RUNNING.ordinal()) {
            return RUNNING;
        }

        return null;
    }
}