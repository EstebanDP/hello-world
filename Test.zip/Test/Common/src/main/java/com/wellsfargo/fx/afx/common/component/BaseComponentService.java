package com.wellsfargo.fx.afx.common.component;

import com.wellsfargo.fx.afx.common.valueobject.JVMStatusEnum;

public interface BaseComponentService {

    /**
     * Becomes ready for warm up after this. Status changes to "READY_FOR_WARM_UP
     */
    public void start(String reason);

    /**
     * Starts warm up
     */
    public void warmUp(String reason);

    /**
     * Cleans up after warm up. Status changes to "UP" after this
     */
    public void postWarmUp(String reason);

    /**
     * Gets ready to start. Status changes to "STAND_BY" after this
     */
    public void init(String reason);

    /**
     * Starts the process. Status changes to "RUNNING"
     */
    public void go(String reason);

    /**
     * Status changes to "DOWN"
     */
    public void stop(String reason);

    public JVMStatusEnum getJvmStatus();

    public void changeStatus(JVMStatusEnum status, String reason, boolean userAttentionNeeded, boolean resendStatusEvenIfSame);

}
