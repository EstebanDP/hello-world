package com.wellsfargo.fx.afx.ecom.common.valueobject.buffet;


public enum BuffetTradeStatus {
    NEW, AMEND, REPAIRQ, CANCELLED, REJECTED;

    public static BuffetTradeStatus valueOf(int ordinal) {
        if (ordinal == NEW.ordinal()) {
            return NEW;
        } else if (ordinal == AMEND.ordinal()) {
            return AMEND;
        } else if (ordinal == REPAIRQ.ordinal()) {
            return REPAIRQ;
        } else if (ordinal == CANCELLED.ordinal()) {
            return CANCELLED;
        } else if (ordinal == REJECTED.ordinal()) {
            return REJECTED;
        }
        return null;
    }
}
