package com.wellsfargo.fx.afx.common.component;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.wellsfargo.fx.afx.common.util.CommonConstants;
import com.wellsfargo.fx.afx.common.util.LoggerConstants;
import com.wellsfargo.fx.afx.common.valueobject.JVMStatus;
import com.wellsfargo.fx.afx.common.valueobject.JVMStatusEnum;
import com.wellsfargo.fx.afx.ecom.common.sp.ServerProxyCommunicationManagerFactory;

/**
 * This class contorls the fundamental lifecycle status of all components.
 * 
 * start() --> READY_TO_WARM_UP
 * warmUp() & postWarmUp() --> UP
 * init() --> STANDBY
 * go() --> RUNNING
 * stop() --> DOWN
 */
public abstract class AbstractComponentService implements BaseComponentService {

    private static final Logger logger = LoggerFactory.getLogger(LoggerConstants.COMMON);

    private volatile JVMStatusEnum status;

    @Override
    public final void start(String reason) {
        boolean sendStatus = doStart();
        if (sendStatus) {
            changeStatus(JVMStatusEnum.READY_TO_WARM_UP, reason != null ? reason : CommonConstants.CONST_COMPONENT_READY_WARM_UP, false, false);
        }
    }

    protected abstract boolean doStart();

    @Override
    public final void warmUp(String reason) {
        doWarmUp();
    }

    protected abstract void doWarmUp();

    @Override
    public final void postWarmUp(String reason) {
        boolean sendStatus = doPostWarmUp();
        if (sendStatus) {
            changeStatus(JVMStatusEnum.UP, reason != null ? reason : CommonConstants.CONST_COMPONENT_FINISHED_WARM_UP, false, false);
        }
    }

    protected abstract boolean doPostWarmUp();

    @Override
    public final void init(String reason) {
        boolean sendStatus = doInit();
        if (sendStatus) {
            changeStatus(JVMStatusEnum.STANDBY, reason != null ? reason : CommonConstants.CONST_COMPONENT_STANDBY, false, false);
        }
    }

    protected abstract boolean doInit();

    @Override
    public final void go(String reason) {
        boolean sendStatus = doGo();
        if (sendStatus) {
            changeStatus(JVMStatusEnum.RUNNING, reason != null ? reason : CommonConstants.CONST_COMPONENT_RUNNING, false, false);
        }
    }

    protected abstract boolean doGo();

    @Override
    public final void stop(String reason) {
        boolean sendStatus = doStop();
        if (sendStatus) {
            changeStatus(JVMStatusEnum.DOWN, reason != null ? reason : CommonConstants.CONST_COMPONENT_DOWN, true, false);
        }
    }

    protected abstract boolean doStop();

    @Override
    public final JVMStatusEnum getJvmStatus() {
        return status;
    }

    @Override
    public final synchronized void changeStatus(JVMStatusEnum status, String reason, boolean userAttentionNeeded, boolean resendStatusEvenIfSame) {
        if (this.status != status || resendStatusEvenIfSame) {
            this.status = status;
            JVMStatus jvmStatus = new JVMStatus(CommonConstants.VALUE_COMPONENT_NAME, status);
            jvmStatus.setUserAttentionNeeded(userAttentionNeeded);
            jvmStatus.setResendStatusEvenIfSame(resendStatusEvenIfSame);
            jvmStatus.setReason(reason);
            ServerProxyCommunicationManagerFactory.getServerProxyCommunicationManager().send(jvmStatus.toBytes());
            logger.debug("Sent status... " + jvmStatus.toString());
        } else {
            logger.debug("New status " + status + " is same as existing status, so no action taken in the changeStatus method.");
        }
    }
}
