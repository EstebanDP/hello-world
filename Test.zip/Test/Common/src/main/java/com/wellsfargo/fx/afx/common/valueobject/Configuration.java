package com.wellsfargo.fx.afx.common.valueobject;

import java.util.Date;

import com.wellsfargo.fx.afx.common.util.Util;

public class Configuration extends ValueObject {

	private static final byte version = 1;
	
    private ComponentName componentName;
    private String configType;
    private String configurationName;
    private String configurationValue;
    private String userName;
    private Date updateDate;
    private String description;
    private boolean saveToDatabase;

    public ComponentName getComponentName() {
        return componentName;
    }

    public void setConfigType(String configType) {
		this.configType = configType;
	}

	public String getConfigType() {
		return configType;
	}

	public void setComponentName(ComponentName componentName) {
        this.componentName = componentName;
    }

    public String getConfigurationName() {
        return configurationName;
    }

    public void setConfigurationName(String configurationName) {
        this.configurationName = configurationName;
    }

    public String getConfigurationValue() {
        return configurationValue;
    }

    public void setConfigurationValue(String configurationValue) {
        this.configurationValue = configurationValue;
    }

    public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	public Date getUpdateDate() {
		return updateDate;
	}

	public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
    
	public void setSaveToDatabase(boolean saveToDatabase) {
		this.saveToDatabase = saveToDatabase;
	}

	public boolean isSaveToDatabase() {
		return saveToDatabase;
	}

	@Override
	public byte[] toBytes() {
        int length = 1 + 1 + 1 + + 1 + configurationName.length() + 1 + configType.length() + 1 + configurationValue.length() + 1 + 1 + userName.length();
        length += 1 + description.length() + 8 + 1;
        
        byte[] bytes = new byte[length];
        int pos = 0;
        bytes[pos++] = MessageType.CONFIGURATION;
        bytes[pos++] = version;
        bytes[pos++] = (byte) componentName.ordinal();
        pos = Util.writeStringToByteArray(configurationName, bytes, pos);
        pos = Util.writeStringToByteArray(configType, bytes, pos);
        pos = Util.writeStringToByteArray(configurationValue, bytes, pos);
        bytes[pos++] = Util.booleanToByte(saveToDatabase);
        pos = Util.writeStringToByteArray(userName, bytes, pos);
        pos = Util.writeStringToByteArray(description, bytes, pos);
        pos = Util.writeLongToByteArray(updateDate.getTime(), bytes, pos);
        

        return bytes;
	}

	@Override
	public int readFrom(byte[] bytes) {
		int pos = 2; // skip type and version
    	componentName = ComponentName.valueOf(bytes[pos++]);
    	
    	int length = bytes[pos++];
    	configurationName = Util.readStringFromBytes(bytes, length, pos);
        pos += length;
        
    	length = bytes[pos++];
    	configType = Util.readStringFromBytes(bytes, length, pos);
        pos += length;
        
        length = bytes[pos++];
        configurationValue = Util.readStringFromBytes(bytes, length, pos);
        pos += length;
        
        saveToDatabase = Util.byteToBoolean(bytes[pos++]);
        
        length = bytes[pos++];
        userName = Util.readStringFromBytes(bytes, length, pos);
        pos += length;
        
        length = bytes[pos++];
        description = Util.readStringFromBytes(bytes, length, pos);
        pos += length;
        
        updateDate = new Date(Util.readLongFromBytes(bytes, pos));
        pos += 8;
        
        return pos;
	}
	
	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("Component Name: ").append(componentName.toString()).append('\n');
		sb.append("Config Type: ").append(configType.toString()).append('\n');
		sb.append("Save to Database: ").append(saveToDatabase).append('\n');
		sb.append("Configuration Name: ").append(configurationName).append('\n');
		sb.append("Configuration Value: ").append(configurationValue.toString()).append('\n');
		sb.append("User Name: ").append(userName.toString()).append('\n');
		sb.append("Update Date: ").append(updateDate.toString()).append('\n');
		sb.append("Description: ").append(description.toString());
		
		return sb.toString();
	}
}
