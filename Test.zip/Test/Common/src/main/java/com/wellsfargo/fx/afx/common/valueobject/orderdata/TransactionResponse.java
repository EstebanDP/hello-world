package com.wellsfargo.fx.afx.common.valueobject.orderdata;

import com.wellsfargo.fx.afx.common.util.Util;
import com.wellsfargo.fx.afx.common.valueobject.MessageType;
import com.wellsfargo.fx.afx.common.valueobject.ValueObject;

public class TransactionResponse extends ValueObject {
    // private static Logger log = LoggerFactory.getLogger("");

    private static final String DELIMITER = "|";
    private static final byte version = 1;
    private int strategyId;
    private int groupId;
    private TransactionStatus status;

    @Override
    public byte[] toBytes() {
        byte[] bytes = new byte[11];
        int pos = 0;
        bytes[pos++] = MessageType.TRANSACTION_RESPONSE;
        bytes[pos++] = version;
        pos = Util.writeIntToByteArray(strategyId, bytes, pos);
        pos = Util.writeIntToByteArray(groupId, bytes, pos);
        bytes[pos++] = (byte) status.ordinal();
        // log.debug(toString());
        return bytes;
    }

    @Override
    public int readFrom(byte[] bytes) {
        int pos = 2; // skip type and version
        strategyId = Util.readIntFromBytes(bytes, pos);
        pos += 4;
        groupId = Util.readIntFromBytes(bytes, pos);
        pos += 4;
        status = TransactionStatus.valueOf(bytes[pos++]);
        // log.debug(toString());
        return pos;
    }

    public int getStrategyId() {
        return strategyId;
    }

    public void setStrategyId(int strategyId) {
        this.strategyId = strategyId;
    }

    public int getGroupId() {
        return groupId;
    }

    public void setGroupId(int groupId) {
        this.groupId = groupId;
    }

    public String getTransactionId() {
        return strategyId + DELIMITER + groupId;
    }

    public TransactionStatus getStatus() {
        return status;
    }

    public void setStatus(TransactionStatus status) {
        this.status = status;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(System.currentTimeMillis()).append(": ");
        sb.append(strategyId).append('\t');
        sb.append(groupId).append('\t');
        sb.append(status).append('\n');
        return sb.toString();
    }
}
