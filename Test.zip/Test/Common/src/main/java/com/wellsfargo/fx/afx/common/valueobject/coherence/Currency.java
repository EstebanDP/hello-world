package com.wellsfargo.fx.afx.common.valueobject.coherence;

import java.io.Serializable;

@SuppressWarnings("serial")
public class Currency implements Serializable {
	private String name;
    private int ordinal;
    private boolean baseCcyForUsd;

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setOrdinal(int ordinal) {
		this.ordinal = ordinal;
	}

	public int getOrdinal() {
		return ordinal;
	}

	public void setBaseCcyForUsd(boolean baseCcyForUsd) {
		this.baseCcyForUsd = baseCcyForUsd;
	}

	public boolean isBaseCcyForUsd() {
		return baseCcyForUsd;
	}
}
