package com.wellsfargo.fx.afx.ecom.common.valueobject.marketdata;

import java.util.TreeMap;

import com.wellsfargo.fx.afx.common.util.CommonConstants;
import com.wellsfargo.fx.afx.common.valueobject.CurrencyPair;
import com.wellsfargo.fx.afx.common.valueobject.Exchange;

public class CurrencyPairSnapshot implements Cloneable {

    private CurrencyPair currencyPair;
    private Exchange source;
    private long tickReceivedTime;
    private String snapshotTime;
    private final SideBook bidBook;
    private final SideBook offerBook;

    public CurrencyPairSnapshot(CurrencyPair currencyPair) {
        this.currencyPair = currencyPair;
        bidBook = new BidBook();
        offerBook = new OfferBook();
    }

    public CurrencyPairSnapshot(String currencyPair) {
        this(CurrencyPair.getByName(currencyPair));
    }

    public CurrencyPair getCurrencyPair() {
        return currencyPair;
    }

    public Exchange getSource() {
        return source;
    }

    public void setSource(Exchange source) {
        this.source = source;
    }

    public long getTickReceivedTime() {
        return tickReceivedTime;
    }

    public void setTickReceivedTime(long tickReceivedTime) {
        this.tickReceivedTime = tickReceivedTime;
    }

    public String getSnapshotTime() {
        return snapshotTime;
    }

    public void setSnapshotTime(String snapshotTime) {
        this.snapshotTime = snapshotTime;
    }

    public SideBook getBidBook() {
        return bidBook;
    }

    public SideBook getOfferBook() {
        return offerBook;
    }

    public float getBestBid() {
        return bidBook.getBestPrice();
    }

    public float getBestOffer() {
        return offerBook.getBestPrice();
    }

    public void clear() {
        bidBook.clear();
        offerBook.clear();
    }

    public abstract class SideBook {

        // private boolean isBid;
        protected TreeMap<Float, Float> priceQuantityMap = new TreeMap<Float, Float>(); // price, quantity

        private SideBook(boolean isBid) {
            // this.isBid = isBid;
        }

        public abstract float getBestPrice();

        public float getQuantityForBestPrice() {
            if (priceQuantityMap.size() > 0) {
                return priceQuantityMap.get(getBestPrice());
            }
            return CommonConstants.CONST_NA;
        }

        public void setPrice(float price, float quantity) {
            priceQuantityMap.put(price, quantity);

        }

        public void removePrice(float price) {
            priceQuantityMap.remove(price);
        }

        public void clear() {
            priceQuantityMap.clear();
        }
    }

    public final class BidBook extends SideBook {

        private BidBook() {
            super(true);
        }

        public float getBestPrice() {
            if (priceQuantityMap.size() > 0) {
                return priceQuantityMap.floorKey(Float.MAX_VALUE);
            }
            return CommonConstants.CONST_NA;
        }

    }

    public final class OfferBook extends SideBook {

        private OfferBook() {
            super(false);
        }

        public float getBestPrice() {
            if (priceQuantityMap.size() > 0) {
                return priceQuantityMap.ceilingKey(0f);
            }
            return CommonConstants.CONST_NA;
        }

    }
}
