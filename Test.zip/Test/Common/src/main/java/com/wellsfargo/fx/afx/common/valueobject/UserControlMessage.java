package com.wellsfargo.fx.afx.common.valueobject;

import com.wellsfargo.fx.afx.common.util.Util;

public class UserControlMessage extends ValueObject {
    private static final byte version = 1;
    private UserControlMessageEnum userControlMessage;
    private String reason;
    private boolean forcePause;
    private boolean userAttentionNeeded;
    private String userId;

    public UserControlMessage() {
    }
    
    public void setUserControlMessage(UserControlMessageEnum userControlMessage) {
    	this.userControlMessage = userControlMessage;
    }
    
    public UserControlMessageEnum getUserControlMessage() {
    	return userControlMessage;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

	public void setForcePause(boolean forcePause) {
		this.forcePause = forcePause;
	}

	public boolean isForcePause() {
		return forcePause;
	}
	
	public void setUserAttentionNeeded(boolean userAttentionNeeded) {
		this.userAttentionNeeded = userAttentionNeeded;
	}

	public boolean isUserAttentionNeeded() {
		return userAttentionNeeded;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserId() {
		return userId;
	}

    @Override
    public String toString() {
        StringBuffer sb = new StringBuffer();
        sb.append(userId).append('\t');
        sb.append(userControlMessage.toString()).append('\t');
        sb.append(reason).append('\t');
        sb.append(forcePause).append('\t');
        sb.append(userAttentionNeeded);
        return sb.toString();
    }

    @Override
    public int readFrom(byte[] bytes) {
        int pos = 2;
        userControlMessage = UserControlMessageEnum.valueOf(bytes[pos]);
        pos++;
        int str_len = bytes[pos++];
        userId = Util.readStringFromBytes(bytes, str_len, pos);
        pos += str_len;
        str_len = bytes[pos++];
        reason = Util.readStringFromBytes(bytes, str_len, pos);
        pos += str_len;
        forcePause = Util.byteToBoolean(bytes[pos++]);
        userAttentionNeeded = Util.byteToBoolean(bytes[pos++]);

        return pos;
    }

    @Override
    public byte[] toBytes() {
        int length = 1 + 1 + 1 + 1 + userId.length()+ 1 + reason.length() + 1 + 1;
        byte[] bytes = new byte[length];
        int pos = 0;
        bytes[pos++] = MessageType.USER_CONTROL_MESSAGE;
        bytes[pos++] = version;
        bytes[pos++] = (byte) userControlMessage.ordinal();
        pos = Util.writeStringToByteArray(userId, bytes, pos);
        pos = Util.writeStringToByteArray(reason, bytes, pos);
        bytes[pos++] = Util.booleanToByte(forcePause);
        bytes[pos++] = Util.booleanToByte(userAttentionNeeded);
        return bytes;
    }
    
    public enum UserControlMessageEnum {
    	START, PAUSE, SHUTDOWN, UPDATE_CONFIGURATIONS, UPDATE_POSITIONS_FROM_OPICS, STRATEGY_CONTROL;

        public static UserControlMessageEnum valueOf(int ordinal) {
            if (ordinal == START.ordinal()) {
                return START;
            } else if (ordinal == PAUSE.ordinal()) {
                return PAUSE;
            } else if (ordinal == SHUTDOWN.ordinal()) {
                return SHUTDOWN;
            } else if (ordinal == UPDATE_CONFIGURATIONS.ordinal()) {
                return UPDATE_CONFIGURATIONS;
            } else if (ordinal == UPDATE_POSITIONS_FROM_OPICS.ordinal()) {
                return UPDATE_POSITIONS_FROM_OPICS;
            } else if (ordinal == STRATEGY_CONTROL.ordinal()) {
                return STRATEGY_CONTROL;
            }

            return null;
        }
    }
}
