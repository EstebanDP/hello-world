package com.wellsfargo.fx.afx.ecom.common.valueobject;

import java.math.BigDecimal;

import com.wellsfargo.fx.afx.common.util.Util;
import com.wellsfargo.fx.afx.common.valueobject.CurrencyPair;
import com.wellsfargo.fx.afx.common.valueobject.MessageType;
import com.wellsfargo.fx.afx.common.valueobject.ValueObject;

public class CurrencyPairThresholdsConfig  extends ValueObject {
	
	private static final byte version = 1;
	
	private CurrencyPair currencyPair;
	private boolean enabled;
	private BigDecimal shortThreshold;
	private BigDecimal longThreshold;
	private String userName;
	
	public void setCurrencyPair(CurrencyPair currencyPair) {
		this.currencyPair = currencyPair;
	}
	
	public CurrencyPair getCurrencyPair() {
		return currencyPair;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	public boolean isEnabled() {
		return enabled;
	}

	public void setShortThreshold(BigDecimal shortThreshold) {
		this.shortThreshold = shortThreshold;
	}

	public BigDecimal getShortThreshold() {
		return shortThreshold;
	}

	public void setLongThreshold(BigDecimal longThreshold) {
		this.longThreshold = longThreshold;
	}

	public BigDecimal getLongThreshold() {
		return longThreshold;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserName() {
		return userName;
	}
	
	public int getLength() {
		int length = 1 + 1 + 1 + 1 + 1 + userName.length();
        length += 1 + shortThreshold.toPlainString().length() + 1 + longThreshold.toPlainString().length();
		return length;
	}

	@Override
	public byte[] toBytes() {
        byte[] bytes = new byte[getLength()];
        int pos = 0;
        bytes[pos++] = MessageType.CURRENCY_PAIR_TRESHOLDS_CONFIG;
        bytes[pos++] = version;
        pos = Util.writeStringToByteArray(userName, bytes, pos);
        bytes[pos++] = (byte) currencyPair.ordinal();
        bytes[pos++] = Util.booleanToByte(enabled);
        pos = Util.writeStringToByteArray(shortThreshold.toPlainString(), bytes, pos);
        pos = Util.writeStringToByteArray(longThreshold.toPlainString(), bytes, pos);
        
        return bytes;
	}

	@Override
	public int readFrom(byte[] bytes) {
        return readFrom(bytes, 2);
	}
	
	public int readFrom(byte[] bytes, int pos) {
        int length = bytes[pos++];
        userName = Util.readStringFromBytes(bytes, length, pos);
        pos += length;
        
        currencyPair = CurrencyPair.valueOf(bytes[pos++]);
        enabled = Util.byteToBoolean(bytes[pos++]);
        
        length = bytes[pos++];
        String thresholdStr = Util.readStringFromBytes(bytes, length, pos);
        pos += length;
        shortThreshold = new BigDecimal(thresholdStr);
        
        length = bytes[pos++];
        thresholdStr = Util.readStringFromBytes(bytes, length, pos);
        pos += length;
        longThreshold = new BigDecimal(thresholdStr);

        return pos;	
	}
	
	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("****************************").append("\n");
		sb.append("User Name: ").append(userName).append("\n");
		sb.append("Currency Pair: ").append(currencyPair.toString()).append("\n");
		sb.append("Is Enabled: ").append(enabled).append("\n");
		sb.append("Short Treshold: ").append(shortThreshold.toPlainString()).append("\n");
		sb.append("Long Treshold: ").append(longThreshold.toPlainString()).append("\n");
		
		return sb.toString();
	}
}
