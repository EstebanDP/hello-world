package com.wellsfargo.fx.afx.ecom.common.valueobject;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.wellsfargo.fx.afx.common.util.Util;
import com.wellsfargo.fx.afx.common.valueobject.MessageType;
import com.wellsfargo.fx.afx.common.valueobject.ValueObject;

public class ThresholdStrategy extends ValueObject {
	private static final byte version = 1;
	
	private String strategyName;
	private String appliedByUser;
	private String updateUser;
	private List<CurrencyPairThresholdsConfig> ccyPairThresholdsConfig;
	private boolean activeStrategy;
	private boolean deletable;
	// To avoid loops with insertion to the cache
	private boolean updateCache;
	private Date updateDate;
	private String notes;
	
	public void setStrategyName(String strategyName) {
		this.strategyName = strategyName;
	}
	
	public String getStrategyName() {
		return strategyName;
	}
	
	public void setAppliedByUser(String appliedByUser) {
		this.appliedByUser = appliedByUser;
	}
	
	public String getAppliedByUser() {
		return appliedByUser;
	}

	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}

	public String getUpdateUser() {
		return updateUser;
	}

	public void setCcyPairThresholdsConfig(List<CurrencyPairThresholdsConfig> ccyPairThresholdsConfig) {
		this.ccyPairThresholdsConfig = ccyPairThresholdsConfig;
	}

	public List<CurrencyPairThresholdsConfig> getCcyPairThresholdsConfig() {
		return ccyPairThresholdsConfig;
	}

	public void setActiveStrategy(boolean activeStrategy) {
		this.activeStrategy = activeStrategy;
	}

	public boolean isActiveStrategy() {
		return activeStrategy;
	}

	public void setDeletable(boolean deletable) {
		this.deletable = deletable;
	}

	public boolean isDeletable() {
		return deletable;
	}

	public void setUpdateCache(boolean updateCache) {
		this.updateCache = updateCache;
	}

	public boolean isUpdateCache() {
		return updateCache;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	public Date getUpdateDate() {
		return updateDate;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public String getNotes() {
		return notes;
	}
	
	public int getLength() {
		int length = 1 + 1 + 1 + strategyName.length() + 1 + appliedByUser.length() + 1 + updateUser.length() + 1 + 1 + 1 + 1;
		
		for (CurrencyPairThresholdsConfig currencyPairThresholdsConfig : ccyPairThresholdsConfig) {
			length += currencyPairThresholdsConfig.getLength();
		}
		
		length += 8 + 4 + notes.length();
		return length;
	}

	@Override
	public byte[] toBytes() {
        byte[] bytes = new byte[getLength()];
        int pos = 0;
        bytes[pos++] = MessageType.TRESHOLD_STRATEGY;
        bytes[pos++] = version;
        pos = Util.writeStringToByteArray(strategyName, bytes, pos);
        pos = Util.writeStringToByteArray(appliedByUser, bytes, pos);
        pos = Util.writeStringToByteArray(updateUser, bytes, pos);
        bytes[pos++] = Util.booleanToByte(activeStrategy);
        bytes[pos++] = Util.booleanToByte(deletable);
        bytes[pos++] = Util.booleanToByte(updateCache);

        bytes[pos++] = (byte) ccyPairThresholdsConfig.size();
        for (CurrencyPairThresholdsConfig currencyPairThresholdsConfig : ccyPairThresholdsConfig) {
        	byte[] currencyPairThresholdsConfigBytes = currencyPairThresholdsConfig.toBytes();
        	System.arraycopy(currencyPairThresholdsConfigBytes, 0, bytes, pos, currencyPairThresholdsConfigBytes.length);
        	pos += currencyPairThresholdsConfigBytes.length;
		}

        pos = Util.writeLongToByteArray(updateDate.getTime(), bytes, pos);
        pos = Util.writeIntToByteArray(notes.length(), bytes, pos);

        byte[] stringBytes = notes.getBytes();
        System.arraycopy(stringBytes, 0, bytes, pos, stringBytes.length);
        pos += stringBytes.length;
        
        return bytes;
	}
	
	@Override
	public int readFrom(byte[] bytes) {
        int pos = 2;
        int length = bytes[pos++];
        strategyName = Util.readStringFromBytes(bytes, length, pos);
        pos += length;
        length = bytes[pos++];
        appliedByUser = Util.readStringFromBytes(bytes, length, pos);
        pos += length;
        length = bytes[pos++];
        updateUser = Util.readStringFromBytes(bytes, length, pos);
        pos += length;
        activeStrategy = Util.byteToBoolean(bytes[pos++]);
        deletable = Util.byteToBoolean(bytes[pos++]);
        updateCache = Util.byteToBoolean(bytes[pos++]);
        
        length = bytes[pos++];
        ccyPairThresholdsConfig = new ArrayList<CurrencyPairThresholdsConfig>();
        for (int i = 0; i < length; i++) {
        	CurrencyPairThresholdsConfig currencyPairThresholdsConfig = new CurrencyPairThresholdsConfig();
            pos = currencyPairThresholdsConfig.readFrom(bytes, pos + 2);
            ccyPairThresholdsConfig.add(currencyPairThresholdsConfig);
        }

        updateDate = new Date(Util.readLongFromBytes(bytes, pos));
        pos += 8;

        int notesLength = Util.readIntFromBytes(bytes, pos);
        pos += 4;
        notes = Util.readStringFromBytes(bytes, notesLength, pos);
        pos += notesLength;

        return pos;
	}
	
	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("Strategy Name:").append(strategyName).append("\t");
		sb.append("Applied by User: ").append(appliedByUser).append("\t");
		sb.append("Updated by User: ").append(updateUser).append("\t");
		sb.append("Active: ").append(activeStrategy).append("\t");
		sb.append("Deletable: ").append(deletable).append("\t");
		sb.append("Update Cache: ").append(updateCache).append("\t");
		sb.append("Date: ").append(updateDate.toString()).append("\t");
		sb.append("Notes: ").append(notes).append("\n");
		
		for (CurrencyPairThresholdsConfig currencyPairThresholdsConfig :  ccyPairThresholdsConfig) {
			sb.append(currencyPairThresholdsConfig.toString());
		}

		return sb.toString();
	}
}
