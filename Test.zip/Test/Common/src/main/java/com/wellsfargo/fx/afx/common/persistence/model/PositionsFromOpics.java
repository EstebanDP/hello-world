package com.wellsfargo.fx.afx.common.persistence.model;

import java.math.BigDecimal;

public class PositionsFromOpics {
	private String trad;
	private String ccy1;
	private String ccy2;
	private BigDecimal ccy1amt;
	private BigDecimal ccy2amt;
	private String spotrate_8;
	private String terms;

	public String getTrad() {
		return trad;
	}

	public void setTrad(String trad) {
		this.trad = trad;
	}

	public String getCcy1() {
		return ccy1;
	}

	public void setCcy1(String ccy1) {
		this.ccy1 = ccy1;
	}

	public String getCcy2() {
		return ccy2;
	}

	public void setCcy2(String ccy2) {
		this.ccy2 = ccy2;
	}

	public BigDecimal getCcy1amt() {
		return ccy1amt;
	}

	public void setCcy1amt(BigDecimal ccy1amt) {
		this.ccy1amt = ccy1amt;
	}

	public BigDecimal getCcy2amt() {
		return ccy2amt;
	}

	public void setCcy2amt(BigDecimal ccy2amt) {
		this.ccy2amt = ccy2amt;
	}

	public String getSpotrate_8() {
		return spotrate_8;
	}

	public void setSpotrate_8(String spotrate_8) {
		this.spotrate_8 = spotrate_8;
	}

	public String getTerms() {
		return terms;
	}

	public void setTerms(String terms) {
		this.terms = terms;
	}	
}