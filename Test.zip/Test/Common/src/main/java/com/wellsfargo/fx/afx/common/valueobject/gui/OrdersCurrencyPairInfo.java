package com.wellsfargo.fx.afx.common.valueobject.gui;

import java.util.List;

import javolution.util.FastList;

import com.wellsfargo.fx.afx.common.valueobject.MessageType;
import com.wellsfargo.fx.afx.common.valueobject.ValueObject;

public class OrdersCurrencyPairInfo extends ValueObject {

    private static final byte version = 1;
    private List<OrdersCurrencyPairDetails> currencyPairDetails = new FastList<OrdersCurrencyPairDetails>();

    public List<OrdersCurrencyPairDetails> getCurrencyPairDetails() {
        return currencyPairDetails;
    }

    public void setCurrencyPairDetails(List<OrdersCurrencyPairDetails> currencyPairDetails) {
        this.currencyPairDetails = currencyPairDetails;
    }

    public int getByteLength() {
        int byteLength = 0;
        for (OrdersCurrencyPairDetails detail : currencyPairDetails) {
            byteLength += detail.getByteLength();
        }
        return byteLength;
    }

    private void addCurrencyPairDetail(OrdersCurrencyPairDetails detail) {
        this.currencyPairDetails.add(detail);
    }

    @Override
    public int readFrom(byte[] bytes) {

        int pos = 2; // skip type and version
        int length = bytes[pos++];
        int detailPos = pos;
        for (int i = 0; i < length; i++) {
            byte[] detailBytes = new byte[bytes.length - detailPos];
            System.arraycopy(bytes, detailPos, detailBytes, 0, detailBytes.length);
            OrdersCurrencyPairDetails currencyPairDetails = new OrdersCurrencyPairDetails();
            detailPos = currencyPairDetails.readFrom(detailBytes);
            addCurrencyPairDetail(currencyPairDetails);
            pos += detailPos;
            bytes = detailBytes;
        }

        return pos;
    }

    @Override
    public byte[] toBytes() {
        int byteLength = getByteLength();
        byte[] bytes = new byte[byteLength + 3];
        int pos = 0;
        bytes[pos++] = MessageType.ORDERS_PER_CCY_PAIR_INFO;
        bytes[pos++] = version;
        bytes[pos++] = (byte) currencyPairDetails.size();
        for (OrdersCurrencyPairDetails detail : currencyPairDetails) {
            byte[] detailBytes = detail.toBytes();
            System.arraycopy(detailBytes, 0, bytes, pos, detailBytes.length);
            pos += detailBytes.length;
        }
        return bytes;
    }
}
