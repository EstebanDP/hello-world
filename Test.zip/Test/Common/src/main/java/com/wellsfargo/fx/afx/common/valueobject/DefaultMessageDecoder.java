package com.wellsfargo.fx.afx.common.valueobject;

import com.wellsfargo.fx.afx.common.component.ComponentCommand;
import com.wellsfargo.fx.afx.common.log.utils.LogWrapper;
import com.wellsfargo.fx.afx.common.messaging.MessageDecoder;
import com.wellsfargo.fx.afx.common.valueobject.gui.CurrencyDates;
import com.wellsfargo.fx.afx.common.valueobject.gui.CurrencyPairDatesDetails;
import com.wellsfargo.fx.afx.common.valueobject.gui.DealInfo;
import com.wellsfargo.fx.afx.common.valueobject.gui.LoginMessage;
import com.wellsfargo.fx.afx.common.valueobject.gui.OrdersCurrencyPairDetails;
import com.wellsfargo.fx.afx.common.valueobject.gui.OrdersCurrencyPairInfo;
import com.wellsfargo.fx.afx.common.valueobject.gui.OrdersStrategyDetails;
import com.wellsfargo.fx.afx.common.valueobject.gui.PositionInfo;
import com.wellsfargo.fx.afx.common.valueobject.gui.UsdEquivalentPositionInfo;
import com.wellsfargo.fx.afx.common.valueobject.marketdata.MarketTick;
import com.wellsfargo.fx.afx.common.valueobject.marketdata.MarketTickWarmupRequest;
import com.wellsfargo.fx.afx.common.valueobject.orderdata.ExchangeOrderResponse;
import com.wellsfargo.fx.afx.common.valueobject.orderdata.ExchangeRequest;
import com.wellsfargo.fx.afx.common.valueobject.orderdata.Order;
import com.wellsfargo.fx.afx.common.valueobject.orderdata.OrderFill;
import com.wellsfargo.fx.afx.common.valueobject.orderdata.OrderResponse;
import com.wellsfargo.fx.afx.common.valueobject.orderdata.TransactionRequest;
import com.wellsfargo.fx.afx.common.valueobject.orderdata.TransactionResponse;
import com.wellsfargo.fx.afx.common.valueobject.serverproxy.StrategyState;
import com.wellsfargo.fx.afx.common.valueobject.serverproxy.WarmupVo;
import com.wellsfargo.fx.afx.ecom.common.valueobject.ThresholdStrategy;
import com.wellsfargo.fx.afx.ecom.common.valueobject.CurrencyPairThresholdsConfig;
import com.wellsfargo.fx.afx.ecom.common.valueobject.PositionVo;
import com.wellsfargo.fx.afx.ecom.common.valueobject.buffet.AFXStatus;
import com.wellsfargo.fx.afx.ecom.common.valueobject.buffet.AmendedBuffetTrades;
import com.wellsfargo.fx.afx.ecom.common.valueobject.buffet.BuffetBootstrapInfo;
import com.wellsfargo.fx.afx.ecom.common.valueobject.buffet.BuffetTrade;
import com.wellsfargo.fx.afx.ecom.common.valueobject.buffet.BuffetTradeDetailInquiry;
import com.wellsfargo.fx.afx.ecom.common.valueobject.buffet.PositionTransfer;
import com.wellsfargo.fx.afx.ecom.common.valueobject.marketdata.CurrencyPairRateDisplay;
import com.wellsfargo.fx.afx.ecom.common.valueobject.marketdata.EcomMarketTick;

public class DefaultMessageDecoder implements MessageDecoder {

    @Override
    public ValueObject decode(byte[] bytes) {
        ValueObject vo = null;
        switch (bytes[0]) {
        case MessageType.TRANSACTION_REQUEST:
            vo = new TransactionRequest();
            break;
        case MessageType.TRANSACTION_RESPONSE:
            vo = new TransactionResponse();
            break;
        case MessageType.EXCHANGE_ORDER_REQUEST:
            vo = new ExchangeRequest();
            break;
        case MessageType.EXCHANGE_ORDER_RESPONSE:
            vo = new ExchangeOrderResponse();
            break;
        case MessageType.ORDER_RESPONSE:
            vo = new OrderResponse();
            break;
        case MessageType.MARKET_TICK:
            vo = new MarketTick();
            break;
        case MessageType.DEAL_INFO:
            vo = new DealInfo();
            break;
        case MessageType.POSITION_INFO:
            vo = new PositionInfo();
            break;
        case MessageType.USD_EQUIVALENT_POSITION_INFO:
            vo = new UsdEquivalentPositionInfo();
            break;
        case MessageType.CURRENCY_DATES:
            vo = new CurrencyDates();
            break;
        case MessageType.USER_CONTROL_MESSAGE:
            vo = new UserControlMessage();
            break;
        case MessageType.LOGIN_MESSAGE:
            vo = new LoginMessage();
            break;
        case MessageType.ORDER:
            vo = new Order();
            break;
        case MessageType.CCY_PAIR_DATES_DETAILS:
            vo = new CurrencyPairDatesDetails();
            break;
        case MessageType.ORDERS_PER_CCY_PAIR_INFO:
            vo = new OrdersCurrencyPairInfo();
            break;
        case MessageType.DEALS_PER_STRATEGY_DETAILS:
            vo = new OrdersStrategyDetails();
            break;
        case MessageType.DEALS_PER_CCY_PAIR_DETAILS:
            vo = new OrdersCurrencyPairDetails();
            break;
        case MessageType.WARMUP_VO:
            vo = new WarmupVo();
            break;
        case MessageType.LOG_WRAPPER:
            vo = new LogWrapper();
            break;
        case MessageType.CONFIGURATION:
            vo = new Configuration();
            break;
        case MessageType.SHUTDOWN_CMD:
            vo = new ShutdownCmd();
            break;
        case MessageType.JVM_STATUS:
            vo = new JVMStatus();
            break;
        case MessageType.STRATEGY_STATE:
            vo = new StrategyState();
            break;
        case MessageType.MARKET_TICK_WARMUP_REQUEST:
            vo = new MarketTickWarmupRequest();
            break;
        case MessageType.BUFFET_TRADE:
            vo = new BuffetTrade();
            break;
        case MessageType.AMENDED_BUFFET_TRADES:
            vo = new AmendedBuffetTrades();
            break;
        case MessageType.BUFFET_TRADE_DETAIL_INQUIRY:
        	vo = new BuffetTradeDetailInquiry();
        	break;
        case MessageType.ECOM_MARKET_TICK:
            vo = new EcomMarketTick();
            break;
        case MessageType.BUFFET_BOOTSTRAP_INFO:
            vo = new BuffetBootstrapInfo();
            break;
        case MessageType.CURRENCY_PAIR_RATE_DISPLAY:
            vo = new CurrencyPairRateDisplay();
            break;
        case MessageType.POSITION_VO:
            vo = new PositionVo();
            break;
        case MessageType.ORDER_FILL:
            vo = new OrderFill();
            break;
        case MessageType.COMPONENT_COMMAND:
            vo = new ComponentCommand();
            break;
        case MessageType.AFX_STATUS:
        	vo = new AFXStatus();
        	break;
        case MessageType.POSITION_TRANSFER:
        	vo = new PositionTransfer();
        	break;
        case MessageType.CURRENCY_PAIR_TRESHOLDS_CONFIG:
        	vo = new CurrencyPairThresholdsConfig();
        	break;
        case MessageType.TRESHOLD_STRATEGY:
        	vo = new ThresholdStrategy();
        	break;
        }

        vo.readFrom(bytes);
        vo.setMessageType(bytes[0]);
        return vo;
    }

}
