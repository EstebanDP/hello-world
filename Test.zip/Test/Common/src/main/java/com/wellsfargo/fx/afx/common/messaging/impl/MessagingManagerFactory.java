package com.wellsfargo.fx.afx.common.messaging.impl;

import com.wellsfargo.fx.afx.common.messaging.MessagingManager;

public class MessagingManagerFactory {
	private static volatile MessagingManager instance;
	private static final String product = "LBM";

	public static MessagingManager getMessagingManager() {
		if (instance == null) {
			synchronized (MessagingManagerFactory.class) {
				if (instance == null) {
					if (product.equals("LBM")) {
						instance = new MessagingManagerLBM();
					} else {
						throw new RuntimeException(
								"Make sure the configuration value for the property 'messaging.product' is correctly set");
					}
				}
			}
		}
		return instance;
	}
}
