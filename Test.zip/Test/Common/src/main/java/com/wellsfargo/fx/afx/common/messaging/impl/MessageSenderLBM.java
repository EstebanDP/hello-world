package com.wellsfargo.fx.afx.common.messaging.impl;

import com.latencybusters.lbm.LBM;
import com.latencybusters.lbm.LBMContext;
import com.latencybusters.lbm.LBMException;
import com.latencybusters.lbm.LBMSource;
import com.latencybusters.lbm.LBMSourceAttributes;
import com.latencybusters.lbm.LBMSourceEventCallback;
import com.latencybusters.lbm.LBMTopic;
import com.wellsfargo.fx.afx.common.messaging.MessageSender;
import com.wellsfargo.fx.afx.common.util.ConfigurationLoader;

class MessageSenderLBM implements MessageSender {
	private LBMSource source;
	private LBMSourceAttributes sattr;

	public MessageSenderLBM(LBMContext context, String topicName, LBMSourceEventCallback sourceEventCallback) {
		initConfig();
		createSource(context, topicName, sourceEventCallback);
	}

	public void send(byte[] bytes) {
		try {
			source.send(bytes, bytes.length, LBM.MSG_FLUSH);
		} catch (LBMException e) {
			e.printStackTrace();
			System.exit(1);
		}
	}

	private void initConfig() {
		try {
			sattr = new LBMSourceAttributes();
		} catch (LBMException ex) {
			System.err.println("Error Creating Source Attributes: " + ex.toString());
			System.exit(1);
		}
	}

	private void createSource(LBMContext context, String topicName, LBMSourceEventCallback sourceEventCallback) {
		LBMTopic topic = null;
		String transportType = null;

		try {
			transportType = ConfigurationLoader.getInstance().getString("messaging.lbm.topic." + topicName + ".transport".toLowerCase(), true);
		} catch (Exception e) {
		}

		try {
			if (transportType != null) {
				sattr.setValue("transport", transportType);
			}
			topic = context.allocTopic(topicName, sattr);
			
			if(sourceEventCallback != null) {
				source = context.createSource(topic, sourceEventCallback, null);
			} else {
				source = context.createSource(topic);
			}
		} catch (LBMException ex) {
			System.out.println("Error Creating Source: " + ex.toString());
			throw new RuntimeException("Unable to create LBMSource", ex);
		}
		
		if (transportType != null) {
			System.out.println("Created Source for Topic " + topicName + " with " + transportType + " transport type. [Caution: receiver may not be ready yet!]");
		} else {
			System.out.println("Created Source for Topic " + topicName + ". [Caution: receiver may not be ready yet!]");
		}
	}

	@Override
	public String getTopicName() {
		return null;
	}
}