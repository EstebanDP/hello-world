package com.wellsfargo.fx.afx.common.util;


/**
 * This singleton class tracks if configurations are set/reset. 
 */
public class ConfigurationTracker {
	
	//TODO (Danny) Shouldn't this class be in PM?  All configurations are PM related.
	private static ConfigurationTracker self;
	private volatile boolean ccypairTradingThresholdConfigured;
	private volatile boolean pnlAllowedNetLossConfigured;
	private volatile boolean cancelledThresholdConfigured;
	private volatile boolean amendThresholdConfigured;
	private volatile boolean aggregatedPositionThresholdConfigured;
	private volatile boolean buffetRoutingBucketLimitConfigured; //TODO (Danny) Do we still need this?  Jeff said no need to validate
	
	static {
		self = new ConfigurationTracker();
	}
	
	
	private ConfigurationTracker() {
		reset();
	}
	
	public static ConfigurationTracker getInstance() {
		return self;
	}

	public synchronized void setCcypairTradingThresholdConfigured(boolean ccypairTradingThresholdConfigured) {
		this.ccypairTradingThresholdConfigured = ccypairTradingThresholdConfigured;
	}

	public synchronized void setPnlAllowedNetLossConfigured(boolean pnlAllowedNetLossConfigured) {
		this.pnlAllowedNetLossConfigured = pnlAllowedNetLossConfigured;
	}

	public synchronized void setAmendThresholdConfigured(boolean amendThresholdConfigured) {
		this.amendThresholdConfigured = amendThresholdConfigured;
	}
	
	public synchronized void setCancelledThresholdConfigured(boolean cancelledThresholdConfigured) {
		this.cancelledThresholdConfigured = cancelledThresholdConfigured;
	}

	public synchronized void setAggregatedPositionThresholdConfigured(boolean aggregatedPositionThresholdConfigured) {
		this.aggregatedPositionThresholdConfigured = aggregatedPositionThresholdConfigured;
	}
	
	public synchronized void setBuffetRoutingBucketLimitConfigured(boolean buffetRoutingBucketLimitConfigured) {
		this.buffetRoutingBucketLimitConfigured = buffetRoutingBucketLimitConfigured;
	}

	public synchronized boolean isConfigurationsCompleted() {
		return (ccypairTradingThresholdConfigured && pnlAllowedNetLossConfigured && aggregatedPositionThresholdConfigured && buffetRoutingBucketLimitConfigured && cancelledThresholdConfigured && amendThresholdConfigured);
	}
	
	public synchronized void reset() {
		pnlAllowedNetLossConfigured = false;
		aggregatedPositionThresholdConfigured = false;
		buffetRoutingBucketLimitConfigured = false;
		amendThresholdConfigured = false;
		cancelledThresholdConfigured = false;
	}
	
	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("ccypairTradingThresholdConfigured: ").append(ccypairTradingThresholdConfigured).append('\t');
		sb.append("pnlAllowedNetLossConfigured: ").append(pnlAllowedNetLossConfigured).append('\t');
		sb.append("aggregatedPositionThresholdConfigured: ").append(aggregatedPositionThresholdConfigured).append('\t');
		sb.append("buffetRoutingBucketLimitConfigured: ").append(buffetRoutingBucketLimitConfigured).append('\t');
		sb.append("amendThresholdConfigured: ").append(amendThresholdConfigured).append('\t');
		sb.append("cancelledThresholdConfigured: ").append(cancelledThresholdConfigured);
		
		return sb.toString();
	}
}
