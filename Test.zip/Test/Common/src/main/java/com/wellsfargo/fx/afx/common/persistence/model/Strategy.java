package com.wellsfargo.fx.afx.common.persistence.model;

import java.util.Date;
import java.util.List;

public class Strategy {
	private String strategyName;
	private List<CurrencyPairThresholdsConfig> ccyPairThresholdsConfig;
	private String updateUser;
	private boolean deletable;
	private Date updateDate;
	private String notes;
	
	public void setStrategyName(String strategyName) {
		this.strategyName = strategyName;
	}
	
	public String getStrategyName() {
		return strategyName;
	}
	
	public void setCcyPairThresholdsConfig(List<CurrencyPairThresholdsConfig> ccyPairThresholdsConfig) {
		this.ccyPairThresholdsConfig = ccyPairThresholdsConfig;
	}

	public List<CurrencyPairThresholdsConfig> getCcyPairThresholdsConfig() {
		return ccyPairThresholdsConfig;
	}
	
	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}

	public String getUpdateUser() {
		return updateUser;
	}

	public void setDeletable(boolean deletable) {
		this.deletable = deletable;
	}

	public boolean isDeletable() {
		return deletable;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	public Date getUpdateDate() {
		return updateDate;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public String getNotes() {
		return notes;
	}
}
