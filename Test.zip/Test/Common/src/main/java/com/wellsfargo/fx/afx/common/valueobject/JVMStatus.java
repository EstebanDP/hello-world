package com.wellsfargo.fx.afx.common.valueobject;

import com.wellsfargo.fx.afx.common.util.Util;

public class JVMStatus extends ValueObject {

    private static final byte VERSION = 1;
    private ComponentName componentName;
    private JVMStatusEnum jvmStatusEnum;
    private boolean userAttentionNeeded;
    private boolean resendStatusEvenIfSame;
    private String reason = new String();

    public JVMStatus() {
    }

    public JVMStatus(ComponentName componentName) {
        this.componentName = componentName;
    }

    public JVMStatus(ComponentName componentName, JVMStatusEnum jvmStatusEnum) {
        this.componentName = componentName;
        this.jvmStatusEnum = jvmStatusEnum;
    }

    public void setComponentName(ComponentName componentName) {
        this.componentName = componentName;
    }

    public ComponentName getComponentName() {
        return this.componentName;
    }

    public void setJVMStatusEnum(JVMStatusEnum jvmStatusEnum) {
        this.jvmStatusEnum = jvmStatusEnum;
    }

    public JVMStatusEnum getJVMStatusEnum() {
        return this.jvmStatusEnum;
    }

    public void setUserAttentionNeeded(boolean userAttentionNeeded) {
        this.userAttentionNeeded = userAttentionNeeded;
    }

    public boolean isUserAttentionNeeded() {
        return userAttentionNeeded;
    }

    public boolean isResendStatusEvenIfSame() {
        return resendStatusEvenIfSame;
    }

    public void setResendStatusEvenIfSame(boolean resendStatusEvenIfSame) {
        this.resendStatusEvenIfSame = resendStatusEvenIfSame;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getReason() {
        return this.reason;
    }

    @Override
    public int readFrom(byte[] bytes) {
        int pos = 2; // skip type and version
        componentName = ComponentName.valueOf(bytes[pos++]);
        jvmStatusEnum = JVMStatusEnum.valueOf(bytes[pos++]);
        userAttentionNeeded = Util.byteToBoolean(bytes[pos++]);
        resendStatusEvenIfSame = Util.byteToBoolean(bytes[pos++]);

        short strLength = Util.readShortFromBytes(bytes, pos);
        pos += 2;
        reason = Util.readStringFromBytes(bytes, strLength, pos);
        pos += strLength;
        return pos;
    }

    @Override
    public byte[] toBytes() {

        int length = 1 + 1 + 1 + 1 + 1 + 1 + 2 + reason.length();
        byte[] bytes = new byte[length];

        int pos = 0;
        bytes[pos++] = MessageType.JVM_STATUS;
        bytes[pos++] = VERSION;
        bytes[pos++] = (byte) componentName.ordinal();
        bytes[pos++] = (byte) jvmStatusEnum.ordinal();
        bytes[pos++] = Util.booleanToByte(userAttentionNeeded);
        bytes[pos++] = Util.booleanToByte(resendStatusEvenIfSame);
        pos = Util.writeShortToByteArray(((Integer)reason.length()).shortValue(), bytes, pos);
        pos = Util.writeLongStringToByteArray(reason, bytes, pos);

        return bytes;
    }

    public String toString() {
    	StringBuilder sb = new StringBuilder();
    	sb.append(Util.getJVMNameByComponent(componentName)).append(": ").append(jvmStatusEnum.toString());

        if (reason != null && reason.length() > 0) {
            sb.append(", reason: " + reason);
        }
        return sb.toString();
    }
    
    public String toDetailedString() {
    	StringBuilder sb = new StringBuilder();
    	sb.append("\n********* JVM Status *********");
    	sb.append("\nComponent Name: " + componentName.toString());
    	sb.append("\nUser Attention Needed: " + userAttentionNeeded);
    	sb.append("\nResend status even if same: " + resendStatusEvenIfSame);
    	sb.append("\nStatus: " + jvmStatusEnum.toString());
    	
    	if (reason != null && reason.length() > 0) {
    		sb.append("\nReason: " + reason);
        }

        return sb.toString();
    }
}
