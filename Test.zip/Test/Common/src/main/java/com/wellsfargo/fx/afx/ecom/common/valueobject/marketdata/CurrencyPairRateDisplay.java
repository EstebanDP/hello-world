package com.wellsfargo.fx.afx.ecom.common.valueobject.marketdata;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import com.wellsfargo.fx.afx.common.util.CommonConstants;
import com.wellsfargo.fx.afx.common.util.Util;
import com.wellsfargo.fx.afx.common.valueobject.CurrencyPair;
import com.wellsfargo.fx.afx.common.valueobject.MessageType;
import com.wellsfargo.fx.afx.common.valueobject.ValueObject;

public class CurrencyPairRateDisplay extends ValueObject {

    private static final int VERSION = 1;
    private Map<CurrencyPair, BidOffer> rates = new HashMap<CurrencyPair, BidOffer>();

    public void addRates(CurrencyPair currencyPair, float bestBid, float bestOffer) {
        rates.put(currencyPair, new BidOffer(bestBid, bestOffer));
    }

    public Set<CurrencyPair> getCurrencyPairs() {
        return rates.keySet();
    }

    public float getBestBid(CurrencyPair currencyPair) {
        if (rates.containsKey(currencyPair)) {
            return rates.get(currencyPair).bid;
        } else {
            return CommonConstants.CONST_NA;
        }
    }

    public float getBestOffer(CurrencyPair currencyPair) {
        if (rates.containsKey(currencyPair)) {
            return rates.get(currencyPair).offer;
        } else {
            return CommonConstants.CONST_NA;
        }
    }

    @Override
    public int readFrom(byte[] bytes) {
        int pos = 2;
        while (pos < bytes.length) {
            CurrencyPair cp = CurrencyPair.valueOf(bytes[pos++]);
            float bid = Util.readFloatFromBytes(bytes, pos);
            pos += 4;
            float offer = Util.readFloatFromBytes(bytes, pos);
            pos += 4;
            rates.put(cp, new BidOffer(bid, offer));
        }
        return pos;
    }

    @Override
    public byte[] toBytes() {
        byte[] bytes = new byte[getLength()];
        int pos = 0;
        bytes[pos++] = MessageType.CURRENCY_PAIR_RATE_DISPLAY;
        bytes[pos++] = VERSION;

        for (CurrencyPair cp : rates.keySet()) {
            bytes[pos++] = (byte) cp.ordinal();
            pos = Util.writeFloatToByteArray(rates.get(cp).bid, bytes, pos);
            pos = Util.writeFloatToByteArray(rates.get(cp).offer, bytes, pos);
        }
        return bytes;
    }

    private int getLength() {
        return 2 + (1 + 4 + 4) * rates.size();
    }

    private class BidOffer {

        BidOffer(float bid, float offer) {
            this.bid = bid;
            this.offer = offer;
        }

        private float bid;
        private float offer;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (CurrencyPair cp : rates.keySet()) {
            sb.append(cp).append(": ").append(rates.get(cp).bid).append('/').append(rates.get(cp).offer).append('\n');
        }
        return sb.toString();
    }
}
