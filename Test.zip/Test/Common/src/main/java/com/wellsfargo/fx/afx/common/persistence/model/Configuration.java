package com.wellsfargo.fx.afx.common.persistence.model;

import java.util.Date;

public class Configuration {
	private String configType;
	private String configName;
	private String configValue;
	private String updateUser;
	private Date updateDate;
	
	public void setConfigType(String configType) {
		this.configType = configType;
	}

	public String getConfigType() {
		return configType;
	}

	public void setConfigName(String configName) {
		this.configName = configName;
	}

	public String getConfigName() {
		return configName;
	}

	public void setConfigValue(String configValue) {
		this.configValue = configValue;
	}

	public String getConfigValue() {
		return configValue;
	}
	
	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}

	public String getUpdateUser() {
		return updateUser;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	public Date getUpdateDate() {
		return updateDate;
	}
}
