package com.wellsfargo.fx.afx.ecom.common.mdg;

import java.util.Set;

import com.wellsfargo.fx.afx.ecom.common.valueobject.marketdata.CurrencyPairSnapshot;

public interface MarketDataListener {

    public void onMarketData(Set<CurrencyPairSnapshot> snapshots);

}
