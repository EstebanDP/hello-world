package com.wellsfargo.fx.afx.common.valueobject;

public enum OrderType {
	MARKET, LIMIT, INTERNAL;

	public static OrderType valueOf(int ordinal) {
		if (ordinal == MARKET.ordinal()) {
			return MARKET;
		} else if (ordinal == LIMIT.ordinal()) {
			return LIMIT;
		} else if (ordinal == INTERNAL.ordinal()) {
			return INTERNAL;
		} else {
			return null;
		}
	}
}
