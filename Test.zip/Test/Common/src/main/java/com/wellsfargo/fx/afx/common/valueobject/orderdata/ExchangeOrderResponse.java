package com.wellsfargo.fx.afx.common.valueobject.orderdata;

import com.wellsfargo.fx.afx.common.util.Util;
import com.wellsfargo.fx.afx.common.valueobject.CurrencyPair;
import com.wellsfargo.fx.afx.common.valueobject.MessageType;
import com.wellsfargo.fx.afx.common.valueobject.OrderStatus;
import com.wellsfargo.fx.afx.common.valueobject.Side;
import com.wellsfargo.fx.afx.common.valueobject.ValueObject;

public class ExchangeOrderResponse extends ValueObject {
    // private static Logger log = LoggerFactory.getLogger("");
    private static final byte version = 1;
    private int orderId;
    private int strategyId;
    private int groupId;
    private CurrencyPair currencyPair;
    private Side side;
    private OrderStatus status = OrderStatus.NONE;
    private float quantityFilled;
    private float priceFilled;
    private long responseReceivedTime;
    private String reason = "";

    @Override
    public byte[] toBytes() {
        int length = 1 + 1 + 4 + 4 + 4 + 1 + 1 + 1 + 4 + 4 + 8 + 1 + reason.length();
        byte[] bytes = new byte[length];

        int pos = 0;
        bytes[pos++] = MessageType.EXCHANGE_ORDER_RESPONSE;
        bytes[pos++] = version;
        pos = Util.writeIntToByteArray(orderId, bytes, pos);
        pos = Util.writeIntToByteArray(strategyId, bytes, pos);
        pos = Util.writeIntToByteArray(groupId, bytes, pos);
        bytes[pos++] = (byte) currencyPair.ordinal();
        bytes[pos++] = (byte) side.ordinal();
        bytes[pos++] = (byte) status.ordinal();
        pos = Util.writeFloatToByteArray(quantityFilled, bytes, pos);
        pos = Util.writeFloatToByteArray(priceFilled, bytes, pos);
        pos = Util.writeLongToByteArray(responseReceivedTime, bytes, pos);
        pos = Util.writeStringToByteArray(reason, bytes, pos);
        // log.debug(toString());
        return bytes;
    }

    @Override
    public int readFrom(byte[] bytes) {
        int pos = 2; // skip type and version
        orderId = Util.readIntFromBytes(bytes, pos);
        pos += 4;
        strategyId = Util.readIntFromBytes(bytes, pos);
        pos += 4;
        groupId = Util.readIntFromBytes(bytes, pos);
        pos += 4;

        currencyPair = CurrencyPair.valueOf(bytes[pos++]);
        side = Side.valueOf(bytes[pos++]);
        status = OrderStatus.valueOf(bytes[pos++]);

        quantityFilled = Util.readFloatFromBytes(bytes, pos);
        pos += 4;
        priceFilled = Util.readFloatFromBytes(bytes, pos);
        pos += 4;
        responseReceivedTime = Util.readLongFromBytes(bytes, pos);
        pos += 8;
        int length = bytes[pos++];
        reason = Util.readStringFromBytes(bytes, length, pos);
        pos += length;
        // log.debug(toString());
        return pos;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("[Exchange Order Response] ").append('\t');
        sb.append(orderId).append('|');
        sb.append(strategyId).append('|');
        sb.append(groupId).append('\t');
        sb.append(currencyPair).append('\t');
        sb.append(side).append('\t');
        sb.append(status).append('\t');
        sb.append(quantityFilled).append('\t');
        sb.append(priceFilled).append('\t');
        sb.append(responseReceivedTime).append('\t');
        sb.append(reason);
        return sb.toString();
    }

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public int getStrategyId() {
        return strategyId;
    }

    public void setStrategyId(int strategyId) {
        this.strategyId = strategyId;
    }

    public int getGroupId() {
        return groupId;
    }

    public void setGroupId(int groupId) {
        this.groupId = groupId;
    }

    public CurrencyPair getCurrencyPair() {
        return currencyPair;
    }

    public void setCurrencyPair(CurrencyPair currencyPair) {
        this.currencyPair = currencyPair;
    }

    public Side getSide() {
        return side;
    }

    public void setSide(Side side) {
        this.side = side;
    }

    public OrderStatus getOrderStatus() {
        return status;
    }

    public void setOrderStatus(OrderStatus status) {
        this.status = status;
    }

    public float getQuantityFilled() {
        return quantityFilled;
    }

    public void setQuantityFilled(float quantityFilled) {
        this.quantityFilled = quantityFilled;
    }

    public float getPriceFilled() {
        return priceFilled;
    }

    public void setPriceFilled(float priceFilled) {
        this.priceFilled = priceFilled;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getTransactionId() {
        return strategyId + "|" + groupId;
    }

    public String getCompositeOrderId() {
        return orderId + "|" + strategyId + "|" + groupId;
    }

    public long getResponseReceivedTime() {
        return responseReceivedTime;
    }

    public void setResponseReceivedTime(long responseReceivedTime) {
        this.responseReceivedTime = responseReceivedTime;
    }

}
