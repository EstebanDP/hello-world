package com.wellsfargo.fx.afx.common.valueobject.coherence;

import java.io.Serializable;

@SuppressWarnings("serial")
public final class OrderRatios implements Serializable {

    private int filled;
    private int partiallyFilled;
    private int cancelled;
    private int rejectedByExchange;
    private int rejectedByThroughput;
    private int rejectedByLatency;
    private int rejectedByValidation;
    private int total;

    public int getFilled() {
        return filled;
    }

    public void incrementFilled(int count) {
        this.filled += count;
    }

    public int getPartiallyFilled() {
        return partiallyFilled;
    }

    public void incrementPartiallyFilled(int count) {
        this.partiallyFilled += count;
    }

    public int getCancelled() {
        return cancelled;
    }

    public void incrementCancelled(int count) {
        this.cancelled += count;
    }

    public int getRejectedByExchange() {
        return rejectedByExchange;
    }

    public void incrementRejectedByExchange(int count) {
        this.rejectedByExchange += count;
    }

    public int getRejectedByThroughput() {
        return rejectedByThroughput;
    }

    public void incrementRejectedByThroughput(int count) {
        this.rejectedByThroughput += count;
    }

    public int getRejectedByLatency() {
        return rejectedByLatency;
    }

    public void incrementRejectedByLatency(int count) {
        this.rejectedByLatency += count;
    }

    public int getRejectedByValidation() {
        return rejectedByValidation;
    }

    public void incrementRejectedByValidation(int count) {
        this.rejectedByValidation += count;
    }

    public int getTotal() {
        return total;
    }

    public float getFillRatioPercentage() {
        return getFillRatioPercentage(false);
    }

    public float getFillRatioPercentage(boolean includePartialFills) {
        int totalFilled = filled;
        if (includePartialFills) {
            totalFilled += partiallyFilled;
        }
        if (total != 0) {
            return 100f * totalFilled / total;
        } else {
            return -Float.MIN_VALUE;
        }
    }

    public void incrementTotal(int count) {
        this.total += count;
    }
    
    public String toString() {
    	StringBuilder sb = new StringBuilder();
    	
    	sb.append("filled: ").append(filled).append("\n");
    	sb.append("partiallyFilled: ").append(partiallyFilled).append("\n");
    	sb.append("cancelled: ").append(cancelled).append("\n");
    	sb.append("rejectedByExchange: ").append(rejectedByExchange).append("\n");
    	sb.append("rejectedByThroughput: ").append(rejectedByThroughput).append("\n");
    	sb.append("rejectedByLatency: ").append(rejectedByLatency).append("\n");
    	sb.append("rejectedByValidation: ").append(rejectedByValidation).append("\n");
    	sb.append("total: ").append(total);
    	
    	return sb.toString();
    }
}
