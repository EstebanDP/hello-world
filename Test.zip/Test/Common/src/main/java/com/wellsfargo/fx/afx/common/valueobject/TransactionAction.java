package com.wellsfargo.fx.afx.common.valueobject;

public enum TransactionAction {
    NONE, SUBMIT_ORDERS, CANCEL_POSITIONS, HANDLE_RESIDUALS, REMOVE_FROM_MAP;

    public static TransactionAction valueOf(int ordinal) {
        if (ordinal == NONE.ordinal()) {
            return NONE;
        } else if (ordinal == SUBMIT_ORDERS.ordinal()) {
            return SUBMIT_ORDERS;
        } else if (ordinal == CANCEL_POSITIONS.ordinal()) {
            return CANCEL_POSITIONS;
        } else if (ordinal == HANDLE_RESIDUALS.ordinal()) {
            return HANDLE_RESIDUALS;
        } else if (ordinal == REMOVE_FROM_MAP.ordinal()) {
            return REMOVE_FROM_MAP;
        }
        return null;
    }
}
