package com.wellsfargo.fx.afx.common.util;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.List;
import java.util.Locale;

import com.wellsfargo.fx.afx.common.valueobject.ComponentName;

public class Util {

    private static final NumberFormat amountFormatter = DecimalFormat.getInstance(Locale.US);
    private static final NumberFormat numberFormat = NumberFormat.getNumberInstance(Locale.US);
    private static DecimalFormat amountNoDecimalFormat = new DecimalFormat("###,###");

    static {
        amountFormatter.setMinimumFractionDigits(2);
        amountFormatter.setMaximumFractionDigits(2);
        amountFormatter.setGroupingUsed(false);
    }

    @SuppressWarnings("unchecked")
    public static <T> T cast(Object obj) {
        return (T) obj;
    }

    public static long micros() {
        return System.nanoTime() / 1000;
    }

    public static int writeLongToByteArray(long value, byte[] bytes, int pos) {
        for (int i = 0; i < 8; i++) {
            int offset = (7 - i) * 8;
            bytes[pos++] = (byte) ((value >>> offset) & 0xFF);
        }
        return pos;
    }

    public static int writeIntToByteArray(int value, byte[] bytes, int pos) {
        for (int i = 0; i < 4; i++) {
            int offset = (3 - i) * 8;
            bytes[pos++] = (byte) ((value >>> offset) & 0xFF);
        }
        return pos;
    }

    public static long readLongFromBytes(byte[] bytes, int pos) {
        long value = 0;
        for (int i = 0; i < 8; i++) {
            value = (value << 8) + (bytes[pos++] & 0xff);
        }
        return value;
    }

    public static int readIntFromBytes(byte[] bytes, int pos) {
        int value = 0;
        for (int i = 0; i < 4; i++) {
            value = (value << 8) + (bytes[pos++] & 0xff);
        }
        return value;
    }

    /**
     * This function has a limitation that the string size cannot be greater than 128 (0-127)
     */
    public static int writeStringToByteArray(String value, byte[] bytes, int pos) {
        byte[] stringBytes = value.getBytes();
        bytes[pos++] = (byte) stringBytes.length;
        System.arraycopy(stringBytes, 0, bytes, pos, stringBytes.length);
        return pos + stringBytes.length;
    }
    
    public static String readStringFromBytes(byte[] bytes, int length, int pos) {
        return new String(bytes, pos, length);
    }

    public static int writeLongStringToByteArray(String value, byte[] bytes, int pos) {
	    byte[] stringBytes = value.getBytes();
	    System.arraycopy(stringBytes, 0, bytes, pos, stringBytes.length);
	    return pos + stringBytes.length;
	}
    
    public static int writeFloatToByteArray(float value, byte[] bytes, int pos) {
        return writeIntToByteArray(Float.floatToIntBits(value), bytes, pos);
    }

    public static float readFloatFromBytes(byte[] bytes, int pos) {
        int n = readIntFromBytes(bytes, pos);
        return Float.intBitsToFloat(n);
    }

    public static int writeDoubleToByteArray(double value, byte[] bytes, int pos) {
        return writeLongToByteArray(Double.doubleToLongBits(value), bytes, pos);
    }

    public static double readDoubleFromBytes(byte[] bytes, int pos) {
        long l = readLongFromBytes(bytes, pos);
        return Double.longBitsToDouble(l);
    }

    public static boolean byteToBoolean(byte byt) {
        if (byt == 0) {
            return false;
        } else {
            return true;
        }
    }

    public static byte booleanToByte(boolean bool) {
        if (bool) {
            return 1;
        } else {
            return 0;
        }
    }

    public static short readShortFromBytes(byte[] bytes, int pos) {
        short value = 0;
        for (int i = 0; i < 2; i++) {
            value = (short) ((value << 8) + (bytes[pos++] & 0xff));
        }
        return value;
    }

    public static int writeShortToByteArray(short value, byte[] bytes, int pos) {
        for (int i = 0; i < 2; i++) {
            int offset = (1 - i) * 8;
            bytes[pos++] = (byte) ((value >>> offset) & 0xFF);
        }
        return pos;
    }

    public static boolean isEmptyList(List<String> list) {
        if (list == null || list.size() == 0)
            return true;

        return false;
    }

    public static boolean isEmptyString(String stringToValidate) {
        if (stringToValidate == null || stringToValidate.length() == 0)
            return true;

        return false;
    }

    public static String getAmountAsString(float f) {
        return amountFormatter.format(f);
    }

    public static String getAmountAsString(double d) {
        return amountFormatter.format(d);
    }
    
    public static boolean isComponentConnectedToServerProxy() {
        if (CommonConstants.VALUE_COMPONENT_NAME.equals(ComponentName.SERVER_PROXY) || CommonConstants.VALUE_COMPONENT_NAME.equals(ComponentName.MARKET_TICK_SIMULATOR) || CommonConstants.VALUE_COMPONENT_NAME.equals(ComponentName.GUI)) {
        	return false;
        }

		return true;
	}
    
    public static String getTrimmedString(String originalStr, String toRemoveStr) {
    	int index = originalStr.lastIndexOf(toRemoveStr);
		
		if (index != -1) {
			originalStr = originalStr.substring(0, index).trim();
		}
		
		return originalStr;
    }
    
    public static ComponentName getComponentName(String componentNameStr) {
    	if (componentNameStr.equals(CommonConstants.CONST_MDG_EBS)) {
			return ComponentName.MARKET_DATA_GATEWAY;
    	} else if (componentNameStr.equals(CommonConstants.CONST_ORG_EBS)) {
    		return ComponentName.ORDER_ROUTING_GATEWAY;
    	} else if (componentNameStr.equals(CommonConstants.CONST_MDG_CNX)) {
    		return ComponentName.CNX_MARKET_DATA_GATEWAY;
    	} else if (componentNameStr.equals(CommonConstants.CONST_ORG_CNX)) {
    		return ComponentName.CNX_ORDER_ROUTING_GATEWAY;
    	} else if (componentNameStr.equals(CommonConstants.CONST_MDG_INTEGRAL)) {
    		return ComponentName.INTEGRAL_MARKET_DATA_GATEWAY;
    	} else if (componentNameStr.equals(CommonConstants.CONST_ORG_INTEGRAL)) {
    		return ComponentName.INTEGRAL_ORDER_ROUTING_GATEWAY;
    	}

		return ComponentName.getByName(componentNameStr);
	}
    
	public static String getJVMNameByComponent(ComponentName componentName) {
		if (componentName.equals(ComponentName.CNX_MARKET_DATA_GATEWAY)) {
			return "Currenex MDG";
		} else if (componentName.equals(ComponentName.INTEGRAL_MARKET_DATA_GATEWAY)) {
			return "Integral MDG";
		} else if (componentName.equals(ComponentName.CNX_ORDER_ROUTING_GATEWAY)) {
			return "Currenex ORG";
		} else if (componentName.equals(ComponentName.INTEGRAL_ORDER_ROUTING_GATEWAY)) {
			return "Integral ORG";
		} else if (componentName.equals(ComponentName.POSITION_MANAGER_ECOM)) {
			return "Position Manager";
		} else if (componentName.equals(ComponentName.SERVER_PROXY)) {
			return "Server Proxy";
		} else if (componentName.equals(ComponentName.CLIENT_PROXY)) {
			return "Client Proxy";
		}  else if (componentName.equals(ComponentName.GFX_API)) {
			return "Buffet";
		}

		return componentName.toString();
	}

	public static String getMonitorMessageByConfiguration(String configurationName) {
		if (configurationName.equalsIgnoreCase(CommonConstants.CONST_ALLOWED_NET_LOSS_CONFIG)) {
			return "Allowed Net Loss updated to ";
		} else if (configurationName.equalsIgnoreCase(CommonConstants.CONST_AGGREGATED_POSITION_THRESHOLD_CONFIG)) {
			return "Aggregated Position Threshold updated to ";
		} else if (configurationName.equalsIgnoreCase(CommonConstants.CONST_BUFFET_ROUTING_BUCKET_LIMIT_CONFIG)) {
			return "Buffet Trade Routing Threshold updated to ";
		} else if (configurationName.equalsIgnoreCase(CommonConstants.CONST_POSITION_GFX_AMEND_THRESHOLD_CONFIG)) {
			return "Buffet Amended Trade Threshold updated to ";
		} else if (configurationName.equalsIgnoreCase(CommonConstants.CONST_POSITION_GFX_CANCEL_THRESHOLD_CONFIG)) {
			return "Buffet Cancelled Trade Threshold updated to ";		
		} else if (configurationName.equalsIgnoreCase(CommonConstants.CONST_POSITION_GFX_TRADE_SOURCES_CONFIG)) {
			return "Buffet Trade Sources updated to ";
		} else if (configurationName.equalsIgnoreCase(CommonConstants.CONST_MACRO_THRESHOLD_MIN_AMOUNT)) {
			return "Macro Minimum Threshold amount updated to ";
		} else if (configurationName.equalsIgnoreCase(CommonConstants.CONST_MACRO_THRESHOLD_MAX_AMOUNT)) {
			return "Macro Maximum Threshold amount updated to ";
		} else if (configurationName.equalsIgnoreCase(CommonConstants.CONST_POSITION_MASTER_LIMIT)) {
			return "Position Master Limit updated to ";
		} else if (configurationName.equalsIgnoreCase(CommonConstants.CONST_POSITION_ORDER_CANCEL_TIME)) {
			return "Position Order Cancel Time updated to ";
		}
		
		return new String();
	}
	
    public static String convertFloatToReadableString(float floatValue) {
    	if (floatValue == CommonConstants.CONST_NA) {
    		return CommonConstants.CONST_NA_STRING;
    	} else if (floatValue < 0) {
    		return ("(" + amountNoDecimalFormat.format(floatValue * -1) + ")");
    	}
    	
    	return amountNoDecimalFormat.format(floatValue);
    }
    
    public static String convertBigDecimalToReadableString(BigDecimal bdValue, int numberOfDecimals) {
    	if (bdValue.compareTo(CommonConstants.CONST_NA_BIG_DECIMAL) == 0) {
    		return CommonConstants.CONST_NA_STRING;
    	} else {
        	bdValue = bdValue.setScale(numberOfDecimals, BigDecimal.ROUND_HALF_UP);
        	
        	if (bdValue.compareTo(CommonConstants.CONST_ZERO_BIG_DECIMAL) < 0) {
        		double doubleValue = (bdValue.multiply(new BigDecimal(-1)).doubleValue());
        		return ("(" + numberFormat.format(doubleValue) + ")");
        	}
        	return numberFormat.format(bdValue.doubleValue());
    	}
    }
    
    public static String convertUSDEquivalentBigDecimalToReadableString(BigDecimal bdValue, int numberOfDecimals) {
    	if (bdValue.compareTo(CommonConstants.CONST_NA_BIG_DECIMAL) == 0) {
    		return CommonConstants.CONST_NA_STRING;
    	} else {
    		bdValue = bdValue.setScale(numberOfDecimals, BigDecimal.ROUND_HALF_UP).negate();

        	if (bdValue.compareTo(CommonConstants.CONST_ZERO_BIG_DECIMAL) < 0) {
        		double doubleValue = (bdValue.multiply(new BigDecimal(-1)).doubleValue());
        		return ("(" + numberFormat.format(doubleValue) + ")");
        	}
        	return numberFormat.format(bdValue.doubleValue());    		
    	}
    }
}
