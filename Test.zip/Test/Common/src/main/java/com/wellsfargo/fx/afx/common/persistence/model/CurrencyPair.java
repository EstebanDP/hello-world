package com.wellsfargo.fx.afx.common.persistence.model;

import java.util.Date;

public class CurrencyPair {
	private int ordinal;
	private String ccy1;
	private String ccy2;
	private int precision;
	private boolean enabled;
	private String updateUser;
	private Date updateDate;

	public void setOrdinal(int ordinal) {
		this.ordinal = ordinal;
	}

	public int getOrdinal() {
		return ordinal;
	}

	public void setCcy1(String currency) {
		this.ccy1 = currency;
	}

	public String getCcy1() {
		return ccy1;
	}

	public void setCcy2(String currency) {
		this.ccy2 = currency;
	}

	public String getCcy2() {
		return ccy2;
	}

	public void setPrecision(int precision) {
		this.precision = precision;
	}

	public int getPrecision() {
		return precision;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	public boolean isEnabled() {
		return enabled;
	}

	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}

	public String getUpdateUser() {
		return updateUser;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	public Date getUpdateDate() {
		return updateDate;
	}
}
