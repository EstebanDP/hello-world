package com.wellsfargo.fx.afx.common.valueobject.gui;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Collection;
import java.util.Map;

import javolution.util.FastMap;

import com.wellsfargo.fx.afx.common.util.Util;
import com.wellsfargo.fx.afx.common.valueobject.Currency;
import com.wellsfargo.fx.afx.common.valueobject.MessageType;
import com.wellsfargo.fx.afx.common.valueobject.ValueObject;

public class PositionInfo extends ValueObject {
    private static final byte version = 1;

    private Map<Currency, PositionDetail> positionDetails = new FastMap<Currency, PositionDetail>();

    @Override
    public synchronized int readFrom(byte[] bytes) {
        if (bytes[0] != MessageType.POSITION_INFO) {
            throw new RuntimeException("Wrong message type. Expected " + MessageType.POSITION_INFO + ". Found " + bytes[0]);
        }
        int pos = 2; // skip type and version
        int length = bytes[pos++];

        for (int i = 0; i < length; i++) {
            PositionDetail detail = new PositionDetail();
            pos = detail.readFrom(bytes, pos);
            positionDetails.put(detail.getCurrency(), detail);
        }
        return pos;
    }

    public synchronized void addPositionDetail(PositionDetail positionDetail) {
        positionDetails.put(positionDetail.getCurrency(), positionDetail);
    }

    public synchronized Collection<PositionDetail> getPositionDetails() {
        return positionDetails.values();
    }

    public synchronized PositionDetail getPositionDetail(Currency currency) {
        return positionDetails.get(currency);
    }

    public void addPositions(PositionInfo addlPosition) {
        // logger.debug("Adding position " + addlPosition.toString() + " to " + toString());
        for (PositionDetail apd : addlPosition.getPositionDetails()) {
            PositionDetail pd = positionDetails.get(apd.getCurrency());
            if (pd == null) {
                pd = new PositionDetail(apd.getCurrency());
                positionDetails.put(apd.getCurrency(), pd);
            }
            pd.setPosition(pd.getPosition().add(apd.getPosition()));
        }
        // logger.debug("Position after addition " + toString());
    }

    public boolean hasWholePositions() {
        for (PositionDetail pd : positionDetails.values()) {
            if (pd.getCurrency() == Currency.USD || pd.getCurrency() == Currency.getByName("EUR")) {
                if (pd.getPosition().abs().floatValue() >= 1) {
                    return true;
                }
            }
        }
        return false;
    }

    public boolean hasResidualPositions() {
        for (PositionDetail pd : positionDetails.values()) {
            if (pd.getCurrency() != Currency.USD) {
                if (pd.getPosition().abs().floatValue() >= 0.00001) {
                    // logger.debug(pd.getCurrency() + ": " + pd.getPosition());
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    public synchronized byte[] toBytes() {
        int length = 1 + 1 + 1;
        for (PositionDetail detail : positionDetails.values()) {
            length += detail.byteLength();
        }
        byte[] bytes = new byte[length];

        int pos = 0;
        bytes[pos++] = MessageType.POSITION_INFO;
        bytes[pos++] = version;
        bytes[pos++] = (byte) positionDetails.size();
        for (PositionDetail detail : positionDetails.values()) {
            pos = detail.toBytes(bytes, pos);
        }
        return bytes;
    }

    public Collection<Currency> getCurrencies() {
        return positionDetails.keySet();
    }

    public static class PositionDetail {
        private Currency currency;
        private static int scale = 6;
        private BigDecimal position = new BigDecimal(0f);

        public PositionDetail(Currency currency) {
            setCurrency(currency);
        }

        PositionDetail() {
        }

        public Currency getCurrency() {
            return currency;
        }

        public void setCurrency(Currency currency) {
            this.currency = currency;
        }

        protected static int getScale() {
            return scale;
        }

        public BigDecimal getPosition() {
            return position;
        }

        public void setPosition(BigDecimal position) {
            this.position = position.setScale(scale, RoundingMode.HALF_DOWN);
        }

        public int byteLength() {
            return 1 + 1 + position.toPlainString().length();
        }

        public int readFrom(byte[] bytes, int pos) {
            currency = Currency.valueOf(bytes[pos++]);
            int length = bytes[pos++];
            position = new BigDecimal(Util.readStringFromBytes(bytes, length, pos));
            pos += length;
            return pos;
        }

        public int toBytes(byte[] bytes, int pos) {
            bytes[pos++] = (byte) currency.ordinal();
            pos = Util.writeStringToByteArray(position.toPlainString(), bytes, pos);
            return pos;
        }
    }

    public String toString() {
        StringBuilder tb = new StringBuilder();
        for (PositionDetail pd : positionDetails.values()) {
            tb.append(pd.getCurrency()).append(':').append(pd.getPosition().toPlainString()).append('\t');
        }
        return tb.toString();
    }
}
