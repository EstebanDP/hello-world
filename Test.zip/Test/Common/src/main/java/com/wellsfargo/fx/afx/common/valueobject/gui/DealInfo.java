package com.wellsfargo.fx.afx.common.valueobject.gui;

import com.wellsfargo.fx.afx.common.util.Util;
import com.wellsfargo.fx.afx.common.valueobject.MessageType;
import com.wellsfargo.fx.afx.common.valueobject.ValueObject;

public class DealInfo extends ValueObject {
    private static final byte version = 1;
    private int orderId;
    private float quantityFilled;

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public float getQuantityFilled() {
        return quantityFilled;
    }

    public void setQuantityFilled(float quantityFilled) {
        this.quantityFilled = quantityFilled;
    }

    @Override
    public int readFrom(byte[] bytes) {
        if (bytes[0] != MessageType.DEAL_INFO) {
            throw new RuntimeException("Wrong message type. Expected " + MessageType.DEAL_INFO + ". Found " + bytes[0]);
        }
        int pos = 2; // skip type and version
        orderId = Util.readIntFromBytes(bytes, pos);
        pos += 4;
        quantityFilled = Util.readFloatFromBytes(bytes, pos);
        pos += 4;
        return pos;
    }

    @Override
    public byte[] toBytes() {
        int length = 1 + 1 + 1 + 4 + 4;
        byte[] bytes = new byte[length];
        int pos = 0;
        bytes[pos++] = MessageType.DEAL_INFO;
        bytes[pos++] = version;
        pos = Util.writeIntToByteArray(orderId, bytes, pos);
        pos = Util.writeFloatToByteArray(quantityFilled, bytes, pos);
        return bytes;
    }
}
