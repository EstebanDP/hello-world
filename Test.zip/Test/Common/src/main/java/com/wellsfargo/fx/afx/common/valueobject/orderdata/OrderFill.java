package com.wellsfargo.fx.afx.common.valueobject.orderdata;

import java.util.Date;

import com.wellsfargo.fx.afx.common.util.Util;
import com.wellsfargo.fx.afx.common.valueobject.CurrencyPair;
import com.wellsfargo.fx.afx.common.valueobject.Exchange;
import com.wellsfargo.fx.afx.common.valueobject.MessageType;
import com.wellsfargo.fx.afx.common.valueobject.Side;
import com.wellsfargo.fx.afx.common.valueobject.ValueObject;

public class OrderFill extends ValueObject {

    private static final int MESSAGE_TYPE = MessageType.ORDER_FILL;
    private static final int VERSION = 1;

    private String ecnTradeId;
    private String orderId;
    private Exchange exchange;
    private CurrencyPair currencyPair;
    private Side side;
    private float quantity;
    private float price;
    private Date executionTime;
    private Date afxTime;

    @Override
    public int readFrom(byte[] bytes) {
        int pos = 2;
        int length = bytes[pos++];
        ecnTradeId = Util.readStringFromBytes(bytes, length, pos);
        pos += length;
        length = bytes[pos++];
        orderId = Util.readStringFromBytes(bytes, length, pos);
        pos += length;
        exchange = Exchange.valueOf(bytes[pos++]);
        currencyPair = CurrencyPair.valueOf(bytes[pos++]);
        side = Side.valueOf(bytes[pos++]);
        quantity = Util.readFloatFromBytes(bytes, pos);
        pos += 4;
        price = Util.readFloatFromBytes(bytes, pos);
        pos += 4;
        executionTime = new Date(Util.readLongFromBytes(bytes, pos));
        pos += 8;
        afxTime = new Date(Util.readLongFromBytes(bytes, pos));
        pos += 8;

        return pos;
    }

    @Override
    public byte[] toBytes() {
        byte[] bytes = new byte[getLength()];
        int pos = 0;
        bytes[pos++] = MESSAGE_TYPE;
        bytes[pos++] = VERSION;
        pos = Util.writeStringToByteArray(ecnTradeId, bytes, pos);
        pos = Util.writeStringToByteArray(orderId, bytes, pos);
        bytes[pos++] = (byte) exchange.ordinal();
        bytes[pos++] = (byte) currencyPair.ordinal();
        bytes[pos++] = (byte) side.ordinal();
        pos = Util.writeFloatToByteArray(quantity, bytes, pos);
        pos = Util.writeFloatToByteArray(price, bytes, pos);
        pos = Util.writeLongToByteArray(executionTime.getTime(), bytes, pos);
        pos = Util.writeLongToByteArray(afxTime.getTime(), bytes, pos);

        return bytes;
    }

    private int getLength() {
        return 2 + ecnTradeId.length() + 1 + orderId.length() + 1 + 1 + 1 + 1 + 4 + 4 + 8 + 8;
    }

    public String getEcnTradeId() {
        return ecnTradeId;
    }

    public void setEcnTradeId(String ecnTradeId) {
        this.ecnTradeId = ecnTradeId;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public CurrencyPair getCurrencyPair() {
        return currencyPair;
    }

    public void setCurrencyPair(CurrencyPair currencyPair) {
        this.currencyPair = currencyPair;
    }

    public Exchange getExchange() {
        return exchange;
    }

    public void setExchange(Exchange exchange) {
        this.exchange = exchange;
    }

    public Side getSide() {
        return side;
    }

    public void setSide(Side side) {
        this.side = side;
    }

    public float getQuantity() {
        return quantity;
    }

    public void setQuantity(float quantity) {
        this.quantity = quantity;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public Date getExecutionTime() {
        return executionTime;
    }

    public void setExecutionTime(Date executionTime) {
        this.executionTime = executionTime;
    }
    
    public Date getAfxTime() {
        return afxTime;
    }

    public void setAfxTime(Date afxTime) {
        this.afxTime = afxTime;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(ecnTradeId).append('\t');
        sb.append(orderId).append('\t');
        sb.append(exchange).append('\t');
        sb.append(currencyPair).append('\t');
        sb.append(side).append('\t');
        sb.append(quantity).append('\t');
        sb.append(price).append('\t');
        sb.append(executionTime.toString()).append('\t');
        sb.append(afxTime.toString());

        return sb.toString();
    }
}
