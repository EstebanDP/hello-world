package com.wellsfargo.fx.afx.common.messaging;

import com.latencybusters.lbm.LBMSourceEventCallback;

public interface MessagingManager {

	public MessageSender getSenderForTopic(String topicName);
	
	public MessageSender getSenderForTopic(String topicName, LBMSourceEventCallback sourceEventCallback);

	public MessageReceiver getReceiverForTopic(String topicName, MessageListener listener);
	
	public MessageReceiver getReceiverForTopic(String topicName, EOSMessageListener listener);
}
