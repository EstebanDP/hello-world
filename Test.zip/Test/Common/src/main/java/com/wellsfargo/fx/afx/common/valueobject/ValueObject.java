package com.wellsfargo.fx.afx.common.valueobject;

public abstract class ValueObject {
    private int messageType;

    public abstract byte[] toBytes();

    public abstract int readFrom(byte[] bytes);

    public int getMessageType() {
        return messageType;
    }

    public void setMessageType(int messageType) {
        this.messageType = messageType;
    }

}
