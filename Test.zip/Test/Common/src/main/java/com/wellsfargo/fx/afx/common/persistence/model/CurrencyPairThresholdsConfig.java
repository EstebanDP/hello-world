package com.wellsfargo.fx.afx.common.persistence.model;

import java.math.BigDecimal;

public class CurrencyPairThresholdsConfig {
	private String strategyName;
	private String currencyPair;
	private boolean enabled;
	private BigDecimal shortThreshold;
	private BigDecimal longThreshold;
	private String updatedByUser;
	private boolean updated;
	
	public void setStrategyName(String strategyName) {
		this.strategyName = strategyName;
	}

	public String getStrategyName() {
		return strategyName;
	}	
	
	public void setCurrencyPair(String currencyPair) {
		this.currencyPair = currencyPair;
	}
	
	public String getCurrencyPair() {
		return currencyPair;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	public boolean isEnabled() {
		return enabled;
	}

	public void setShortThreshold(BigDecimal shortThreshold) {
		this.shortThreshold = shortThreshold;
	}

	public BigDecimal getShortThreshold() {
		return shortThreshold;
	}

	public void setLongThreshold(BigDecimal longThreshold) {
		this.longThreshold = longThreshold;
	}

	public BigDecimal getLongThreshold() {
		return longThreshold;
	}

	public void setUpdatedByUser(String updatedByUser) {
		this.updatedByUser = updatedByUser;
	}

	public String getUpdatedByUser() {
		return updatedByUser;
	}

	public void setUpdated(boolean updated) {
		this.updated = updated;
	}

	public boolean isUpdated() {
		return updated;
	}
}
