package com.wellsfargo.fx.afx.common.messaging.impl;

import com.latencybusters.lbm.LBMContext;
import com.latencybusters.lbm.LBMEventQueue;
import com.latencybusters.lbm.LBMException;
import com.latencybusters.lbm.LBMReceiverAttributes;
import com.wellsfargo.fx.afx.common.messaging.MessageListener;
import com.wellsfargo.fx.afx.common.messaging.MessageReceiver;
import com.wellsfargo.fx.afx.common.messaging.EOSMessageListener;
import com.wellsfargo.fx.afx.common.util.AFXThread;

class MessageReceiverLBM implements MessageReceiver {

    private LBMRcvThread lbmRcvThread;
    private String topicName;
    private LBMEventQueue queue;

    private LBMReceiverAttributes rattr;
    private MessageListener listener;
    private EOSMessageListener eosListener;

    public MessageReceiverLBM(String topicName) {
        this.topicName = topicName;
        initConfig();
        createEventQueue();
    }

    public MessageReceiverLBM(LBMContext context, String topicName, MessageListener listener) {
        this(topicName);
        this.listener = listener;
        createReceiver(context, false);
    }

    public MessageReceiverLBM(LBMContext context, String topicName, EOSMessageListener eosListener) {
        this(topicName);
        this.eosListener = eosListener;
        createReceiver(context, true);
    }

    private void createEventQueue() {
        try {
            queue = new LBMEventQueue();
        } catch (LBMException ex) {

            System.err.println("Error Creating Event Queue: " + ex.toString());
        }
    }

    private void initConfig() {
        try {
            rattr = new LBMReceiverAttributes();
        } catch (LBMException ex) {
            System.err.println("Error Creating Receiver Attributes: " + ex.toString());
            System.exit(1);
        }
    }

    private void createReceiver(LBMContext context, boolean isServerProxyReceiver) {
        try {
            if (isServerProxyReceiver) {
                System.out.println("Creating SERVER PROXY receiver for topic " + topicName);
                new LBMEOSReceiver(context, context.lookupTopic(this.topicName, rattr), queue, eosListener);

            } else {
                System.out.println("Creating Receiver for Topic " + topicName);
                new LBMRcvReceiver(context, context.lookupTopic(this.topicName, rattr), queue, listener);
            }
        } catch (LBMException ex) {
            System.err.println("Error Creating Receiver: " + ex.toString());
            System.exit(1);
        }

        System.out.println("Created Receiver For Topic " + topicName);

        lbmRcvThread = new LBMRcvThread();
        System.out.println("Created Receiver Thread for Topic " + topicName);
    }

    @Override
    public String getTopicName() {
        return topicName;
    }

    @Override
    public void start() {
        lbmRcvThread.start();
        System.out.println("Started Receiver Thread for Topic " + topicName);
    }

    @Override
    public void stop() {
        if (lbmRcvThread != null) {
            lbmRcvThread.stop();
            System.out.println("Stopped Receiver Thread for Topic " + topicName);
        } else {
            System.out.println("Failed to Stop Receiver thread for Topic " + topicName + ", Receiver Thread is NULL");
        }
    }

    private class LBMRcvThread implements Runnable {
        private Thread myThread;
        private boolean isRunning = false;

        public LBMRcvThread() {
        }

        public void start() {
            isRunning = true;
            myThread = new AFXThread(this);
            myThread.setName(topicName);
            myThread.setDaemon(true);

            myThread.start();
        }

        public void stop() {
            isRunning = false;
        }

        public void run() {
            while (isRunning) {
                try {
                    queue.run(10000);
                    // printQueueStats(new LBMEventQueueStatistics(queue));
                } catch (Exception e) {
                    System.err.println("Exception caught by LBMRcvThread");
                    e.printStackTrace();
                    System.exit(1);
                }
            }
        }

        /*
         * Enable this code to monitor event queue for statistics Should not be used for production deployment since monitoring the event queue will add extra latency to the process set on the configuration file, event_queue queue_age_enabled 1 event_queue_count_enabled 1 event_queue queue_service_time_enabled 1
         */

        /*
         * private void printQueueStats(LBMEventQueueStatistics eventQueueStatistics) { try { System.out.println("******************************************************"); System.out.println("Number of Data Messages: + " + String.valueOf(eventQueueStatistics.dataMessages())); System.out.println("Total Number of Data Messages: + " + String.valueOf(eventQueueStatistics.dataMessagesTotal()));
         * 
         * System.out.println("Number of Events Currently Enqueued: + " + String.valueOf(eventQueueStatistics.events())); System.out.println("Total Number of Events Currently Enqueued: + " + String.valueOf(eventQueueStatistics.eventsTotal()));
         * 
         * System.out.println("Maximum Service Time: + " + String.valueOf(eventQueueStatistics.dataMessagesMaximumServiceTime())); System.out.println("Minimum Service Time: + " + String.valueOf(eventQueueStatistics.dataMessagesMinimumServiceTime())); System.out.println("Mean Service Time: + " + String.valueOf(eventQueueStatistics.dataMessagesMeanServiceTime()));
         * 
         * System.out.println("Maximum Age: + " + String.valueOf(eventQueueStatistics.maximumAge())); System.out.println("Minimum Age: + " + String.valueOf(eventQueueStatistics.minimumAge())); System.out.println("Mean Age: + " + String.valueOf(eventQueueStatistics.meanAge()));
         * 
         * } catch (LBMException exception) { exception.printStackTrace(); } }
         */
    }
}