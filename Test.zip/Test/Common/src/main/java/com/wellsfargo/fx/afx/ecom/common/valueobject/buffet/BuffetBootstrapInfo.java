package com.wellsfargo.fx.afx.ecom.common.valueobject.buffet;

import com.wellsfargo.fx.afx.common.valueobject.MessageType;
import com.wellsfargo.fx.afx.common.valueobject.ValueObject;
import com.wellsfargo.fx.afx.ecom.common.valueobject.PositionVo;

public class BuffetBootstrapInfo extends ValueObject {

    private static final byte MESSAGE_TYPE = (byte) MessageType.BUFFET_BOOTSTRAP_INFO;
    private static final byte VERSION = 1;

    private PositionVo positions = new PositionVo();

    public PositionVo getPositions() {
        return positions;
    }

    public void setPositions(PositionVo positions) {
        this.positions = positions;
    }

    @Override
    public int readFrom(byte[] bytes) {
        int pos = 2 + 2; // skip type and version for both BuffetBootstrapInfo and PositionVo
        return positions.readFrom(bytes, pos);
    }

    @Override
    public byte[] toBytes() {
        int pos = 0;
        byte[] bytes = new byte[1 + 1 + positions.getLength()];
        bytes[pos++] = MESSAGE_TYPE;
        bytes[pos++] = VERSION;
        positions.writeBytes(bytes, pos);
        return bytes;
    }
}
