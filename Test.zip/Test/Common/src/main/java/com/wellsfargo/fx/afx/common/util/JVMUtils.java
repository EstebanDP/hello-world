package com.wellsfargo.fx.afx.common.util;

import com.wellsfargo.fx.afx.common.log.Logger;
import com.wellsfargo.fx.afx.common.log.impl.AbstractLogger;
import com.wellsfargo.fx.afx.common.messaging.MessageSender;
import com.wellsfargo.fx.afx.common.messaging.impl.MessagingManagerFactory;
import com.wellsfargo.fx.afx.common.valueobject.JVMStatus;
import com.wellsfargo.fx.afx.common.valueobject.JVMStatusEnum;

public class JVMUtils {

    private static MessageSender messageSender;
    private static long jvmShutDownTtlMilli = Long.MIN_VALUE;

    private static void loadConfig(Logger logger) {
        try {
            jvmShutDownTtlMilli = Integer.parseInt(ConfigurationLoader.getInstance().getString("jvm.shutdown.ttl", true));

            if (Util.isComponentConnectedToServerProxy()) {
            	String senderTopic = ConfigurationLoader.getInstance().getString(CommonConstants.CONST_SEND_TO_SERVER_PROXY_TOPIC);
                messageSender = MessagingManagerFactory.getMessagingManager().getSenderForTopic(senderTopic, null);
            }

        } catch (Exception e) {
            logger.info("Exception caught when loading JVM parameters: " + e);

            if (jvmShutDownTtlMilli == Long.MIN_VALUE) {
                jvmShutDownTtlMilli = 3000;
            }

            logger.info("Setting parameters to default values, jvmShutDownTtlMilli: " + jvmShutDownTtlMilli + ", componentName: " + CommonConstants.VALUE_COMPONENT_NAME);
        }
    }

	public static void killJVM(Logger logger, boolean sendToServerProxy, boolean isGracefulShutdown, Exception exception) {
    	try {
			logger.setEnableLogging(true);
			loadConfig(logger);
			
			if (exception != null && !isGracefulShutdown) {
				logger.info(exception);
			}
			
			logger.info("Going to sleep for " + jvmShutDownTtlMilli + " ms to flush the logs before killing " + CommonConstants.VALUE_COMPONENT_NAME + "...");
			AbstractLogger.flushAll();

			if (sendToServerProxy) {
			    JVMStatus jvmStatus = new JVMStatus(CommonConstants.VALUE_COMPONENT_NAME, JVMStatusEnum.DOWN);
			    jvmStatus.setReason(exception.getMessage());
			    messageSender.send(jvmStatus.toBytes());
			}

			try {
			    Thread.sleep(jvmShutDownTtlMilli);
			} catch (InterruptedException interruptedException) {
			    logger.info(interruptedException.getMessage());
			}
		} catch (Exception e) {
			exception.printStackTrace();
			System.out.println("Exception caught while killing JVM: " + e);
		} finally {
			System.exit(-1);
		}
    }
}