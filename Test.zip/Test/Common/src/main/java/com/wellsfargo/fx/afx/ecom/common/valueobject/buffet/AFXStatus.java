package com.wellsfargo.fx.afx.ecom.common.valueobject.buffet;

import com.wellsfargo.fx.afx.common.util.Util;
import com.wellsfargo.fx.afx.common.valueobject.MessageType;
import com.wellsfargo.fx.afx.common.valueobject.ValueObject;

public class AFXStatus extends ValueObject {

	private AFXStatusEnum afxStatusEnum = AFXStatusEnum.DOWN;
	private static final byte version = 1;
	private boolean resendStatusEvenIfSame;
	
	public enum AFXStatusEnum {
		DOWN, UP, STANDBY, RUNNING;
		
		public static AFXStatusEnum valueOf(int ordinal) {
			if (ordinal == DOWN.ordinal()) {
				return DOWN;
			} else if (ordinal == UP.ordinal()) {
				return UP;
			} else if (ordinal == STANDBY.ordinal()) {
				return STANDBY;
			} else if (ordinal == RUNNING.ordinal()) {
				return RUNNING;
			}

			return null;
		}
	}
	
	public AFXStatus() {		
	}
	
	public AFXStatus(AFXStatusEnum afxStatusEnum) {
		this.afxStatusEnum = afxStatusEnum;
	}

    @Override
    public int readFrom(byte[] bytes) {
        int pos = 2; // skip type and version
        afxStatusEnum = AFXStatusEnum.valueOf(bytes[pos++]);
        resendStatusEvenIfSame = Util.byteToBoolean(bytes[pos++]);
        return pos;
    }

    @Override
    public byte[] toBytes() {
        int length = 1 + 1 + 1 + 1;
        byte[] bytes = new byte[length];

        int pos = 0;
        bytes[pos++] = MessageType.AFX_STATUS;
        bytes[pos++] = version;
        bytes[pos++] = (byte) afxStatusEnum.ordinal();
        bytes[pos++] = Util.booleanToByte(resendStatusEvenIfSame);

        return bytes;
    }

	public void setAfxStatusEnum(AFXStatusEnum afxStatusEnum) {
		this.afxStatusEnum = afxStatusEnum;
	}

	public AFXStatusEnum getAfxStatusEnum() {
		return afxStatusEnum;
	}
	
	public void setResendStatusEvenIfSame(boolean resendStatusEvenIfSame) {
		this.resendStatusEvenIfSame = resendStatusEvenIfSame;
	}

	public boolean isResendStatusEvenIfSame() {
		return resendStatusEvenIfSame;
	}
	
	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("\n********* AFX Status *********");
		sb.append("\nResend status even if same: " + resendStatusEvenIfSame);
		sb.append("\nStatus: " + afxStatusEnum.toString());

        return sb.toString();
	}
}

