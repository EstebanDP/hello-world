package com.wellsfargo.fx.afx.common.valueobject.gui;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.util.Collection;
import java.util.Map;

import javolution.util.FastMap;

import com.wellsfargo.fx.afx.common.log.Logger;
import com.wellsfargo.fx.afx.common.log.impl.LoggerFactory;
import com.wellsfargo.fx.afx.common.util.CommonConstants;
import com.wellsfargo.fx.afx.common.util.Util;
import com.wellsfargo.fx.afx.common.valueobject.Currency;
import com.wellsfargo.fx.afx.common.valueobject.MessageType;
import com.wellsfargo.fx.afx.common.valueobject.ValueObject;

public class UsdEquivalentPositionInfo extends ValueObject {
    private static final Logger log = LoggerFactory.getLogger();
    private static final byte version = 1;
    private static final MathContext mc = new MathContext(10, RoundingMode.HALF_DOWN);
    private static final BigDecimal ZERO = new BigDecimal(0);;
    private Map<Currency, UsdEquivalentPositionDetail> positionDetails = new FastMap<Currency, UsdEquivalentPositionDetail>();

    @Override
    public synchronized int readFrom(byte[] bytes) {
        if (bytes[0] != MessageType.USD_EQUIVALENT_POSITION_INFO) {
            throw new RuntimeException("Wrong message type. Expected " + MessageType.POSITION_INFO + ". Found " + bytes[0]);
        }
        int pos = 2; // skip type and version
        int length = bytes[pos++];

        for (int i = 0; i < length; i++) {
            UsdEquivalentPositionDetail detail = new UsdEquivalentPositionDetail();
            pos = detail.readFrom(bytes, pos);
            positionDetails.put(detail.getCurrency(), detail);
        }
        return pos;
    }

    public synchronized void addPositionDetail(UsdEquivalentPositionDetail positionDetail) {
        positionDetails.put(positionDetail.getCurrency(), positionDetail);
    }

    public synchronized Collection<UsdEquivalentPositionDetail> getPositionDetails() {
        return positionDetails.values();
    }

    public synchronized UsdEquivalentPositionDetail getPositionDetail(Currency currency) {
        return positionDetails.get(currency);
    }

    public void addPositions(UsdEquivalentPositionInfo addlPosition) {
        // log.debug("Adding position " + addlPosition.toString() + " to " + toString());
        for (UsdEquivalentPositionDetail apd : addlPosition.getPositionDetails()) {
            UsdEquivalentPositionDetail pd = positionDetails.get(apd.getCurrency());
            if (pd == null) {
                pd = new UsdEquivalentPositionDetail(apd.getCurrency());
                positionDetails.put(apd.getCurrency(), pd);
            }
            pd.setPosition(pd.getPosition().add(apd.getPosition()));
        }
        // log.debug("Position after addition " + toString());
    }

    public BigDecimal getPnL() {
        StringBuffer sb = new StringBuffer();
        for (UsdEquivalentPositionDetail pd : positionDetails.values()) {
            sb.append(pd.getCurrency()).append(':').append(pd.getPosition()).append('/').append(pd.getUsdEquivalentPosition()).append('\t');
        }
        if (sb.length() > 0) {
            log.debug(sb.toString());
        }
        BigDecimal pnl = new BigDecimal(0, mc);
        for (UsdEquivalentPositionDetail pd : positionDetails.values()) {
            if (pd.getUsdEquivalentPosition().compareTo(CommonConstants.CONST_NA_BIG_DECIMAL) == 0) {
                return CommonConstants.CONST_NA_BIG_DECIMAL;
            } else {
                pnl = pnl.add(pd.getUsdEquivalentPosition());
            }
        }
        return pnl;
    }

    public BigDecimal getGrossAggregatePosition() {
        BigDecimal gap = new BigDecimal(0);
        for (UsdEquivalentPositionDetail pd : positionDetails.values()) {
            if (pd.getCurrency() != Currency.USD) {
                if (pd.getUsdEquivalentPosition().compareTo(CommonConstants.CONST_NA_BIG_DECIMAL) == 0) {
                    return CommonConstants.CONST_NA_BIG_DECIMAL;
                } else {
                    gap = gap.add(pd.getUsdEquivalentPosition().abs());
                }
            }
        }
        return gap;
    }

    public boolean hasWholePositions() {
        for (UsdEquivalentPositionDetail pd : positionDetails.values()) {
            if (pd.getCurrency() == Currency.USD || pd.getCurrency() == Currency.getByName("EUR")) {
                if (pd.getPosition().abs().floatValue() >= 1) {
                    return true;
                }
            }
        }
        return false;
    }

    public boolean hasResidualPositions() {
        for (UsdEquivalentPositionDetail pd : positionDetails.values()) {
            if (pd.getCurrency() != Currency.USD) {
                if (pd.getPosition().compareTo(ZERO) != 0) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    public synchronized byte[] toBytes() {
        int length = 1 + 1 + 1 + 1;
        for (UsdEquivalentPositionDetail detail : positionDetails.values()) {
            length += detail.byteLength();
        }
        byte[] bytes = new byte[length];

        int pos = 0;
        bytes[pos++] = MessageType.USD_EQUIVALENT_POSITION_INFO;
        bytes[pos++] = version;
        bytes[pos++] = (byte) positionDetails.size();
        for (UsdEquivalentPositionDetail detail : positionDetails.values()) {
            pos = detail.toBytes(bytes, pos);
        }
        return bytes;
    }

    public Collection<Currency> getCurrencies() {
        return positionDetails.keySet();
    }

    public static class UsdEquivalentPositionDetail extends PositionInfo.PositionDetail {
        private BigDecimal usdEquivalentPosition = ZERO;

        public UsdEquivalentPositionDetail(Currency currency) {
            setCurrency(currency);
        }

        UsdEquivalentPositionDetail() {
        }

        public BigDecimal getUsdEquivalentPosition() {
            return usdEquivalentPosition;
        }

        public void setUsdEquivalentPosition(BigDecimal usdEquivalentPosition) {
            if (usdEquivalentPosition.compareTo(CommonConstants.CONST_NA_BIG_DECIMAL) == 0) {
                this.usdEquivalentPosition = usdEquivalentPosition;
            } else {
                this.usdEquivalentPosition = usdEquivalentPosition.setScale(getScale(), RoundingMode.HALF_DOWN);
            }
        }

        public int byteLength() {
            return super.byteLength() + 1 + usdEquivalentPosition.toPlainString().length();
        }

        public int readFrom(byte[] bytes, int pos) {
            pos = super.readFrom(bytes, pos);
            int length = bytes[pos++];
            String str = Util.readStringFromBytes(bytes, length, pos);
            if (str.equals("NA")) {
                usdEquivalentPosition = CommonConstants.CONST_NA_BIG_DECIMAL;
            } else {
                usdEquivalentPosition = new BigDecimal(str);
            }
            pos += length;
            return pos;
        }

        public int toBytes(byte[] bytes, int pos) {
            pos = super.toBytes(bytes, pos);
            if (usdEquivalentPosition.compareTo(CommonConstants.CONST_NA_BIG_DECIMAL) == 0) {
                pos = Util.writeStringToByteArray("NA", bytes, pos);
            } else {
                pos = Util.writeStringToByteArray(usdEquivalentPosition.toPlainString(), bytes, pos);
            }
            return pos;
        }
    }

    public String toString() {
    	StringBuilder tb = new StringBuilder();
        tb.append("Positions: ");
        for (UsdEquivalentPositionDetail pd : positionDetails.values()) {
            tb.append(pd.getCurrency()).append(':').append(pd.getUsdEquivalentPosition().toPlainString()).append('(').append(pd.getPosition().toPlainString()).append(")\t");
        }
        BigDecimal pnl = getPnL();
        BigDecimal gap = getGrossAggregatePosition();
        tb.append("P/L: ").append(pnl.floatValue() != CommonConstants.CONST_NA ? getPnL().multiply(new BigDecimal(1000000), mc).toPlainString() : "N/A").append("\t");
        tb.append("GAP: ").append(gap.floatValue() != CommonConstants.CONST_NA ? getGrossAggregatePosition().toPlainString() : "N/A");
        return tb.toString();
    }
}
