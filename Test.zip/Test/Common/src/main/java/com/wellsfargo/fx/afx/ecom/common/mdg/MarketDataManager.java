package com.wellsfargo.fx.afx.ecom.common.mdg;

import java.util.Set;

import com.wellsfargo.fx.afx.common.valueobject.CurrencyPair;
import com.wellsfargo.fx.afx.ecom.common.valueobject.marketdata.CurrencyPairSnapshot;
import com.wellsfargo.fx.afx.ecom.common.valueobject.marketdata.EcomMarketTick;

public interface MarketDataManager {

    public void start();

    public void stop();

    public void mergeDelta(EcomMarketTick marketTick);

    public CurrencyPairSnapshot getSnapshot(CurrencyPair currencyPair);

    public Set<CurrencyPair> getCurrencyPairs();

    public void registerMarketDataListener(MarketDataListener marketDataListener);

}