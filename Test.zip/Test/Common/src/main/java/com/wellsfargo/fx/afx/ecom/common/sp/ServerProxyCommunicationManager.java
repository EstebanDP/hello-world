package com.wellsfargo.fx.afx.ecom.common.sp;

public interface ServerProxyCommunicationManager {

    public void start();

    public void stop();

    public void send(byte[] bytes);

}
