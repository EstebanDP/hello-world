package com.wellsfargo.fx.afx.common.valueobject.orderdata;

public enum TransactionStatus {
    CANCELLED_POSITIONS, HANDLED_RESIDUALS, DENIED;

    static TransactionStatus valueOf(byte ordinal) {
        if (CANCELLED_POSITIONS.ordinal() == ordinal) {
            return CANCELLED_POSITIONS;
        } else if (HANDLED_RESIDUALS.ordinal() == ordinal) {
            return HANDLED_RESIDUALS;
        } else if (DENIED.ordinal() == ordinal) {
            return DENIED;
        } else {
            return null;
        }
    }
}
