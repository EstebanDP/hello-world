package com.wellsfargo.fx.afx.common.valueobject.marketdata;

import com.wellsfargo.fx.afx.common.util.Util;
import com.wellsfargo.fx.afx.common.valueobject.MessageType;
import com.wellsfargo.fx.afx.common.valueobject.ValueObject;

public class MarketTickWarmupRequest extends ValueObject {
	
	private static final byte version = 1;
	private int strategyId;
	private int numberOfRequests;

	public MarketTickWarmupRequest() {
		
	}
	
	public MarketTickWarmupRequest(int strategyId, int numberOfRequests) {
		this.strategyId = strategyId;
		this.numberOfRequests = numberOfRequests;
	}
	
	public int getStrategyId() {
        return strategyId;
    }

    public void setStrategyId(int strategyId) {
        this.strategyId = strategyId;
    }
    
    public int getNumberOfRequests() {
        return numberOfRequests;
    }

    public void setNumberOfRequests(int numberOfRequests) {
        this.numberOfRequests = numberOfRequests;
    }
    
	@Override
	public int readFrom(byte[] bytes) {
		int pos = 2; // skip type and version
		strategyId = Util.readIntFromBytes(bytes, pos);
		pos += 4;
		numberOfRequests = Util.readIntFromBytes(bytes, pos);
        
        return pos;
	}

	@Override
	public byte[] toBytes() {
		int length = 1 + 1 + 4 + 4;
        byte[] bytes = new byte[length];
		int pos = 0;
        bytes[pos++] = MessageType.MARKET_TICK_WARMUP_REQUEST;
        bytes[pos++] = version;
        pos = Util.writeIntToByteArray(strategyId, bytes, pos);
        pos = Util.writeIntToByteArray(numberOfRequests, bytes, pos);
        
        return bytes;
	}
	
	public String toString() {
		String str = "Strategy Id: " + strategyId;
		str += "\nNumber Of Requests: " + numberOfRequests;
        return str;
	}

}
