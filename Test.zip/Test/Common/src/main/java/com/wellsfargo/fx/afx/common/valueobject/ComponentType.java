package com.wellsfargo.fx.afx.common.valueobject;

public enum ComponentType {
    ARB, ECOM;

    public static ComponentType valueOf(final int ordinal) {
        if (ordinal == ARB.ordinal()) {
            return ARB;
        } else if (ordinal == ECOM.ordinal()) {
            return ECOM;
        } 
        return null;
    }
    
    public static ComponentType getByName(String name) {
        return valueOf(name);
    }
}