package com.wellsfargo.fx.afx.common.valueobject.gui;

import java.util.List;

import com.wellsfargo.fx.afx.common.util.ConfigurationLoader;
import com.wellsfargo.fx.afx.common.util.Util;
import com.wellsfargo.fx.afx.common.valueobject.MessageType;
import com.wellsfargo.fx.afx.common.valueobject.ValueObject;

public class LoginMessage extends ValueObject {

    private String userName;
    private String password;
    private String strategies;
    private boolean authenticate = false;
    private final String DOUBLE_HASH = "##";
    private final String AT = "@";
    private final String DOLLAR = "$";

    public LoginMessage() {
    }

    public LoginMessage(String userName, String password) {
        this.userName = userName;
        this.password = password;
    }

    @Override
    public int readFrom(byte[] bytes) {

        String credentials = new String(bytes);
        String[] arr = credentials.trim().split(DOUBLE_HASH);
        this.userName = arr[0];
        this.password = arr[1];
        this.authenticate = Boolean.valueOf(arr[2]).booleanValue();

        if (authenticate) {
            this.strategies = arr[3];
        }
        return -1;
    }

    @Override
    public byte[] toBytes() {

        String credentials = userName + DOUBLE_HASH + password + DOUBLE_HASH + authenticate;
        if (authenticate) {
            credentials += DOUBLE_HASH;
            List<String> strategyNamesList = Util.cast(ConfigurationLoader.getInstance().getList("strategy.name"));
            List<String> strategyIdsList = Util.cast(ConfigurationLoader.getInstance().getList("strategy.id"));
            List<String> pipsList = Util.cast(ConfigurationLoader.getInstance().getList("strategy.triggerpip"));
            List<String> firstCcyList = Util.cast(ConfigurationLoader.getInstance().getList("strategy.currencypair.1"));
            List<String> secondCcyList = Util.cast(ConfigurationLoader.getInstance().getList("strategy.currencypair.2"));
            List<String> thirdCcyList = Util.cast(ConfigurationLoader.getInstance().getList("strategy.currencypair.3"));

            List<String> depthOneList = Util.cast(ConfigurationLoader.getInstance().getList("strategy.depthofbook.1"));
            List<String> depthTwoList = Util.cast(ConfigurationLoader.getInstance().getList("strategy.depthofbook.2"));
            List<String> depthThreeList = Util.cast(ConfigurationLoader.getInstance().getList("strategy.depthofbook.3"));

            int count = strategyNamesList.size();
            String strategy = "";
            for (int i = 0; i < count; i++) {
                String depth = depthOneList.get(i) + " / " + depthTwoList.get(i) + " / " + depthThreeList.get(i);

                strategy += strategyNamesList.get(i) + AT + strategyIdsList.get(i) + AT + firstCcyList.get(i) + AT + secondCcyList.get(i) + AT + thirdCcyList.get(i) + AT + pipsList.get(i) + AT + depth + DOLLAR;
            }
            credentials += strategy + DOUBLE_HASH;
        }

        byte[] original = credentials.getBytes();
        int length = original.length;
        byte[] messageArray = new byte[length];
        messageArray[0] = MessageType.LOGIN_MESSAGE;

        for (int i = 1; i < original.length; i++) {
            messageArray[i] = original[i];
        }

        return messageArray;
    }

    public boolean isAuthenticate() {
        return authenticate;
    }

    public void setAuthenticate(boolean authenticate) {
        this.authenticate = authenticate;
    }

    public String getStrategies() {
        return strategies;
    }

}
