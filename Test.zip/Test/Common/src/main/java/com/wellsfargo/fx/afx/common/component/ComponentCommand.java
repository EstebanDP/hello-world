package com.wellsfargo.fx.afx.common.component;

import com.wellsfargo.fx.afx.common.valueobject.MessageType;
import com.wellsfargo.fx.afx.common.valueobject.ValueObject;

public class ComponentCommand extends ValueObject {
    private static final int MESSAGE_TYPE = MessageType.COMPONENT_COMMAND;
    private static final int VERSION = 1;

    public enum Command {
        WARM_UP, POST_WARM_UP, INIT, RUN;

        private static Command valueOf(int ordinal) {
            if (WARM_UP.ordinal() == ordinal) {
                return WARM_UP;
            } else if (POST_WARM_UP.ordinal() == ordinal) {
                return POST_WARM_UP;
            } else if (INIT.ordinal() == ordinal) {
                return INIT;
            } else if (RUN.ordinal() == ordinal) {
                return RUN;
            }
            return null;
        }

    }

    private Command command;

    @Override
    public int readFrom(byte[] bytes) {
        command = Command.valueOf(bytes[2]);
        return 3;
    }

    @Override
    public byte[] toBytes() {
        byte[] bytes = new byte[3];
        int pos = 0;
        bytes[pos++] = MESSAGE_TYPE;
        bytes[pos++] = VERSION;
        bytes[pos++] = (byte) command.ordinal();

        return bytes;
    }

    public Command getCommand() {
        return command;
    }

    public void setCommand(Command command) {
        this.command = command;
    }

}
