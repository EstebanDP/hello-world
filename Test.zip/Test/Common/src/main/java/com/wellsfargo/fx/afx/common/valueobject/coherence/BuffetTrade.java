package com.wellsfargo.fx.afx.common.valueobject.coherence;

import java.io.Serializable;
import java.util.Date;

import com.wellsfargo.fx.afx.ecom.common.valueobject.buffet.BuffetTradeStatus;

@SuppressWarnings("serial")
public class BuffetTrade implements Serializable, Cloneable {

    private String transactionId;
    private String buffetTradeId;
    private String sourceTradeId;
    private String userId;
    private String currencyPair;
    private String side;
    private String source;
    private String rate;
    private String marketRateBid;
    private String marketRateOffer;
    private String reasonForReject;
    private BuffetTradeStatus buffetTradeStatus;
    
    private Date sourceExecutionTime;
    private Date buffetSentTime;
    private Date afxTime;
    private int tradeCounter = -1; // used by GUI

    private double quantity;
    private boolean duplicateTrade = false;
    private boolean initialPosition = false;

    public String getBuffetTradeId() {
        return buffetTradeId;
    }

    public void setBuffetTradeId(String buffetTradeId) {
        this.buffetTradeId = buffetTradeId;
    }

    public String getSourceTradeId() {
        return sourceTradeId;
    }

    public void setSourceTradeId(String sourceTradeId) {
        this.sourceTradeId = sourceTradeId;
    }
    
	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserId() {
		return userId;
	}

    public String getCurrencyPair() {
        return currencyPair;
    }

    public void setCurrencyPair(String currencyPair) {
        this.currencyPair = currencyPair;
    }

    public double getQuantity() {
        return quantity;
    }

    public void setQuantity(double quantity) {
        this.quantity = quantity;
    }

    public String getSide() {
        return side;
    }

    public void setSide(String side) {
        this.side = side;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getSource() {
        return source;
    }

    public String getRate() {
        return rate;
    }

    public void setRate(String rate) {
        this.rate = rate;
    }
    
	public void setMarketRateBid(String marketRateBid) {
		this.marketRateBid = marketRateBid;
	}

	public String getMarketRateBid() {
		return marketRateBid;
	}

	public void setMarketRateOffer(String marketRateOffer) {
		this.marketRateOffer = marketRateOffer;
	}

	public String getMarketRateOffer() {
		return marketRateOffer;
	}

    public Date getSourceExecutionTime() {
        return sourceExecutionTime;
    }

    public void setSourceExecutionTime(Date sourceExecutionTime) {
        this.sourceExecutionTime = sourceExecutionTime;
    }

    public Date getBuffetSentTime() {
        return buffetSentTime;
    }

    public void setBuffetSentTime(Date buffetSentTime) {
        this.buffetSentTime = buffetSentTime;
    }
    
    public Date getAfxTime() {
        return afxTime;
    }

    public void setAfxTime(Date afxTime) {
        this.afxTime = afxTime;
    }

    public BuffetTradeStatus getBuffetTradeStatus() {
        return buffetTradeStatus;
    }

    public void setBuffetTradeStatus(BuffetTradeStatus buffetTradeStatus) {
        this.buffetTradeStatus = buffetTradeStatus;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getTransactionId() {
        return transactionId;
    }
    
    public void setReasonForReject(String reasonForReject) {
		this.reasonForReject = reasonForReject;
	}

	public String getReasonForReject() {
		return reasonForReject;
	}
    
	public void setDuplicateTrade(boolean duplicateTrade) {
		this.duplicateTrade = duplicateTrade;
	}

	public boolean isDuplicateTrade() {
		return duplicateTrade;
	}
	
    public void setInitialPosition(boolean initialPosition) {
		this.initialPosition = initialPosition;
	}

	public boolean isInitialPosition() {
		return initialPosition;
	}
	
    public void setTradeCounter(int tradeCounter) {
        this.tradeCounter = tradeCounter;
    }

    public int getTradeCounter() {
        return tradeCounter;
    }

	public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(buffetTradeId).append('\t');
        sb.append(sourceTradeId).append('\t');
        sb.append(userId).append('\t');
        sb.append(buffetTradeStatus).append('\t');
        sb.append(currencyPair).append('\t');
        sb.append(duplicateTrade).append('\t');
        sb.append(initialPosition).append('\t');
        sb.append(source).append('\t');
        sb.append(sourceExecutionTime.toString()).append('\t');
        sb.append(buffetSentTime.toString()).append('\t');
        sb.append(quantity).append('\t');
        sb.append(rate).append('\t');
        sb.append(marketRateBid).append('\t');
        sb.append(marketRateOffer).append('\t');
        sb.append(reasonForReject);

        return sb.toString();
    }
    
    public Object clone() {
        try {
            return super.clone();
        } catch (CloneNotSupportedException e) {
            throw new RuntimeException("Unexpected state - unable to clone Buffet Trade", e);
        }
    }
}