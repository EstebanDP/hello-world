package com.wellsfargo.fx.afx.ecom.common.valueobject.buffet;

import java.util.Date;

import com.wellsfargo.fx.afx.common.util.Util;
import com.wellsfargo.fx.afx.common.valueobject.CurrencyPair;
import com.wellsfargo.fx.afx.common.valueobject.MessageType;
import com.wellsfargo.fx.afx.common.valueobject.Side;
import com.wellsfargo.fx.afx.common.valueobject.ValueObject;

public class PositionTransfer extends ValueObject {
    private static final byte messageType = MessageType.POSITION_TRANSFER;
    private static final byte version = 1;
    
    private String positionTransferBuffetId;
    private String currencyPair;
    private CurrencyPair currencyPairVO;
    private double quantity;
    private double ctrQuantity;
    private float rate;
    private String source;
    private String bookFrom;
    private String bookTo;
    private String portfolio;
    private Side side;
    private String userId;
    private boolean rejectedTransfer;
    private String reason;
    private String reasonForReject;
    private Date transferCreationTime;
    private Date afxTime;

    public String getPositionTransferBuffetId() {
        return positionTransferBuffetId;
    }

    public void setPositionTransferBuffetId(String positionTransferBuffetId) {
        this.positionTransferBuffetId = positionTransferBuffetId;
    }

    public String getCurrencyPair() {
        return currencyPair;
    }

    public void setCurrencyPair(String currencyPair) {
        this.currencyPair = currencyPair;
    }
    
	public void setCurrencyPairVO(CurrencyPair currencyPairVO) {
        this.currencyPairVO = currencyPairVO;
    }
	
    public CurrencyPair getCurrencyPairVO() {
        return currencyPairVO;
    }

    public double getQuantity() {
        return quantity;
    }

    public void setQuantity(double quantity) {
        this.quantity = quantity;
    }
    
    public double getCtrQuantity() {
        return ctrQuantity;
    }

    public void setCtrQuantity(double ctrQuantity) {
        this.ctrQuantity = ctrQuantity;
    }

    public float getRate() {
        return rate;
    }

    public void setRate(float rate) {
        this.rate = rate;
    }

    public Date getTransferCreationTime() {
        return transferCreationTime;
    }

    public void setTransferCreationTime(Date transferCreationTime) {
        this.transferCreationTime = transferCreationTime;
    }
    
    public Date getAfxTime() {
        return afxTime;
    }

    public void setAfxTime(Date afxTime) {
        this.afxTime = afxTime;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getSource() {
        return source;
    }

    public void setBookFrom(String bookFrom) {
		this.bookFrom = bookFrom;
	}

	public String getBookFrom() {
		return bookFrom;
	}

	public void setBookTo(String bookTo) {
		this.bookTo = bookTo;
	}

	public String getBookTo() {
		return bookTo;
	}
	
	public void setPortfolio(String portfolio) {
		this.portfolio = portfolio;
	}

	public String getPortfolio() {
		return portfolio;
	}
	
	public void setSide(Side side) {
		this.side = side;
	}

	public Side getSide() {
		return side;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserId() {
		return userId;
	}
	
	public void setRejectedTransfer(boolean rejectedTransfer) {
		this.rejectedTransfer = rejectedTransfer;
	}

	public boolean isRejectedTransfer() {
		return rejectedTransfer;
	}
	
	public void setReason(String reason) {
		this.reason = reason;
	}

	public String getReason() {
		return reason;
	}
	
    public void setReasonForReject(String reasonForReject) {
		this.reasonForReject = reasonForReject;
	}

	public String getReasonForReject() {
		return reasonForReject;
	}

	@Override
    public int readFrom(byte[] bytes) {
        int pos = 2;

        int length = bytes[pos++];
        positionTransferBuffetId = Util.readStringFromBytes(bytes, length, pos);
        pos += length;
        
        length = bytes[pos++];
        currencyPair = Util.readStringFromBytes(bytes, length, pos);
        pos += length;

        side = Side.valueOf(bytes[pos++]);
        
        quantity = Util.readDoubleFromBytes(bytes, pos);
        pos += 8;
        ctrQuantity = Util.readDoubleFromBytes(bytes, pos);
        pos += 8;
        rate = Util.readFloatFromBytes(bytes, pos);
        pos += 4;

        length = bytes[pos++];
        source = Util.readStringFromBytes(bytes, length, pos);
        pos += length;

        length = bytes[pos++];
        bookFrom = Util.readStringFromBytes(bytes, length, pos);
        pos += length;

        length = bytes[pos++];
        bookTo = Util.readStringFromBytes(bytes, length, pos);
        pos += length;
        
        length = bytes[pos++];
        portfolio = Util.readStringFromBytes(bytes, length, pos);
        pos += length;
        
        length = bytes[pos++];
        userId = Util.readStringFromBytes(bytes, length, pos);
        pos += length;
        
        length = bytes[pos++];
        reason = Util.readStringFromBytes(bytes, length, pos);
        pos += length;
        
        length = bytes[pos++];
        reasonForReject = Util.readStringFromBytes(bytes, length, pos);
        pos += length;

        transferCreationTime = new Date(Util.readLongFromBytes(bytes, pos));
        pos += 8;
        
        afxTime = new Date(Util.readLongFromBytes(bytes, pos));
        pos += 8;

        rejectedTransfer = Util.byteToBoolean(bytes[pos++]);
        
        return pos;
    }
  
    @Override
    public byte[] toBytes() {
        byte[] bytes = new byte[getLength()];
        int pos = 0;
        bytes[pos++] = messageType;
        bytes[pos++] = version;
        pos = Util.writeStringToByteArray(positionTransferBuffetId, bytes, pos);
        pos = Util.writeStringToByteArray(currencyPair, bytes, pos);
        bytes[pos++] = (byte) side.ordinal();
        pos = Util.writeDoubleToByteArray(quantity, bytes, pos);
        pos = Util.writeDoubleToByteArray(ctrQuantity, bytes, pos);
        pos = Util.writeFloatToByteArray(rate, bytes, pos);
        pos = Util.writeStringToByteArray(source, bytes, pos);
        pos = Util.writeStringToByteArray(bookFrom, bytes, pos);
        pos = Util.writeStringToByteArray(bookTo, bytes, pos);
        pos = Util.writeStringToByteArray(portfolio, bytes, pos);
        pos = Util.writeStringToByteArray(userId, bytes, pos);
        pos = Util.writeStringToByteArray(reason, bytes, pos);
        pos = Util.writeStringToByteArray(reasonForReject, bytes, pos);
        pos = Util.writeLongToByteArray(transferCreationTime.getTime(), bytes, pos);
        pos = Util.writeLongToByteArray(afxTime.getTime(), bytes, pos);
        bytes[pos++] = Util.booleanToByte(rejectedTransfer);

        return bytes;
    }
    
    private int getLength() {
        return 2 + 1 + positionTransferBuffetId.length() + 1 + currencyPair.length() + 1 + 8 + 8 + 4 + 1 + source.length() + 1 + bookFrom.length() + 1 + bookTo.length() + 1 + portfolio.length() + 1 + userId.length() + 1 + reason.length() + 1 + reasonForReject.length() + 8 + 8 + 1;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(positionTransferBuffetId).append('\t');
        sb.append(currencyPair).append('\t');
        sb.append(side.toString()).append('\t');
        sb.append(quantity).append('\t');
        sb.append(ctrQuantity).append('\t');
        sb.append(source).append('\t');
        sb.append(bookFrom).append('\t');
        sb.append(bookTo).append('\t');
        sb.append(portfolio).append('\t');
        sb.append(userId).append('\t');
        sb.append(reason).append('\t');
        sb.append(transferCreationTime.toString()).append('\t');
        sb.append(afxTime.toString()).append('\t');
        sb.append(rejectedTransfer).append('\t');
        sb.append(reasonForReject).append('\t');

        return sb.toString();
    }
}