package com.wellsfargo.fx.afx.common.util;

import java.io.IOException;
import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.StringTokenizer;

import javolution.util.FastList;
import javolution.util.FastMap;

import com.wellsfargo.fx.afx.common.messaging.ConfigurationListener;
import com.wellsfargo.fx.afx.common.valueobject.Configuration;
import com.wellsfargo.fx.afx.common.valueobject.CurrencyPair;

public class ConfigurationLoader {

    public static final String ALL_PROPERTIES = "ALL";

    private static ConfigurationLoader self;
    private Properties properties;
    private Properties dbProperties;
    private Map<String, List<String>> propertiesAsList = new FastMap<String, List<String>>(); // used for faster retrieval, no token parsing
    private Map<String, List<ConfigurationListener>> registeredListeners;

    static {
        self = new ConfigurationLoader();
    }
    
    public static ConfigurationLoader getInstance() {
        return self;
    }

    private ConfigurationLoader() {
        registeredListeners = new FastMap<String, List<ConfigurationListener>>();
        properties = new Properties(System.getProperties());
        try {
			properties.load(this.getClass().getResourceAsStream("/" + properties.getProperty("configuration.file.name")));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.exit(-1);
		}
    }
       
	private void init() {
		// Instantiate Currency Pair object
    	CurrencyPair.values();
    }
    
    public Properties getDBProperties() {
    	return dbProperties;
    }
    
    public String getString(String property) {
    	return getString(property, false);
    }

    public String getString(String property, boolean isNullAllowed) {
    	try {
    		return validateProperty(property, isNullAllowed);
		} catch (Exception e) {
			System.err.println("Fatal error while validating property '" + property + "', exception: " + e);
			e.printStackTrace();
			System.exit(-1);
		}
		
		return null;
    }

    public int getInt(String property) {
    	try {
    		return Integer.parseInt(validateProperty(property, false));
		} catch (Exception e) {
			System.err.println("Fatal error while validating property '" + property + "', exception: " + e);
			e.printStackTrace();
			System.exit(-1);
		}
		
		return 0;
    }

    public Long getLong(String property) {
    	try {
    		return Long.parseLong(validateProperty(property, false));
		} catch (Exception e) {
			System.err.println("Fatal error while validating property '" + property + "', exception: " + e);
			e.printStackTrace();
			System.exit(-1);
		}
		
		return 0L;
    }

    public float getFloat(String property) {
    	try {
    		return Float.parseFloat(validateProperty(property, false));
		} catch (Exception e) {
			System.err.println("Fatal error while validating property '" + property + "', exception: " + e);
			e.printStackTrace();
			System.exit(-1);
		}
		
		return 0;
    }
    
    public boolean getBoolean(String property) {
    	try {
    		return Boolean.parseBoolean(validateProperty(property, false));
		} catch (Exception e) {
			System.err.println("Fatal error while validating property '" + property + "', exception: " + e);
			e.printStackTrace();
			System.exit(-1);
		}
		
		return false;
    }

    public boolean getBoolean(String property, boolean isNullAllowed) {
    	try {
    		return Boolean.parseBoolean(validateProperty(property, isNullAllowed));
		} catch (Exception e) {
			System.err.println("Fatal error while validating property '" + property + "', exception: " + e);
			e.printStackTrace();
			System.exit(-1);
		}
		
		return false;
    }
    
    public BigDecimal getBigDecimal(String property) {
    	try {
    		return new BigDecimal(validateProperty(property, false));
		} catch (Exception e) {
			System.err.println("Fatal error while validating property '" + property + "', exception: " + e);
			e.printStackTrace();
			System.exit(-1);
		}
		
		return null;
    }

    public List<String> getList(String property) {
    	try {
    		validateProperty(property, false);
		} catch (Exception e) {
			System.err.println("Fatal error while validating property '" + property + "', exception: " + e);
			e.printStackTrace();
			System.exit(-1);
			return null;
		}
    	
        if (propertiesAsList.containsKey(property)) {
            return propertiesAsList.get(property);
        } else {
            StringTokenizer token = new StringTokenizer(properties.getProperty(property), ",");
            List<String> rtnList = new FastList<String>();
            while (token.hasMoreTokens()) {
                rtnList.add(token.nextToken().trim());
            }
            propertiesAsList.put(property, rtnList);
            return rtnList;
        }
    }
    
    private String validateProperty(String property, boolean isNullAllowed) throws Exception {
    	String validatedProperty = properties.getProperty(property);
    	
    	if (!isNullAllowed && (validatedProperty == null || validatedProperty.length() <= 0)) {
    		throw new Exception(property + " is EMPTY or NULL");
    	}
    	
    	return validatedProperty;
    }

    public void updatePropertiesList(String property, int index, String newValue) {
        List<String> list = propertiesAsList.get(property);
        if (list != null) {
            list.remove(index);
            list.add(index, newValue);
        }
    }

    public void updateProperty(String property, String newValue) {
        properties.setProperty(property, newValue);
    }

    public int getPropertyIndex(String propertyList, String property) {
        int index = -1;
        List<String> list = propertiesAsList.get(propertyList);
        if (list != null) {
            for (int i = 0; i < list.size(); i++) {
                String value = list.get(i);
                if (value.equals(property)) {
                    return i;
                }
            }
        }
        return index;
    }

    public void registerListener(String propertyName, ConfigurationListener configListener) {
        List<ConfigurationListener> listenerList = registeredListeners.get(propertyName);
        if (listenerList == null) {
            listenerList = new FastList<ConfigurationListener>();
            listenerList.add(configListener);
            registeredListeners.put(propertyName, listenerList);
        } else {
            listenerList.add(configListener);
        }
    }

    public void onChange(Configuration configuration) {
    	String key = configuration.getConfigurationName();
        String value = configuration.getConfigurationValue();
        properties.setProperty(key, value);
        propertiesAsList.remove(configuration); // remove ghost value

        List<ConfigurationListener> listenerList = registeredListeners.get(configuration);
        if (listenerList != null) {
            for (ConfigurationListener listener : listenerList) {
                listener.onChange(key, value);
            }
        }

        // Dispatch events to listeners registered to all properties
        listenerList = registeredListeners.get(ALL_PROPERTIES);
        if (listenerList != null) {
            for (ConfigurationListener listener : listenerList) {
                listener.onChange(key, value);
            }
        }
    }
 
    @Override
    public String toString() {
    	StringBuilder sb = new StringBuilder("************ Properties ************\n");
    	for(Map.Entry<Object, Object> entry : properties.entrySet()) {
    		sb.append(entry.getKey()).append(" = ").append(entry.getValue()).append("\n");
    	}
    	sb.append("************ DB Properties ************\n");
    	for(Map.Entry<Object, Object> entry : dbProperties.entrySet()) {
    		sb.append(entry.getKey()).append(" = ").append(entry.getValue()).append("\n");
    	}
    	return sb.toString();
    }
    
}
