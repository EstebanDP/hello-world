package com.wellsfargo.fx.afx.ecom.common.valueobject;

import java.math.BigDecimal;
import java.math.MathContext;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import com.wellsfargo.fx.afx.common.util.CommonConstants;
import com.wellsfargo.fx.afx.common.util.Util;
import com.wellsfargo.fx.afx.common.valueobject.Currency;
import com.wellsfargo.fx.afx.common.valueobject.MessageType;
import com.wellsfargo.fx.afx.common.valueobject.ValueObject;

public class PositionVo extends ValueObject {

    private static final byte version = 1;
    private static final BigDecimal ZERO = new BigDecimal(0f, new MathContext(12));
    private Map<Currency, BigDecimal> positions = new HashMap<Currency, BigDecimal>();
    private Map<Currency, BigDecimal> usdEquivalentPositions = new HashMap<Currency, BigDecimal>();

    public synchronized void setPosition(Currency currency, BigDecimal amount, BigDecimal usdEquivalentAmount) {
        positions.put(currency, amount);
        usdEquivalentPositions.put(currency, usdEquivalentAmount);
    }

    public synchronized BigDecimal getPosition(Currency currency) {
        BigDecimal bd = positions.get(currency);
        return bd != null ? bd : ZERO;
    }

    public synchronized BigDecimal getUsdEquivalentPosition(Currency currency) {
        BigDecimal bd = usdEquivalentPositions.get(currency);
        return bd != null ? bd : ZERO;
    }

    public synchronized Set<Currency> getCurrencies() {
        return positions.keySet();
    }

    public float getPnl() {
        float pnl = 0;
        for (Currency currency : usdEquivalentPositions.keySet()) {
            float usdEquivalentPosition = usdEquivalentPositions.get(currency).floatValue();
            if (usdEquivalentPosition == CommonConstants.CONST_NA) {
                return CommonConstants.CONST_NA;
            }
            pnl += usdEquivalentPosition;
        }
        return pnl;
    }

    @Override
    public int readFrom(byte[] bytes) {
        int pos = 2; // skip type and version
        pos = readFrom(bytes, pos);
        return pos;
    }

    public int readFrom(byte[] bytes, int pos) {
        while (pos < bytes.length) {
            Currency currency = Currency.valueOf(bytes[pos++]);

            int length = bytes[pos++];
            String s = Util.readStringFromBytes(bytes, length, pos);
            pos += length;
            BigDecimal amount = new BigDecimal(s);

            length = bytes[pos++];
            s = Util.readStringFromBytes(bytes, length, pos);
            pos += length;
            BigDecimal usdEquivalentAmount = new BigDecimal(s);

            positions.put(currency, amount);
            usdEquivalentPositions.put(currency, usdEquivalentAmount);
        }
        return pos;
    }

    @Override
    public synchronized byte[] toBytes() {
        int pos = 0;
        byte[] bytes = new byte[getLength()];
        writeBytes(bytes, pos);
        return bytes;
    }

    public void writeBytes(byte[] bytes, int pos) {
        bytes[pos++] = MessageType.POSITION_VO;
        bytes[pos++] = version;
        for (Currency currency : positions.keySet()) {
            bytes[pos++] = (byte) currency.ordinal();
            pos = Util.writeStringToByteArray(positions.get(currency).toPlainString(), bytes, pos);
            pos = Util.writeStringToByteArray(usdEquivalentPositions.get(currency).toPlainString(), bytes, pos);
        }
    }

    public int getLength() {
        int length = 0;
        for (Currency currency : positions.keySet()) {
            length += 1 + positions.get(currency).toPlainString().length() + 1 + usdEquivalentPositions.get(currency).toPlainString().length() + 1;
        }
        return 1 + 1 + length;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (Currency currency : positions.keySet()) {
            sb.append(currency).append('\t').append(String.format("%1$# ,22.2f", positions.get(currency))).append('\t').append('\t').append(
                    String.format("%1$# ,22.2f", usdEquivalentPositions.get(currency))).append('\n');
        }
        return sb.toString();
    }

}
