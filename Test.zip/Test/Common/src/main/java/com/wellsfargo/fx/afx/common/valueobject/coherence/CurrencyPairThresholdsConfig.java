package com.wellsfargo.fx.afx.common.valueobject.coherence;

import java.io.Serializable;
import java.math.BigDecimal;

@SuppressWarnings("serial")
public class CurrencyPairThresholdsConfig implements Serializable {
	private String currencyPair;
	private boolean enabled;
	private BigDecimal shortThreshold;
	private BigDecimal longThreshold;
	private String userName;
	private boolean updated;
	
	public void setCurrencyPair(String currencyPair) {
		this.currencyPair = currencyPair;
	}
	
	public String getCurrencyPair() {
		return currencyPair;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	public boolean isEnabled() {
		return enabled;
	}

	public void setShortThreshold(BigDecimal shortThreshold) {
		this.shortThreshold = shortThreshold;
	}

	public BigDecimal getShortThreshold() {
		return shortThreshold;
	}

	public void setLongThreshold(BigDecimal longThreshold) {
		this.longThreshold = longThreshold;
	}

	public BigDecimal getLongThreshold() {
		return longThreshold;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserName() {
		return userName;
	}
	
	public void setUpdated(boolean updated) {
		this.updated = updated;
	}

	public boolean isUpdated() {
		return updated;
	}

	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("****************************").append("\n");
		sb.append("User Name: ").append(userName).append("\n");
		sb.append("Currency Pair: ").append(currencyPair.toString()).append("\n");
		sb.append("Short Treshold: ").append(shortThreshold.toPlainString()).append("\n");
		sb.append("Long Treshold: ").append(longThreshold.toPlainString()).append("\n");
		sb.append("Updated: ").append(updated).append("\n");
		
		return sb.toString();
	}
}
