package com.wellsfargo.fx.afx.ecom.common.sp;

import com.wellsfargo.fx.afx.common.component.BaseComponentService;
import com.wellsfargo.fx.afx.common.component.ComponentCommand;
import com.wellsfargo.fx.afx.common.component.ComponentCommand.Command;
import com.wellsfargo.fx.afx.common.messaging.MessageListener;
import com.wellsfargo.fx.afx.common.valueobject.DefaultMessageDecoder;
import com.wellsfargo.fx.afx.common.valueobject.ValueObject;

public abstract class AbstractServerProxyMessageListener implements MessageListener {

    private static final DefaultMessageDecoder decoder = new DefaultMessageDecoder();
    private final BaseComponentService service;

    protected AbstractServerProxyMessageListener(BaseComponentService service) {
        this.service = service;
    }

    @Override
    public void onMessage(byte[] bytes) {
        ValueObject vo = decoder.decode(bytes);

        if (vo instanceof ComponentCommand) {
            ComponentCommand cc = (ComponentCommand) vo;
            if (cc.getCommand() == Command.WARM_UP) {
                service.warmUp(null);
            } else if (cc.getCommand() == Command.POST_WARM_UP) {
                service.postWarmUp(null);
            } else if (cc.getCommand() == Command.INIT) {
                service.init(null);
            } else if (cc.getCommand() == Command.RUN) {
                service.go(null);
            }
        }

        handleMessage(vo);
    }

    protected abstract void handleMessage(ValueObject vo);

    public final BaseComponentService getService() {
        return service;
    }

}
