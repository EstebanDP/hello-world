package com.wellsfargo.fx.afx.common.valueobject;

public interface MessageType {

    public static final byte LOOP_BACK_MESSAGE = 1;
    public static final byte TRANSACTION_REQUEST = 2;
    public static final byte TRANSACTION_RESPONSE = 3;
    public static final byte EXCHANGE_ORDER_REQUEST = 4;
    public static final byte EXCHANGE_ORDER_RESPONSE = 5;

    public static final int COMPONENT_COMMAND = 6;

    public static final byte MARKET_TICK = 11;

    public static final byte ORDER_RESPONSE = 32;

    public static final byte DEAL_INFO = 52;
    public static final byte POSITION_INFO = 53;
    public static final byte CURRENCY_DATES = 54;
    public static final byte USER_CONTROL_MESSAGE = 55;
    public static final byte LOGIN_MESSAGE = 56;
    public static final byte USD_EQUIVALENT_POSITION_INFO = 59;

    public static final byte ORDER = 61;

    public static final byte DEALS_PER_CCY_PAIR_DETAILS = 63;
    public static final byte DEALS_PER_STRATEGY_DETAILS = 64;
    public static final byte CCY_PAIR_DATES_DETAILS = 65;
    public static final byte ORDERS_PER_CCY_PAIR_INFO = 66;

    // Server Proxy
    public static final byte HEARTBEAT_REQUEST = 70;
    public static final byte HEARTBEAT_RESPONSE = 71;

    public static final byte WARMUP_VO = 80;

    public static final byte STRATEGY_STATE = 82;

    public static final byte LOG_WRAPPER = 83;

    public static final byte CONFIGURATION = 90;

    public static final byte SHUTDOWN_CMD = 91;

    public static final byte JVM_STATUS = 92;
    
    public static final byte CURRENCY_PAIR_TRESHOLDS_CONFIG = 93;
    
    public static final byte TRESHOLD_STRATEGY = 94;

    public static final byte MARKET_TICK_WARMUP_REQUEST = 95;

    public static final byte MARKET_DATA_DELTA = 96;

    public static final byte ECOM_MARKET_TICK = 97;

    public static final byte CURRENCY_PAIR_RATE_DISPLAY = 98;

    public static final byte BUFFET_TRADE = 101;
    
    public static final int BUFFET_BOOTSTRAP_INFO = 102;
    
    public static final int POSITION_TRANSFER = 103;

    public static final int ORDER_FILL = 104;
    
    public static final byte BUFFET_TRADE_DETAIL_INQUIRY = 105;
    
    public static final byte AMENDED_BUFFET_TRADES = 106;

    public static final byte POSITION_VO = 111;
    
    public static final int AFX_STATUS = 122;
}
