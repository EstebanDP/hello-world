package com.wellsfargo.fx.afx.ecom.common.mdg;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.wellsfargo.fx.afx.common.messaging.MessageListener;
import com.wellsfargo.fx.afx.common.messaging.MessageReceiver;
import com.wellsfargo.fx.afx.common.messaging.impl.MessagingManagerFactory;
import com.wellsfargo.fx.afx.common.util.CommonConstants;
import com.wellsfargo.fx.afx.common.util.ConfigurationLoader;
import com.wellsfargo.fx.afx.common.valueobject.CurrencyPair;
import com.wellsfargo.fx.afx.common.valueobject.DefaultMessageDecoder;
import com.wellsfargo.fx.afx.common.valueobject.ValueObject;
import com.wellsfargo.fx.afx.ecom.common.valueobject.marketdata.CurrencyPairDelta;
import com.wellsfargo.fx.afx.ecom.common.valueobject.marketdata.CurrencyPairDelta.Action;
import com.wellsfargo.fx.afx.ecom.common.valueobject.marketdata.CurrencyPairDelta.BookSide;
import com.wellsfargo.fx.afx.ecom.common.valueobject.marketdata.CurrencyPairSnapshot;
import com.wellsfargo.fx.afx.ecom.common.valueobject.marketdata.CurrencyPairSnapshot.SideBook;
import com.wellsfargo.fx.afx.ecom.common.valueobject.marketdata.EcomMarketTick;

public abstract class AbstractMarketDataManager implements MarketDataManager {

    // private static final Logger log = LoggerFactory.getLogger("");

    private Map<CurrencyPair, CurrencyPairSnapshot> books = new HashMap<CurrencyPair, CurrencyPairSnapshot>();
    private static final Collection<CurrencyPair> ccyPairs = CurrencyPair.getEnabledCurrencyPairs();
    private static final String MARKET_DATA_TOPIC_NAME = ConfigurationLoader.getInstance().getString(CommonConstants.CONST_MARKET_TICK_TOPIC_NAME);
    private MessageReceiver marketDataReceiver;
    private List<MarketDataListener> listeners = new ArrayList<MarketDataListener>();

    public AbstractMarketDataManager() {
        for (CurrencyPair cp : ccyPairs) {
            books.put(cp, new CurrencyPairSnapshot(cp));
        }
        marketDataReceiver = MessagingManagerFactory.getMessagingManager().getReceiverForTopic(MARKET_DATA_TOPIC_NAME, new MarketTickListener());
    }

    @Override
    public void start() {
        marketDataReceiver.start();
    }

    @Override
    public void stop() {
        marketDataReceiver.stop();
    }

    @Override
    public Set<CurrencyPair> getCurrencyPairs() {
        return books.keySet();
    }

    @Override
    public void mergeDelta(EcomMarketTick marketTick) {
        if (marketTick.isClearRates()) {
            for (CurrencyPairSnapshot snapshot : books.values()) {
                snapshot.clear();
            }
        }

        for (CurrencyPairDelta delta : marketTick.getCurrencyDeltasList()) {
            CurrencyPair cp = delta.getCurrencyPair();
            CurrencyPairSnapshot book = books.get(cp);
            book.setSnapshotTime(delta.getSnapshotTime());
            book.setTickReceivedTime(delta.getTickReceivedTime());

            SideBook sideBook = delta.getBookSide() == BookSide.BID ? book.getBidBook() : book.getOfferBook();
            if (delta.getAction() == Action.DELETE) {
                sideBook.removePrice(delta.getPrice());
            } else {
                sideBook.setPrice(delta.getPrice(), delta.getQuantity());
            }
        }
    }

    @Override
    public CurrencyPairSnapshot getSnapshot(CurrencyPair currencyPair) {
        return books.get(currencyPair);
    }

    @Override
    public void registerMarketDataListener(MarketDataListener marketDataListener) {
        listeners.add(marketDataListener);
    }

    private void notifyListeners(Set<CurrencyPairSnapshot> snapshots) {
        for (MarketDataListener listener : listeners) {
            listener.onMarketData(snapshots);
        }
    }

    /*
     * private void logPrices(Set<CurrencyPairSnapshot> snapshots) { for (CurrencyPairSnapshot snapshot : snapshots) { log.info(snapshot.getCurrencyPair() + ": " + snapshot.getBestBid() + " " + snapshot.getBestOffer()); } }
     */

    class MarketTickListener implements MessageListener {
        private DefaultMessageDecoder decoder = new DefaultMessageDecoder();

        @Override
        public void onMessage(byte[] bytes) {
            ValueObject vo = decoder.decode(bytes);
            if (vo instanceof EcomMarketTick) {
                EcomMarketTick mt = (EcomMarketTick) vo;
                Set<CurrencyPairSnapshot> snapshots = new HashSet<CurrencyPairSnapshot>();
                mergeDelta(mt);
                if (mt.isClearRates()) {
                    snapshots.addAll(books.values());
                } else {
                    for (CurrencyPairDelta cpd : mt.getCurrencyDeltasList()) {
                        snapshots.add(books.get(cpd.getCurrencyPair()));
                    }
                }
                // logPrices(snapshots);
                notifyListeners(snapshots);
            } else {
                throw new RuntimeException("Unexpected message: " + vo.toString());
            }
        }

    }

}
