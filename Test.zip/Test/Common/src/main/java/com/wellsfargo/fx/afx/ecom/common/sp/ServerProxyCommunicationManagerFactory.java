package com.wellsfargo.fx.afx.ecom.common.sp;


public class ServerProxyCommunicationManagerFactory {

    private static volatile ServerProxyCommunicationManager instance;
    private static AbstractServerProxyMessageListener serverProxyMessageListener;

    public static ServerProxyCommunicationManager getServerProxyCommunicationManager() {
        if (instance == null) {
            if (serverProxyMessageListener == null) {
                throw new RuntimeException("Server Proxy Message Listener not set yet!!");
            }
            synchronized (ServerProxyCommunicationManagerFactory.class) {
                if (instance == null) {
                    instance = new ServerProxyCommunicationManagerImpl(serverProxyMessageListener);
                }
            }
        }
        return instance;
    }

    public static void setServerProxyMessageListener(AbstractServerProxyMessageListener serverProxyMessageListener) {
        ServerProxyCommunicationManagerFactory.serverProxyMessageListener = serverProxyMessageListener;
    }
    
    public static AbstractServerProxyMessageListener getServerProxyMessageListener() {
        return serverProxyMessageListener;
    }
}
