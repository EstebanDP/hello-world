package com.wellsfargo.fx.afx.common.valueobject.coherence;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import com.wellsfargo.fx.afx.common.util.CommonConstants;

@SuppressWarnings("serial")
public class MarketSnapshot implements Serializable {

		// Key -> Currency Pair
	    private Map<String, BidOffer> rates = new HashMap<String, BidOffer>();

	    public void addRates(String currencyPair, String bestBid, String bestOffer) {
	        rates.put(currencyPair, new BidOffer(bestBid, bestOffer));
	    }
	    
	    public Set<String> getCurrencyPairs() {
	        return rates.keySet();
	    }
	    
	    public String getBestBid(String currencyPair) {
	        if (rates.containsKey(currencyPair)) {
	            return rates.get(currencyPair).bid;
	        } else {
	            return Float.toString(CommonConstants.CONST_NA);
	        }
	    }

	    public String getBestOffer(String currencyPair) {
	        if (rates.containsKey(currencyPair)) {
	            return rates.get(currencyPair).offer;
	        } else {
	            return Float.toString(CommonConstants.CONST_NA);
	        }
	    }

	    public String toString() {
	        StringBuilder sb = new StringBuilder();
	        for (String cp : rates.keySet()) {
	            sb.append(cp).append(": ").append(rates.get(cp).bid).append('/').append(rates.get(cp).offer);
	        }
	        return sb.toString();
	    }
	    
	    private class BidOffer implements Serializable {

	        private String bid;
	        private String offer;
	        
	        BidOffer(String bid, String offer) {
	            this.bid = bid;
	            this.offer = offer;
	        }
	    }
}