package com.wellsfargo.fx.afx.common.valueobject.coherence;

import java.io.Serializable;
import java.util.Date;

@SuppressWarnings("serial")
public class UserAuthentication implements Serializable {

	private String userName;
	private String domain;
	private String password;
	private boolean authenticate;
	private String message;
	private AFXRolesEnum role;
	private Date date;
	
	public enum AFXRolesEnum {
		AFXREAD, AFXADMIN, AFXSTOP, AFXTRADING, AFXNONE;

	    public static AFXRolesEnum valueOf(int ordinal) {
	        if (ordinal == AFXREAD.ordinal()) {
	            return AFXREAD;
	        } else if (ordinal == AFXADMIN.ordinal()) {
	            return AFXADMIN;
	        } else if (ordinal == AFXSTOP.ordinal()) {
	            return AFXSTOP;
	        } else if (ordinal == AFXTRADING.ordinal()) {
	            return AFXTRADING;
	        } else if (ordinal == AFXNONE.ordinal()) {
	            return AFXNONE;
	        }

	        return null;
	    }
	}
	
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	public String getUserName() {
		return userName;
	}
	
	public void setDomain(String domain) {
		this.domain = domain;
	}
	
	public String getDomain() {
		return domain;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getPassword() {
		return password;
	}
	
	public void setAuthenticate(boolean authenticate) {
		this.authenticate = authenticate;
	}

	public boolean isAuthenticate() {
		return authenticate;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	public String getMessage() {
		return message;
	}
	
	public void setRole(AFXRolesEnum role) {
		this.role = role;
	}
	
	public AFXRolesEnum getRole() {
		return role;
	}
	
	public void setDate(Date date) {
		this.date = date;
	}
	
	public Date getDate() {
		return date;
	}
	
	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("Username: ").append(userName).append('\n');
		sb.append("Domain: ").append(domain).append('\n');
		sb.append("Role: ").append(role != null ? role.toString() : "null").append('\n');
		sb.append("Date: ").append(date).append('\n');
		sb.append("Message: ").append(message);
		
		return sb.toString();
	}
}
