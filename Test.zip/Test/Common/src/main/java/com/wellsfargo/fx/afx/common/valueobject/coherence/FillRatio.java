package com.wellsfargo.fx.afx.common.valueobject.coherence;

import java.io.Serializable;

@SuppressWarnings("serial")
public final class FillRatio implements Serializable {

    private int numeratorCount = 0;
    private int denominatorCount = 0;

    public void incrementNumeratorCount(int count) {
        numeratorCount += count;
    }

    public int getNumeratorCount() {
        return numeratorCount;
    }

    public void incrementDenominatorCount(int count) {
        denominatorCount += count;
    }

    public int getDenominatorCount() {
        return denominatorCount;
    }

    public float getFillRatioPercentage() {
        if (denominatorCount != 0) {
            return 100f * numeratorCount / denominatorCount;
        } else {
            return -Float.MIN_VALUE;
        }
    }

}
