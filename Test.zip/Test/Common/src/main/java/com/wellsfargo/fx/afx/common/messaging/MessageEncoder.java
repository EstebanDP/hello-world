package com.wellsfargo.fx.afx.common.messaging;

public interface MessageEncoder {

	public byte[] encode(Object message);

}
