package com.wellsfargo.fx.afx.common.valueobject;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import com.wellsfargo.fx.afx.common.util.CommonConstants;

public class CurrencyPair {

    private static final Map<String, CurrencyPair> nameCurrencyPairMap = new HashMap<String, CurrencyPair>();
    private static final Map<String, CurrencyPair> enabledCurrencyPairMap = new HashMap<String, CurrencyPair>();
    private static final Map<Integer, CurrencyPair> ordinalToCurrencyPairMap = new HashMap<Integer, CurrencyPair>();

    static {
        loadCurrencyPairs();
    }

    private static void loadCurrencyPairs() {
        try {
        	// For the GUI do not load statically, as we don't want to connect to the DB for every GUI instance
        	// instead we add then one by one from cache by using addNewCurrencyPair API
        	if (!CommonConstants.VALUE_COMPONENT_NAME.equals(ComponentName.GUI)) {
				ArrayList<com.wellsfargo.fx.afx.common.persistence.model.CurrencyPair> currencyPairList 
														= new CurrencyPairDAO().getAllCurrencyPairs();
				
				com.wellsfargo.fx.afx.common.persistence.model.CurrencyPair currencyPair = null;
				for (int index = 0; index < currencyPairList.size(); index++) {
					currencyPair = currencyPairList.get(index);
					CurrencyPair cp = new CurrencyPair(
							currencyPair.getCcy1(),
							currencyPair.getCcy2(),
							currencyPair.isEnabled(),
							currencyPair.getOrdinal(),
							currencyPair.getPrecision(),
							currencyPair.getUpdateUser(),
							currencyPair.getUpdateDate());
					
					addNewCurrencyPair(cp);
				}
			}
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Fatal - cannot load currency pair configurations: " + e);
            System.exit(-1);
        }
    }
    
    public static void addNewCurrencyPair(CurrencyPair currencyPair) {
		nameCurrencyPairMap.put(currencyPair.getName(), currencyPair);
		ordinalToCurrencyPairMap.put(currencyPair.ordinal, currencyPair);

		if (currencyPair.isEnabled()) {
			enabledCurrencyPairMap.put(currencyPair.getName(), currencyPair);
		}
	}

	public static Collection<CurrencyPair> values() {
        return nameCurrencyPairMap.values();
    }
    
    public static Collection<CurrencyPair> getEnabledCurrencyPairs() {
    	return enabledCurrencyPairMap.values();
    }

    private String name;
    private int ordinal;
    private int scale;
    private boolean enabled;
    private Currency firstCurrency;
    private Currency secondCurrency;
    private String updateUser;
	private Date updateDate;
    private NumberFormat decimalFormat = DecimalFormat.getInstance(Locale.US);

    public CurrencyPair(String ccy1, String ccy2, boolean enabled, int ordinal, int scale, String updateUser, Date updateDate) {
        this.name = ccy1 + "/" + ccy2;
        this.ordinal = ordinal;
        this.scale = scale;
        this.enabled = enabled;
        this.updateUser = updateUser;
        this.updateDate = updateDate;
        firstCurrency = Currency.getByName(ccy1);
        secondCurrency = Currency.getByName(ccy2);
        decimalFormat.setMinimumFractionDigits(scale);
        decimalFormat.setMaximumFractionDigits(scale);
        decimalFormat.setGroupingUsed(false);
    }

    public static CurrencyPair valueOf(int ordinal) {
        return ordinalToCurrencyPairMap.get(ordinal);
    }

    public static CurrencyPair valueOf(String name) {
        return nameCurrencyPairMap.get(name);
    }

    public static CurrencyPair getByName(String name) {
        return valueOf(name);
    }

    public Currency getFirstCurrency() {
        return firstCurrency;
    }

    public Currency getSecondCurrency() {
        return secondCurrency;
    }

    public boolean containsCurrency(Currency currency) {
        if (currency == firstCurrency || currency == secondCurrency) {
            return true;
        }
        return false;
    }
    
    public int getScale() {
    	return scale;
    }
    
    public boolean isEnabled() {
    	return enabled;
    }

    /**
     * Gets a ccypair with USD in there (i.e. USD/XYZ or XYZ/USD).
     */
    public static CurrencyPair getUsdCurrencyPair(String currency) {
        CurrencyPair cp = getByName("USD/" + currency);
        if (cp == null) {
            cp = getByName(currency + "/USD");
        }
        return cp;
    }

    /**
     * Gets a ccypair with USD in there (i.e. USD/XYZ or XYZ/USD).
     */
    public static CurrencyPair getUsdCurrencyPair(Currency currency) {
        return getUsdCurrencyPair(currency.toString());
    }

    public float roundToScale(float rawValue) {
        float power = (float) Math.pow(10, scale);
        return Math.round(rawValue * power) / power;
    }

    public String getFormattedString(double rawValue) {
        return decimalFormat.format(rawValue);
    }
    
    public String getName() {
    	return name;
    }

    public String toString() {
        return name;
    }

    public int ordinal() {
        return ordinal;
    }

	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}

	public String getUpdateUser() {
		return updateUser;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	public Date getUpdateDate() {
		return updateDate;
	}
	
	public static boolean isEnabled(String ccy) {
		if (enabledCurrencyPairMap.get(ccy) != null) {
			return true;
		}
		return false;
	}
}
