package com.wellsfargo.fx.afx.common.messaging;

public interface MessageListener {
	
	public void onMessage(byte[] bytes);
	
}
