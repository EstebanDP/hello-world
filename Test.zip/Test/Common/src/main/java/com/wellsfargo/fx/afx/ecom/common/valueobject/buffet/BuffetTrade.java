package com.wellsfargo.fx.afx.ecom.common.valueobject.buffet;

import java.util.Date;

import com.wellsfargo.fx.afx.common.util.CommonConstants;
import com.wellsfargo.fx.afx.common.util.Util;
import com.wellsfargo.fx.afx.common.valueobject.CurrencyPair;
import com.wellsfargo.fx.afx.common.valueobject.MessageType;
import com.wellsfargo.fx.afx.common.valueobject.Side;
import com.wellsfargo.fx.afx.common.valueobject.ValueObject;

public class BuffetTrade extends ValueObject {
    private static final byte messageType = MessageType.BUFFET_TRADE;
    private static final byte version = 1;

    private String buffetTradeId;
    private String sourceTradeId;
    private String userId;
    private String currencyPair;
    CurrencyPair currencyPairVO;
    private double quantity;
    private Side side;
    private float rate;
    private float marketRateBid = CommonConstants.CONST_NA;
    private float marketRateOffer = CommonConstants.CONST_NA;
    private Date sourceExecutionTime;
    private Date buffetSentTime;
    private Date afxTime;
    private String source;
    private BuffetTradeStatus buffetTradeStatus;
    private boolean ackNeededBySource = false;
    private boolean duplicateTrade = false;
    private boolean initialPosition = false;
    private String book;
    private String term;
    private String reasonForReject;

    public String getBuffetTradeId() {
        return buffetTradeId;
    }

    public void setBuffetTradeId(String buffetTradeId) {
        this.buffetTradeId = buffetTradeId;
    }

    public String getSourceTradeId() {
        return sourceTradeId;
    }

    public void setSourceTradeId(String sourceTradeId) {
        this.sourceTradeId = sourceTradeId;
    }
    
	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserId() {
		return userId;
	}

    public String getCurrencyPair() {
        return currencyPair;
    }

    public void setCurrencyPair(String currencyPair) {
        this.currencyPair = currencyPair;
    }
    
	public CurrencyPair getCurrencyPairVO() {
        return currencyPairVO;
    }
	
    public void setCurrencyPairVO(CurrencyPair currencyPairVO) {
        this.currencyPairVO = currencyPairVO;
    }

    public double getQuantity() {
        return quantity;
    }

    public void setQuantity(double quantity) {
        this.quantity = quantity;
    }

    public Side getSide() {
        return side;
    }

    public void setSide(Side side) {
        this.side = side;
    }

    public float getRate() {
        return rate;
    }

    public void setRate(float rate) {
        this.rate = rate;
    }
    
    public float getMarketRateBid() {
        return marketRateBid;
    }

    public void setMarketRateBid(float marketRateBid) {
        this.marketRateBid = marketRateBid;
    }
    
    public float getMarketRateOffer() {
        return marketRateOffer;
    }

    public void setMarketRateOffer(float marketRateOffer) {
        this.marketRateOffer = marketRateOffer;
    }

    public Date getSourceExecutionTime() {
        return sourceExecutionTime;
    }

    public void setSourceExecutionTime(Date sourceExecutionTime) {
        this.sourceExecutionTime = sourceExecutionTime;
    }

    public Date getBuffetSentTime() {
        return buffetSentTime;
    }

    public void setBuffetSentTime(Date buffetSentTime) {
        this.buffetSentTime = buffetSentTime;
    }
    
    public Date getAfxTime() {
        return afxTime;
    }

    public void setAfxTime(Date afxTime) {
        this.afxTime = afxTime;
    }

    public BuffetTradeStatus getBuffetTradeStatus() {
        return buffetTradeStatus;
    }

    public void setBuffetTradeStatus(BuffetTradeStatus buffetTradeStatus) {
        this.buffetTradeStatus = buffetTradeStatus;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getSource() {
        return source;
    }
    
    public void setBook(String book) {
    	this.book = book;
    }
    
    public String getBook() {
    	return book;
    }
    
    public void setTerm(String term) {
    	this.term = term;
    }
    
    public String getTerm() {
    	return term;
    }
    
	public void setAckNeededBySource(boolean ackNeededBySource) {
		this.ackNeededBySource = ackNeededBySource;
	}

	public boolean isAckNeededBySource() {
		return ackNeededBySource;
	}
	
	public void setDuplicateTrade(boolean duplicateTrade) {
		this.duplicateTrade = duplicateTrade;
	}

	public boolean isDuplicateTrade() {
		return duplicateTrade;
	}

    public void setInitialPosition(boolean initialPosition) {
		this.initialPosition = initialPosition;
	}

	public boolean isInitialPosition() {
		return initialPosition;
	}
	
	public void setReasonForReject(String reasonForReject) {
		this.reasonForReject = reasonForReject;
	}

	public String getReasonForReject() {
		return reasonForReject;
	}

	@Override
    public int readFrom(byte[] bytes) {
        int pos = 2;

        int length = bytes[pos++];
        buffetTradeId = Util.readStringFromBytes(bytes, length, pos);
        pos += length;

        length = bytes[pos++];
        sourceTradeId = Util.readStringFromBytes(bytes, length, pos);
        pos += length;
        
        length = bytes[pos++];
        userId = Util.readStringFromBytes(bytes, length, pos);
        pos += length;
        
        length = bytes[pos++];
        currencyPair = Util.readStringFromBytes(bytes, length, pos);
        pos += length;

        ackNeededBySource = Util.byteToBoolean(bytes[pos++]);
        duplicateTrade = Util.byteToBoolean(bytes[pos++]);
        initialPosition = Util.byteToBoolean(bytes[pos++]);
        
        quantity = Util.readDoubleFromBytes(bytes, pos);
        pos += 8;
        side = Side.valueOf(bytes[pos++]);
        rate = Util.readFloatFromBytes(bytes, pos);
        pos += 4;
        marketRateBid = Util.readFloatFromBytes(bytes, pos);
        pos += 4;
        marketRateOffer = Util.readFloatFromBytes(bytes, pos);
        pos += 4;

        length = bytes[pos++];
        source = Util.readStringFromBytes(bytes, length, pos);
        pos += length;
        
        length = bytes[pos++];
        book = Util.readStringFromBytes(bytes, length, pos);
        pos += length;
        
        length = bytes[pos++];
        term = Util.readStringFromBytes(bytes, length, pos);
        pos += length;
        
        length = bytes[pos++];
        reasonForReject = Util.readStringFromBytes(bytes, length, pos);
        pos += length;

        sourceExecutionTime = new Date(Util.readLongFromBytes(bytes, pos));
        pos += 8;

        buffetSentTime = new Date(Util.readLongFromBytes(bytes, pos));
        pos += 8;
        
        afxTime = new Date(Util.readLongFromBytes(bytes, pos));
        pos += 8;

        buffetTradeStatus = BuffetTradeStatus.valueOf(bytes[pos++]);

        return pos;
    }

    @Override
    public byte[] toBytes() {
        byte[] bytes = new byte[getLength()];
        int pos = 0;
        bytes[pos++] = messageType;
        bytes[pos++] = version;
        pos = Util.writeStringToByteArray(buffetTradeId, bytes, pos);
        pos = Util.writeStringToByteArray(sourceTradeId, bytes, pos);
        pos = Util.writeStringToByteArray(userId, bytes, pos);
        pos = Util.writeStringToByteArray(currencyPair, bytes, pos);
        bytes[pos++] = Util.booleanToByte(ackNeededBySource);
        bytes[pos++] = Util.booleanToByte(duplicateTrade);
        bytes[pos++] = Util.booleanToByte(initialPosition);
        pos = Util.writeDoubleToByteArray(quantity, bytes, pos);
        bytes[pos++] = (byte) side.ordinal();
        pos = Util.writeFloatToByteArray(rate, bytes, pos);
        pos = Util.writeFloatToByteArray(marketRateBid, bytes, pos);
        pos = Util.writeFloatToByteArray(marketRateOffer, bytes, pos);
        pos = Util.writeStringToByteArray(source, bytes, pos);
        pos = Util.writeStringToByteArray(book, bytes, pos);
        pos = Util.writeStringToByteArray(term, bytes, pos);
        pos = Util.writeStringToByteArray(reasonForReject, bytes, pos);
        pos = Util.writeLongToByteArray(sourceExecutionTime.getTime(), bytes, pos);
        pos = Util.writeLongToByteArray(buffetSentTime.getTime(), bytes, pos);
        pos = Util.writeLongToByteArray(afxTime.getTime(), bytes, pos);
        bytes[pos++] = (byte) buffetTradeStatus.ordinal();

        return bytes;
    }

    /*
     * Notice that a string field requires 1 additional byte (length of string).
     */
    public int getLength() {
        return 2 + 1 + buffetTradeId.length() + 1 + sourceTradeId.length() + 1 + userId.length() + 1 + currencyPair.length() + 1 + 1 + 1 + 8 + 1 + 4 + 4 + 4 + 1 + source.length() + 1 + book.length() + 1 + term.length() + 1 + reasonForReject.length() + 8 + 8 + 8 + 1;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(buffetTradeId).append('\t');
        sb.append(sourceTradeId).append('\t');
        sb.append(userId).append('\t');
        sb.append(buffetTradeStatus.toString()).append('\t');
        sb.append(duplicateTrade).append('\t');
        sb.append(initialPosition).append('\t');
        sb.append(source).append('\t');
        sb.append(book).append('\t');
        sb.append(term).append('\t');
        sb.append(currencyPair).append('\t');
        sb.append(side).append('\t');
        sb.append(quantity).append('\t');
        sb.append(rate).append('\t');
        sb.append(marketRateBid == CommonConstants.CONST_NA ? CommonConstants.CONST_NA_STRING : marketRateBid).append('\t');
        sb.append(marketRateOffer == CommonConstants.CONST_NA ? CommonConstants.CONST_NA_STRING : marketRateOffer).append('\t');
        sb.append(reasonForReject);
        
        return sb.toString();
    }
}