package com.wellsfargo.fx.afx.common.util;

public interface CacheName {

	public static final String CACHE_APPLIED_CONFIGURATION = "CACHE_APPLIED_CONFIGURATION";
	public static final String CACHE_NEW_CONFIGURATION = "CACHE_NEW_CONFIGURATION";
	
	public static final String CACHE_STRATEGY = "CACHE_STRATEGY";
	public static final String CACHE_CURRENCY_PAIR = "CACHE_CURRENCY_PAIR";

	public static final String CACHE_VALUE_DATE = "CACHE_VALUE_DATE";
	public static final String CACHE_JVM_STATUS = "CACHE_JVM_STATUS";
	public static final String CACHE_STRATEGY_STATUS = "CACHE_STRATEGY_STATUS";
	public static final String CACHE_TRANSACTION = "CACHE_TRANSACTION";
	public static final String CACHE_STATISTICS = "CACHE_STATISTICS";
	public static final String CACHE_STRATEGY_FILL_RATIO = "CACHE_STRATEGY_FILLRATIO";
	public static final String CACHE_USER_AUTHENTICATION = "CACHE_USER_AUTHENTICATION";
	
	//ECOM
	public static final String CACHE_POSITION_ECOM = "CACHE_POSITION_ECOM";
	public static final String CACHE_ECOM_TRANSACTION = "CACHE_ECOM_TRANSACTION";
	public static final String CACHE_MARKET_SNAPSHOT = "CACHE_MARKET_SNAPSHOT";
	public static final String CACHE_CURRENCYPAIR_FILL_RATIO_ECOM = "CACHE_CCYPAIR_FILLRATIO_ECOM";
	public static final String CACHE_BUFFET_TRADE_DETAIL_INQUIRY = "CACHE_BUFFET_TRADE_DETAIL_INQUIRY";
	public static final String CACHE_USER_CONTROL_MESSAGE = "CACHE_USER_CONTROL_MESSAGE";
	public static final String CACHE_MONITOR_MESSAGE = "CACHE_MONITOR_MESSAGE";
}
