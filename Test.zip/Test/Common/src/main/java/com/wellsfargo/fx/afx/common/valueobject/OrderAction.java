package com.wellsfargo.fx.afx.common.valueobject;

public enum OrderAction {
    NONE, SUBMIT, AMEND, CANCEL, DISABLED;

    public static OrderAction valueOf(int ordinal) {
        if (ordinal == NONE.ordinal()) {
            return NONE;
        } else if (ordinal == SUBMIT.ordinal()) {
            return SUBMIT;
        } else if (ordinal == AMEND.ordinal()) {
            return AMEND;
        } else if (ordinal == CANCEL.ordinal()) {
            return CANCEL;
        } else if (ordinal == DISABLED.ordinal()) {
            return DISABLED;
        }
        return null;
    }
}
