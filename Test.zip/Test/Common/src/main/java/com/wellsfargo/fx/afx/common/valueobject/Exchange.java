package com.wellsfargo.fx.afx.common.valueobject;

public enum Exchange {
    EBS, CURRENEX, INTEGRAL, INTERNAL, NONE;

    public static Exchange valueOf(int ordinal) {
        if (ordinal == EBS.ordinal()) {
            return EBS;
        } else if (ordinal == CURRENEX.ordinal()) {
            return CURRENEX;
        } else if (ordinal == INTEGRAL.ordinal()) {
            return INTEGRAL;
        } else if (ordinal == INTERNAL.ordinal()) {
            return INTERNAL;
        } else if (ordinal == NONE.ordinal()) {
            return NONE;
        } else {
            return null;
        }
    }

}
