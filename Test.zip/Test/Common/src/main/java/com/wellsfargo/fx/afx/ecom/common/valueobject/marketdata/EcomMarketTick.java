package com.wellsfargo.fx.afx.ecom.common.valueobject.marketdata;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.wellsfargo.fx.afx.common.util.Util;
import com.wellsfargo.fx.afx.common.valueobject.CurrencyPair;
import com.wellsfargo.fx.afx.common.valueobject.Exchange;
import com.wellsfargo.fx.afx.common.valueobject.MessageType;
import com.wellsfargo.fx.afx.common.valueobject.ValueObject;

public class EcomMarketTick extends ValueObject {

    // TODO (Ravi) use unique id(snapshot time) in log statements
    private static final byte version = 1;
    private Exchange exchange;
    private long tickReceivedTime;
    private long sentTime;
    private String snapShotTime;
    private boolean clearRates;
    private List<CurrencyPairDelta> currencyDeltas = new ArrayList<CurrencyPairDelta>();

    public Exchange getExchange() {
        return exchange;
    }

    public void setExchange(Exchange exchange) {
        this.exchange = exchange;
    }
    
    public long getTickReceivedTime() {
        return tickReceivedTime;
    }

    public void setTickReceivedTime(long tickReceivedTime) {
        this.tickReceivedTime = tickReceivedTime;
    }

    public String getSnapShotTime() {
        return snapShotTime;
    }

    public void setSnapShotTime(String msgTime) {
        this.snapShotTime = msgTime;
    }

    public long getSentTime() {
        return sentTime;
    }

    public void setSentTime(long sentTime) {
        this.sentTime = sentTime;
    }

    public boolean isClearRates() {
        return clearRates;
    }

    public void setClearRates(boolean clearRates) {
        this.clearRates = clearRates;
    }

    public Set<CurrencyPair> getCurrencyPairs() {
        Set<CurrencyPair> set = new HashSet<CurrencyPair>();
        for (CurrencyPairDelta delta : currencyDeltas) {
            set.add(delta.getCurrencyPair());
        }
        return set;
    }

    @Override
    public byte[] toBytes() {
        int length = 1 + 1 + 1 + 8 + 8 + snapShotTime.length() + 1 + 1 + 1;
        for (CurrencyPairDelta delta : currencyDeltas) {
            length += delta.getByteLength();
        }

        byte[] bytes = new byte[length];

        int pos = 0;
        bytes[pos++] = MessageType.ECOM_MARKET_TICK;
        bytes[pos++] = version;
        bytes[pos++] = (byte) exchange.ordinal();
        pos = Util.writeLongToByteArray(tickReceivedTime, bytes, pos);
        pos = Util.writeLongToByteArray(sentTime, bytes, pos);
        pos = Util.writeStringToByteArray(snapShotTime, bytes, pos);
        bytes[pos++] = Util.booleanToByte(clearRates);

        bytes[pos++] = (byte) currencyDeltas.size();
        for (CurrencyPairDelta delta : currencyDeltas) {
            pos = delta.writeBytes(bytes, pos);
        }

        return bytes;
    }

    @Override
    public int readFrom(byte[] bytes) {
        int pos = 2; // skip type and version
        exchange = Exchange.valueOf(bytes[pos++]);
        tickReceivedTime = Util.readLongFromBytes(bytes, pos);
        pos += 8;
        sentTime = Util.readLongFromBytes(bytes, pos);
        pos += 8;

        int msgTimeLength = bytes[pos++];
        snapShotTime = Util.readStringFromBytes(bytes, msgTimeLength, pos);
        pos += msgTimeLength;
        clearRates = Util.byteToBoolean(bytes[pos++]);

        int length = bytes[pos++];
        for (int i = 0; i < length; i++) {
            CurrencyPairDelta delta = new CurrencyPairDelta();
            pos = delta.readFrom(bytes, pos);
            currencyDeltas.add(delta);
        }

        return pos;
    }

    public void addCurrencyDelta(CurrencyPairDelta currencyDelta) {
        currencyDeltas.add(currencyDelta);
    }

    public List<CurrencyPairDelta> getCurrencyDeltasList() {
        return currencyDeltas;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append('\t').append(exchange.toString()).append('\t');
        sb.append('\t').append(tickReceivedTime).append('\t');
        sb.append(sentTime).append('\t');
        sb.append(snapShotTime).append('\n');
        for (CurrencyPairDelta delta : currencyDeltas) {
            delta.appendToString(sb);
        }
        return sb.toString();
    }

}
