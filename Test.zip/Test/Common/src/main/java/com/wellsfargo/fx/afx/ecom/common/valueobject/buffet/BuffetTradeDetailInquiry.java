package com.wellsfargo.fx.afx.ecom.common.valueobject.buffet;

import java.util.Date;

import com.wellsfargo.fx.afx.common.util.Util;
import com.wellsfargo.fx.afx.common.valueobject.MessageType;
import com.wellsfargo.fx.afx.common.valueobject.ValueObject;

public class BuffetTradeDetailInquiry extends ValueObject {
    private static final byte messageType = MessageType.BUFFET_TRADE_DETAIL_INQUIRY;
    private static final byte version = 1;

    private String userId;
    private String domain;
    private String buffetTradeId;
    private Date requestTime;

    public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserId() {
		return userId;
	}

	public void setDomain(String domain) {
		this.domain = domain;
	}

	public String getDomain() {
		return domain;
	}
	
    public String getBuffetTradeId() {
        return buffetTradeId;
    }

    public void setBuffetTradeId(String buffetTradeId) {
        this.buffetTradeId = buffetTradeId;
    }

    public Date getRequestTime() {
        return requestTime;
    }

    public void setRequestTime(Date requestTime) {
        this.requestTime = requestTime;
    }

    @Override
    public int readFrom(byte[] bytes) {
        int pos = 2;

        int length = bytes[pos++];
        userId = Util.readStringFromBytes(bytes, length, pos);
        pos += length;
        
        length = bytes[pos++];
        domain = Util.readStringFromBytes(bytes, length, pos);
        pos += length;
        
        length = bytes[pos++];
        buffetTradeId = Util.readStringFromBytes(bytes, length, pos);
        pos += length;

        requestTime = new Date(Util.readLongFromBytes(bytes, pos));
        pos += 8;

        return pos;
    }

    @Override
    public byte[] toBytes() {
        byte[] bytes = new byte[getLength()];
        int pos = 0;
        bytes[pos++] = messageType;
        bytes[pos++] = version;
        pos = Util.writeStringToByteArray(userId, bytes, pos);
        pos = Util.writeStringToByteArray(domain, bytes, pos);
        pos = Util.writeStringToByteArray(buffetTradeId, bytes, pos);

        pos = Util.writeLongToByteArray(requestTime.getTime(), bytes, pos);

        return bytes;
    }

    private int getLength() {
    	return 2 + 1 + userId.length() + 1 + domain.length() + 1 + buffetTradeId.length() + 8;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(userId).append('\t');
        sb.append(domain).append('\t');
        sb.append(buffetTradeId).append('\t');
        sb.append(requestTime);

        return sb.toString();
    }
}