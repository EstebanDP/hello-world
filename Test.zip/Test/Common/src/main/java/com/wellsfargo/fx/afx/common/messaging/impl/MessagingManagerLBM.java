package com.wellsfargo.fx.afx.common.messaging.impl;

import java.io.File;
import java.net.URL;
import java.util.Map;

import javolution.util.FastMap;

import com.latencybusters.lbm.LBM;
import com.latencybusters.lbm.LBMContext;
import com.latencybusters.lbm.LBMContextAttributes;
import com.latencybusters.lbm.LBMContextThread;
import com.latencybusters.lbm.LBMException;
import com.latencybusters.lbm.LBMSourceEventCallback;
import com.wellsfargo.fx.afx.common.messaging.MessageListener;
import com.wellsfargo.fx.afx.common.messaging.MessageReceiver;
import com.wellsfargo.fx.afx.common.messaging.MessageSender;
import com.wellsfargo.fx.afx.common.messaging.MessagingManager;
import com.wellsfargo.fx.afx.common.messaging.EOSMessageListener;
import com.wellsfargo.fx.afx.common.util.ConfigurationLoader;

class MessagingManagerLBM implements MessagingManager {

    private LBMContext ctx;
    private LBMContextAttributes cattr;
    private LBMContextThread ctxthread;
    private int bufsize = 1;
    private LBM lbm;
    private Map<String, MessageSenderLBM> senderMap = new FastMap<String, MessageSenderLBM>();

    public MessagingManagerLBM() {
        initLBM();
        initLogger();
        initConfig();
        createContext();
    }

    @Override
    public MessageReceiver getReceiverForTopic(String topicName, EOSMessageListener listener) {
        return new MessageReceiverLBM(ctx, topicName, listener);
    }

    @Override
    public MessageReceiver getReceiverForTopic(String topicName, MessageListener listener) {
        return new MessageReceiverLBM(ctx, topicName, listener);
    }

    @Override
    public synchronized MessageSender getSenderForTopic(String topicName) {
        MessageSenderLBM sender = senderMap.get(topicName);
        if (sender == null) {
            sender = new MessageSenderLBM(ctx, topicName, null);
            senderMap.put(topicName, sender);
        }
        return sender;
    }

    @Override
    public synchronized MessageSender getSenderForTopic(String topicName, LBMSourceEventCallback sourceEventCallback) {
        MessageSenderLBM sender = senderMap.get(topicName);
        if (sender == null) {
            sender = new MessageSenderLBM(ctx, topicName, sourceEventCallback);
            senderMap.put(topicName, sender);
        }
        return sender;
    }

    private void initLogger() {
        lbm.setLogger(null);
    }

    private void initLBM() {
        try {
            lbm = new LBM();
        } catch (LBMException ex) {
            System.err.println("Error initializing LBM: " + ex.toString());
            System.exit(1);
        }
    }

    private void createContext() {
        try {
            ctx = new LBMContext(cattr);
        } catch (LBMException ex) {
            System.err.println("Error creating context: " + ex.toString());
            System.exit(1);
        }
        ctxthread = new LBMContextThread(ctx);
        ctxthread.setName("LBM Context Thread");
        ctxthread.setDaemon(true);
        ctxthread.start();
    }

    private void initConfig() {
    	String filename = ConfigurationLoader.getInstance().getString("29west.config.filename", true);
    	if (filename == null || filename.equals("")) {
    		filename = "lbt-ipc.conf";
    	}
    	
        URL confFileUrl = ClassLoader.getSystemResource(filename);
        String confFileName = null;

        if (confFileUrl == null) {
            String absPath = new File("").getAbsolutePath();
            confFileName = absPath + "/" + "environment" + "/" + filename;
        } else {
            confFileName = confFileUrl.getFile();
            if (confFileName.contains(":")) {
                confFileName = confFileName.substring(1);
            }
        }

        if (confFileName != null) {
            try {
                LBM.setConfiguration(confFileName);
            } catch (LBMException ex) {
                System.err.println("Error setting LBM configuration: " + ex.toString());
                System.exit(1);
            }
        }
        try {
            cattr = new LBMContextAttributes();
        } catch (LBMException ex) {
            System.out.println("Error creating attributes: " + ex.toString());
            System.exit(1);
        }

        if (bufsize > 0) {
            bufsize *= 1024 * 1024;
            cattr.setProperty("transport_tcp_receiver_socket_buffer", "" + bufsize);
            cattr.setProperty("transport_lbtrm_receiver_socket_buffer", "" + bufsize);
            cattr.setProperty("transport_lbtru_receiver_socket_buffer", "" + bufsize);
        }

        cattr.setProperty("operational_mode", "sequential");
    }
}
