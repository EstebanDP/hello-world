package com.wellsfargo.fx.afx.common.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AFXThread extends Thread {

    private static final Logger logger = LoggerFactory.getLogger(LoggerConstants.COMMON);

    public AFXThread() {
        super();
        setUncaughtExceptionHandler();
    }

    public AFXThread(Runnable target) {
        super(target);
        setUncaughtExceptionHandler();
    }

    public AFXThread(Runnable target, String name) {
        super(target, name);
    }

    private void setUncaughtExceptionHandler() {
        this.setUncaughtExceptionHandler(new AFXUncaughtExceptionHandler());
    }

    public static class AFXUncaughtExceptionHandler implements UncaughtExceptionHandler {

        @Override
        public void uncaughtException(Thread t, Throwable e) {
        	try {
	            System.err.println(e.getMessage());
	            e.printStackTrace();
	            logger.debug("[" + t + "] -- " + e);
        	} catch(Exception ex) {
        		
        	} finally { //in case it fails before killJVM() is called
        		System.exit(-1);
        	}
        }

    }
}
