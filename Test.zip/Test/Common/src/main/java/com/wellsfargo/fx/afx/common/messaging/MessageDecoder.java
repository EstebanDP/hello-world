package com.wellsfargo.fx.afx.common.messaging;

import com.wellsfargo.fx.afx.common.valueobject.ValueObject;

public interface MessageDecoder {

    public ValueObject decode(byte[] message);

}
