package com.wellsfargo.fx.afx.common.valueobject.coherence;

import java.io.Serializable;
import java.util.Date;

@SuppressWarnings("serial")
public class BuffetTradeDetailInquiry implements Serializable, Cloneable {

    private String userId;
    private String domain;
    private String buffetTradeId;
    private Date requestTime;

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserId() {
		return userId;
	}

	public void setDomain(String domain) {
		this.domain = domain;
	}

	public String getDomain() {
		return domain;
	}
	
    public String getBuffetTradeId() {
        return buffetTradeId;
    }

    public void setBuffetTradeId(String buffetTradeId) {
        this.buffetTradeId = buffetTradeId;
    }

    public Date getRequestTime() {
        return requestTime;
    }

    public void setRequestTime(Date requestTime) {
        this.requestTime = requestTime;
    }
    
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(userId).append('\t');
        sb.append(domain).append('\t');
        sb.append(buffetTradeId).append('\t');
        sb.append(requestTime);

        return sb.toString();
    }
}