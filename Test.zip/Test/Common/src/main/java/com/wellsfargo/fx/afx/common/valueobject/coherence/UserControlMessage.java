package com.wellsfargo.fx.afx.common.valueobject.coherence;

import java.io.Serializable;

import com.wellsfargo.fx.afx.common.valueobject.UserControlMessage.UserControlMessageEnum;

@SuppressWarnings("serial")
public class UserControlMessage implements Serializable {
    private UserControlMessageEnum userControlMessage;
    private String reason;
    private boolean forcePause;
    private boolean userAttentionNeeded;
    private String userId;
    private StrategyControl strategyControl;

    public UserControlMessage() {
    }
    
    public void setUserControlMessage(UserControlMessageEnum userControlMessage) {
    	this.userControlMessage = userControlMessage;
    }
    
	public UserControlMessageEnum getUserControlMessage() {
    	return userControlMessage;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

	public void setForcePause(boolean forcePause) {
		this.forcePause = forcePause;
	}

	public boolean isForcePause() {
		return forcePause;
	}
	
	public void setUserAttentionNeeded(boolean userAttentionNeeded) {
		this.userAttentionNeeded = userAttentionNeeded;
	}

	public boolean isUserAttentionNeeded() {
		return userAttentionNeeded;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserId() {
		return userId;
	}

    public void setStrategyControl(StrategyControl strategyControl) {
		this.strategyControl = strategyControl;
	}

	public StrategyControl getStrategyControl() {
		return strategyControl;
	}

	@Override
    public String toString() {
        StringBuffer sb = new StringBuffer();
        sb.append(userId).append('\t');
        sb.append(userControlMessage.toString()).append('\t');
        sb.append(reason).append('\t');
        sb.append(forcePause).append('\t');
        sb.append(userAttentionNeeded).append('\t');
        if (strategyControl != null) {
        	sb.append(strategyControl.toString());
        }
        return sb.toString();
    }
    
    public class StrategyControl implements Serializable {
        private String strategyName;
        private StrategyControlEnum strategyControlEnum;
        private boolean validateActiveStrategy;
        
        public void setStrategyName(String strategyName) {
    		this.strategyName = strategyName;
    	}

    	public String getStrategyName() {
    		return strategyName;
    	}
    	
		public void setStrategyControlEnum(StrategyControlEnum strategyControlEnum) {
			this.strategyControlEnum = strategyControlEnum;
		}

		public StrategyControlEnum getStrategyControlEnum() {
			return strategyControlEnum;
		}
		
    	public void setValidateActiveStrategy(boolean validateActiveStrategy) {
			this.validateActiveStrategy = validateActiveStrategy;
		}

		public boolean isValidateActiveStrategy() {
			return validateActiveStrategy;
		}

		public String toString() {
    		return new String();
    	}
    }
    
    public enum StrategyControlEnum {
    	SEND_TO_PM, DELETE_STRATEGY;

        public static StrategyControlEnum valueOf(int ordinal) {
            if (ordinal == SEND_TO_PM.ordinal()) {
                return SEND_TO_PM;
            } else if (ordinal == DELETE_STRATEGY.ordinal()) {
                return DELETE_STRATEGY;
            }

            return null;
        }
    }
}
