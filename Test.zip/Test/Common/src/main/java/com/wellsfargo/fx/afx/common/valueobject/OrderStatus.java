package com.wellsfargo.fx.afx.common.valueobject;

public enum OrderStatus {
    NONE, FILLED, PARTIALLY_FILLED, CANCELLED, REJECTED_BECAUSE_THROUGHPUT_LIMIT_REACHED, REJECTED_BECAUSE_OF_LATENCY_LIMIT, REJECTED_INTERNAL_VALIDATION, REJECTED_BY_EXCHANGE;

    public static OrderStatus valueOf(int ordinal) {
        if (ordinal == NONE.ordinal()) {
            return NONE;
        } else if (ordinal == FILLED.ordinal()) {
            return FILLED;
        } else if (ordinal == PARTIALLY_FILLED.ordinal()) {
            return PARTIALLY_FILLED;
        } else if (ordinal == CANCELLED.ordinal()) {
            return CANCELLED;
        } else if (ordinal == REJECTED_BECAUSE_THROUGHPUT_LIMIT_REACHED.ordinal()) {
            return REJECTED_BECAUSE_THROUGHPUT_LIMIT_REACHED;
        } else if (ordinal == REJECTED_BECAUSE_OF_LATENCY_LIMIT.ordinal()) {
            return REJECTED_BECAUSE_OF_LATENCY_LIMIT;
        } else if (ordinal == REJECTED_INTERNAL_VALIDATION.ordinal()) {
            return REJECTED_INTERNAL_VALIDATION;
        } else if (ordinal == REJECTED_BY_EXCHANGE.ordinal()) {
            return REJECTED_BY_EXCHANGE;
        } else {
            return null;
        }
    }

    public boolean isNotNoneAndNotFilled() {
        return isRejected() || this == OrderStatus.CANCELLED;
    }

    public boolean isRejected() {
        return this == REJECTED_BECAUSE_THROUGHPUT_LIMIT_REACHED || this == REJECTED_BECAUSE_OF_LATENCY_LIMIT || this == REJECTED_INTERNAL_VALIDATION
                || this == REJECTED_BY_EXCHANGE;
    }

}
