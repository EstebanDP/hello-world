package com.wellsfargo.fx.afx.common.valueobject;

public enum MarketTickSimulatorCode {
    START_SENDING_TICKS, CONTINUE_SENDING_TICKS, STOP_SENDING_TICKS;

    public static MarketTickSimulatorCode valueOf(int ordinal) {
        
    	if (ordinal == START_SENDING_TICKS.ordinal()) {
            return START_SENDING_TICKS;
        } else if (ordinal == CONTINUE_SENDING_TICKS.ordinal()) {
        	return CONTINUE_SENDING_TICKS;
        } else if (ordinal == STOP_SENDING_TICKS.ordinal()) {
            return STOP_SENDING_TICKS;
        } else {
            return null;
        }
    }
}
