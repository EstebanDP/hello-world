package com.wellsfargo.fx.afx.common.valueobject.gui;

import com.wellsfargo.fx.afx.common.util.Util;
import com.wellsfargo.fx.afx.common.valueobject.MessageType;
import com.wellsfargo.fx.afx.common.valueobject.ValueObject;

public class CurrencyPairDatesDetails extends ValueObject {

    private static final byte version = 1;
    private String currencyPair;
    private String valueDate;
    private String tradeDate;

    public CurrencyPairDatesDetails() {
    }

    public CurrencyPairDatesDetails(String currencyPair, String valueDate, String tradeDate) {
        this.currencyPair = currencyPair;
        this.valueDate = valueDate;
        this.tradeDate = tradeDate;
    }

    public String getCurrencyPair() {
        return currencyPair;
    }

    public void setCurrencyPair(String currencyPair) {
        this.currencyPair = currencyPair;
    }

    public String getValueDate() {
        return valueDate;
    }

    public void setValueDate(String valueDate) {
        this.valueDate = valueDate;
    }

    public String getTradeDate() {
        return tradeDate;
    }

    public void setTradeDate(String tradeDate) {
        this.tradeDate = tradeDate;
    }

    @Override
    public int readFrom(byte[] bytes) {
        int pos = 2; // skip type and version
        int length = bytes[pos++];
        currencyPair = Util.readStringFromBytes(bytes, length, pos);
        pos += length;
        length = bytes[pos++];
        tradeDate = Util.readStringFromBytes(bytes, length, pos);
        pos += length;
        length = bytes[pos++];
        valueDate = Util.readStringFromBytes(bytes, length, pos);
        pos += length;
        return pos;
    }

    public int getByteLength() {
        int byteLength = 1 + 1 + currencyPair.length() + tradeDate.length() + valueDate.length() + 1 + 1 + 1;
        return byteLength;
    }

    @Override
    public byte[] toBytes() {
        int byteLength = getByteLength();
        byte[] bytes = new byte[byteLength];
        int pos = 0;
        bytes[pos++] = MessageType.CCY_PAIR_DATES_DETAILS;
        bytes[pos++] = version;
        pos = Util.writeStringToByteArray(currencyPair, bytes, pos);
        pos = Util.writeStringToByteArray(tradeDate, bytes, pos);
        pos = Util.writeStringToByteArray(valueDate, bytes, pos);
        return bytes;
    }
}
