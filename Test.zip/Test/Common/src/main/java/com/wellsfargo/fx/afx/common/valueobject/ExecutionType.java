package com.wellsfargo.fx.afx.common.valueobject;

public enum ExecutionType {
    AGGRESSIVE, PASSIVE, RESIDUAL, DUMMY, MANUAL_OFFSET, HEDGE;

    public static ExecutionType valueOf(int ordinal) {
        if (ordinal == AGGRESSIVE.ordinal()) {
            return AGGRESSIVE;
        } else if (ordinal == PASSIVE.ordinal()) {
            return PASSIVE;
        } else if (ordinal == RESIDUAL.ordinal()) {
            return RESIDUAL;
        } else if (ordinal == DUMMY.ordinal()) {
            return DUMMY;
        } else if (ordinal == MANUAL_OFFSET.ordinal()) {
            return MANUAL_OFFSET;
        } else if (ordinal == HEDGE.ordinal()) {
            return HEDGE;
        }
        return null;
    }

    public boolean isArb() {
        if (this == AGGRESSIVE || this == PASSIVE) {
            return true;
        } else {
            return false;
        }
    }
}
