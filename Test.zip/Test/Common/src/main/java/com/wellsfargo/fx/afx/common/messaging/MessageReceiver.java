package com.wellsfargo.fx.afx.common.messaging;

public interface MessageReceiver {
	
	public void start();

	public void stop();

	public String getTopicName();
}
