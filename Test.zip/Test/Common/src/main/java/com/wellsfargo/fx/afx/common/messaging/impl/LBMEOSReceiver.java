package com.wellsfargo.fx.afx.common.messaging.impl;

import com.latencybusters.lbm.LBM;
import com.latencybusters.lbm.LBMContext;
import com.latencybusters.lbm.LBMEventQueue;
import com.latencybusters.lbm.LBMException;
import com.latencybusters.lbm.LBMMessage;
import com.latencybusters.lbm.LBMReceiver;
import com.latencybusters.lbm.LBMTopic;
import com.wellsfargo.fx.afx.common.messaging.EOSMessageListener;

public class LBMEOSReceiver extends LBMReceiver {
	
	private static final long serialVersionUID = 1L;
	
	private EOSMessageListener listener;

	public LBMEOSReceiver(LBMContext ctx, LBMTopic topic, LBMEventQueue queue, EOSMessageListener listener) throws LBMException {
		super(ctx, topic, queue);
		this.listener = listener;
	}

	protected int onReceive(LBMMessage msg) {
		switch (msg.type()) {
        case LBM.MSG_DATA:
            try {
                   listener.onMessage(msg.data());
                   break;
            } catch (Exception e) {
                e.printStackTrace();
                System.exit(1);
            }
		case LBM.MSG_EOS:
            try {
                listener.onEOSMessage(msg.data());
                break;
	         } catch (Exception e) {
	             e.printStackTrace();
	             System.exit(1);
	         }
		default:
			break;
		}
		msg.dispose();
		return 0;
	}
}
