package com.wellsfargo.fx.afx.common.valueobject.coherence;

import java.io.Serializable;
import java.util.Date;

import com.wellsfargo.fx.afx.common.valueobject.Exchange;
import com.wellsfargo.fx.afx.common.valueobject.Side;

@SuppressWarnings("serial")
public class OrderFill implements Serializable {

    private String ecnTradeId;
    private String orderId;
    private String price;
    private String currencyPair;
    
    private Exchange exchange;
    private Side side;
    private float quantity;
    private Date executionTime;
    private Date afxTime;
    private int tradeCounter; //used by GUI

    public String getEcnTradeId() {
        return ecnTradeId;
    }

    public void setEcnTradeId(String ecnTradeId) {
        this.ecnTradeId = ecnTradeId;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getCurrencyPair() {
        return currencyPair;
    }

    public void setCurrencyPair(String currencyPair) {
        this.currencyPair = currencyPair;
    }

    public Exchange getExchange() {
        return exchange;
    }

    public void setExchange(Exchange exchange) {
        this.exchange = exchange;
    }

    public Side getSide() {
        return side;
    }

    public void setSide(Side side) {
        this.side = side;
    }

    public float getQuantity() {
        return quantity;
    }

    public void setQuantity(float quantity) {
        this.quantity = quantity;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public Date getExecutionTime() {
        return executionTime;
    }

    public void setExecutionTime(Date executionTime) {
        this.executionTime = executionTime;
    }
    
    public Date getAfxTime() {
        return afxTime;
    }

    public void setAfxTime(Date afxTime) {
        this.afxTime = afxTime;
    }

	public void setTradeCounter(int tradeCounter) {
		this.tradeCounter = tradeCounter;
	}

	public int getTradeCounter() {
		return tradeCounter;
	}
	
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(ecnTradeId).append('\t');
        sb.append(orderId).append('\t');
        sb.append(exchange).append('\t');
        sb.append(currencyPair).append('\t');
        sb.append(side).append('\t');
        sb.append(quantity).append('\t');
        sb.append(price).append('\t');
        sb.append(executionTime.toString()).append('\t');
        sb.append(afxTime.toString());

        return sb.toString();
    }
}
