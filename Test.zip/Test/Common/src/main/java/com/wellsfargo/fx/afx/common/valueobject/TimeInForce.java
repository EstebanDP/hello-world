package com.wellsfargo.fx.afx.common.valueobject;

public enum TimeInForce {
	IOC, GTC;

	public static TimeInForce valueOf(int ordinal) {
		if (ordinal == IOC.ordinal()) {
			return IOC;
		} else if (ordinal == GTC.ordinal()) {
			return GTC;
		} else {
			return null;
		}
	}
}
