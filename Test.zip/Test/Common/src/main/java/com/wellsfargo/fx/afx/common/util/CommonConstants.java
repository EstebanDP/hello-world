package com.wellsfargo.fx.afx.common.util;

import java.math.BigDecimal;
import java.math.MathContext;

import com.wellsfargo.fx.afx.common.valueobject.ComponentName;

public interface CommonConstants {
	public static final ComponentName VALUE_COMPONENT_NAME = ComponentName.valueOf(System.getProperty("component.name"));

    public static final float CONST_NA = -Float.MIN_VALUE;
    public static final MathContext CONST_MC = new MathContext(10);
    public static final BigDecimal CONST_ZERO_BIG_DECIMAL = new BigDecimal(0, CONST_MC);
    public static final BigDecimal CONST_NA_BIG_DECIMAL = new BigDecimal(CONST_NA, CONST_MC);
    public static final String CONST_NA_STRING = "N/A";
    public static final int CONST_MANUAL_OFFSET_STRATEGY_ID = 5000;
    public static final int CONST_PENDING_OFFSET_STRATEGY_ID = 5001;
    public static final String CONST_STRATEGY_STATISTICS = "Strategy Statistics";
    public static final String CONST_CURRENCY_PAIR_STATISTICS = "Currency Pair Statistics";
    public static final String CONST_RECEIVE_FROM_SERVER_PROXY_TOPIC = "messaging.topic.receive.from.server.proxy";
    public static final String CONST_SEND_TO_SERVER_PROXY_TOPIC = "messaging.topic.send.to.server.proxy";
    public static final String CONST_COMPONENT_TYPE = "component.type";
    public static final String CONST_START = "START";
    public static final String CONST_INVALID = "INVALID";
    
    public static final String CONST_APPEND_INITIAL_POSITION_RECEIVED = "_INITIAL_POSITION_RECEIVED_";
    public static final String CONST_POSITION_TRANSFER = "TRANSFER";
    public static final String CONST_APPEND_CANCELLED = "_CANCELLED_";
    public static final String CONST_APPEND_AMEND = "_AMEND_";
    public static final String CONST_APPEND_REPAIRQ = "_REPAIRQ_";
    public static final String CONST_APPEND_REJECTED = "_REJECTED_";
    public static final String CONST_APPEND_POSITION_TRANSFER = "_POSITION_TRANSFER_";
    public static final String CONST_APPEND_DUPLICATE = "_DUPLICATE_";
    
    public static final String CONST_SEPARATOR = "**********";
    
	public static final String CONST_MDG_EBS = "MDG.EBS";
	public static final String CONST_ORG_EBS = "ORG.EBS";
	public static final String CONST_MDG_CNX = "MDG.CNX";
	public static final String CONST_ORG_CNX = "ORG.CNX";
	public static final String CONST_MDG_INTEGRAL = "MDG.INTEGRAL";
	public static final String CONST_ORG_INTEGRAL = "ORG.INTEGRAL";
	
	public static final String CONST_ALLOWED_NET_LOSS = "Allowed Net Loss";
	public static final String CONST_AGGREGATED_POSITION_THRESHOLD = "Aggregated Threshold";
	public static final String CONST_BUFFET_ROUTING_BUCKET_THRESHOLD = "Buffet Routing Threshold";
	public static final String CONST_AMEND_THRESHOLD = "Amend Threshold";
	public static final String CONST_CANCEL_THRESHOLD = "Cancel Threshold";
	public static final String CONST_VERIFY_NUMBER_VARIABLES_TO_LOAD = "verifyNumberOfVariablesToLoad";
	
	public static final String CONST_BUSINESS_CONFIG_TYPE = "Business";
	public static final String CONST_INFORMATICA_CONFIG_TYPE = "Informatica";
	public static final String CONST_LOGGER_CONFIG_TYPE = "Logger";
	public static final String CONST_GENERAL_CONFIG_TYPE = "General";
	public static final String CONST_EXCHANGE = "Exchange";
	public static final String CONST_CASCADE = "_Cascade";
	
	public static final String CONST_COMPONENT_READY_WARM_UP = "Component Ready to Warm Up";
	public static final String CONST_COMPONENT_DOWN = "Component is Down";
	public static final String CONST_COMPONENT_FINISHED_WARM_UP = "Component Finished Warming Up";
	public static final String CONST_COMPONENT_STANDBY = "Component is on Stand By";
	public static final String CONST_COMPONENT_RUNNING = "Component is Running";
	
	public static final String CONST_AUTO_HEDGE_STARTED_BY = "Auto hedge started by ";
	public static final String CONST_PAUSING_AFX_MACRO_RECEIVED = "Pausing AFX, new Macro received";
	public static final String CONST_RESTARTING_AFX_MACRO_APPLIED_BY = "Restarting AFX, new Macro applied by ";
	
    public static final String CONST_MARKET_DATA_GATEWAY_LIST = "market.data.gateway.list";
    public static final String CONST_ORDER_ROUTING_GATEWAY_LIST = "order.routing.gateway.list";
    
    public static final String CONST_POSITION_MASTER_LIMIT = "position.master.limit";
    public static final String CONST_POSITION_ORDER_CANCEL_TIME = "position.order.cancel.time";
    public static final String CONST_POSITION_GFX_AMEND_THRESHOLD_CONFIG = "position.gfx.amend.threshold";
    public static final String CONST_POSITION_GFX_CANCEL_THRESHOLD_CONFIG = "position.gfx.cancel.threshold";
    public static final String CONST_POSITION_GFX_TRADE_SOURCES_CONFIG = "position.gfx.trade.sources";
    public static final String CONST_POSITION_GFX_BOOK_PORTFOLIO_CONFIG = "position.gfx.book.portfolio";

    public static final String CONST_ALLOWED_NET_LOSS_CONFIG = "position.pnl.allowednetloss";
    public static final String CONST_AGGREGATED_POSITION_THRESHOLD_CONFIG = "position.pnl.aggregatedpositionthreshold";
    public static final String CONST_BUFFET_ROUTING_BUCKET_LIMIT_CONFIG = "buffet.routing.bucket.limit";
    public static final String CONST_MACRO_THRESHOLD_MIN_AMOUNT = "macro.threshold.min.amount";
    public static final String CONST_MACRO_THRESHOLD_MAX_AMOUNT = "macro.threshold.max.amount";
	
	public static final String CONST_MARKET_TICK_TOPIC_NAME = "messaging.topic.marketdatagateway.market.tick";
	public static final String CONST_ORDER_ROUTING_RESPONSE_TOPIC_NAME = "messaging.topic.orderrouting.response";
    public static final String CONST_ORDER_ROUTING_REQUEST_TOPIC_NAME = "messaging.topic.orderrouting.request";
    
    public static final String CONST_MDG_INCOMING_MSGS_LOG = "marketdatagateway.fix.incoming.messages.log";
    public static final String CONST_MDG_OUTGOING_MSGS_LOG = "marketdatagateway.fix.outgoing.messages.log";
    public static final String CONST_MDG_EVENT_LOG = "marketdatagateway.event.log";
    public static final String CONST_MDG_HEARTBEAT_LOG = "marketdatagateway.heartbeat.log";
    public static final String CONST_MDG_LOG_ACCOUNT_SETTINGS = "marketdatagateway.account.logsettings";
    public static final String CONST_MDG_START_WITHOUT_SERVER_PROXY = "marketdatagateway.start.without.server.proxy";
    public static final String CONST_MDG_TIME_TO_WAIT_BEFORE_START = "marketdatagateway.time.to.wait.before.start";
    public static final String CONST_MDG_FIX_LOGON_USERNAME = "marketdatagateway.fix.logon.username";
    public static final String CONST_MDG_FIX_LOGON_PASSWORD = "marketdatagateway.fix.logon.password";
    public static final String CONST_MDG_MARKET_DEPTH = "marketdatagateway.fix.market.depth";
    public static final String CONST_MDG_AGGREGATED_BOOK = "marketdatagateway.fix.aggregated.book";
    public static final String CONST_MDG_DELIVER_TO_COMP_ID = "marketdatagateway.fix.deliver.to.comp.id";
    
    public static final String CONST_ORG_INCOMING_MSGS_LOG = "orderrouting.fix.incoming.messages.log";
    public static final String CONST_ORG_OUTGOING_MSGS_LOG = "orderrouting.fix.outgoing.messages.log";
    public static final String CONST_ORG_EVENT_LOG = "orderrouting.event.log";
    public static final String CONST_ORG_HEARTBEAT_LOG = "orderrouting.heartbeat.log";
    public static final String CONST_ORG_LOG_ACCOUNT_SETTINGS = "orderrouting.account.logsettings";
    public static final String CONST_ORG_START_WITHOUT_SERVER_PROXY = "orderrouting.start.without.server.proxy";
    public static final String CONST_ORG_FIX_LOGON_USERNAME = "orderrouting.fix.logon.username";
    public static final String CONST_ORG_FIX_LOGON_PASSWORD = "orderrouting.fix.logon.password";
    public static final String CONST_ORG_DELIVER_TO_COMP_ID = "orderrouting.fix.deliver.to.comp.id";
    
    public static final String COHERENCE_EXTEND_ADDRESS = "tangosol.coherence.extend.address";
    public static final String COHERENCE_EXTEND_PORT = "tangosol.coherence.extend.port";
    
}