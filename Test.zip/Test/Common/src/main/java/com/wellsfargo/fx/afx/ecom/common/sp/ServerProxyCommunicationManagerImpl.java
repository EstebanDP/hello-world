package com.wellsfargo.fx.afx.ecom.common.sp;

import java.util.concurrent.atomic.AtomicInteger;

import com.latencybusters.lbm.LBM;
import com.latencybusters.lbm.LBMSourceEvent;
import com.latencybusters.lbm.LBMSourceEventCallback;
import com.wellsfargo.fx.afx.common.log.Logger;
import com.wellsfargo.fx.afx.common.log.impl.LoggerFactory;
import com.wellsfargo.fx.afx.common.messaging.MessageReceiver;
import com.wellsfargo.fx.afx.common.messaging.MessageSender;
import com.wellsfargo.fx.afx.common.messaging.impl.MessagingManagerFactory;
import com.wellsfargo.fx.afx.common.util.CommonConstants;
import com.wellsfargo.fx.afx.common.util.ConfigurationLoader;
import com.wellsfargo.fx.afx.common.util.JVMUtils;
import com.wellsfargo.fx.afx.common.valueobject.ComponentName;
import com.wellsfargo.fx.afx.common.valueobject.ShutdownCmd;

class ServerProxyCommunicationManagerImpl implements ServerProxyCommunicationManager {

    private static final Logger log = LoggerFactory.getLogger();

    private MessageReceiver messageReceiver;
    private MessageSender messageSender;
    private AtomicInteger currentNumberOfReceivers;
    private String senderTopic;
    private boolean messageSenderReady;

    public ServerProxyCommunicationManagerImpl(AbstractServerProxyMessageListener serverProxyMessageListener) {
        currentNumberOfReceivers = new AtomicInteger(0);
        messageSenderReady = false;
        messageReceiver = MessagingManagerFactory.getMessagingManager().getReceiverForTopic(
                ConfigurationLoader.getInstance().getString(CommonConstants.CONST_RECEIVE_FROM_SERVER_PROXY_TOPIC), serverProxyMessageListener);

        senderTopic = ConfigurationLoader.getInstance().getString(CommonConstants.CONST_SEND_TO_SERVER_PROXY_TOPIC);
        messageSender = MessagingManagerFactory.getMessagingManager().getSenderForTopic(senderTopic, new ServerProxyEventCallback());
    }

    @Override
    public void start() {
        if (messageReceiver != null) {
            messageReceiver.start();
            log.debug("Started ServerProxyMessageManager Message Receiver...");
        } else {
            log.info("ServerProxyMessageManager Failed to Start, Invalid Message Receiver...");
        }
        
        while (!messageSenderReady) {
        	try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				log.info("ServerProxyMessageManager Failed to Start, message sender crashed...");
				JVMUtils.killJVM(log, false, false, e);
			}
        }
    }

    @Override
    public void stop() {
        if (messageReceiver != null) {
            messageReceiver.stop();
            log.debug("Stopped ServerProxyMessageManager Message Receiver...");
        } else {
            log.info("ServerProxyMessageManager Failed to Stop, Invalid Message Receiver...");
        }
    }

    @Override
    public void send(byte[] bytes) {
        messageSender.send(bytes);
    }

    private void KillJVM(ShutdownCmd shutdownCmd, boolean sendToServerProxy) {
        log.setEnableLogging(true);
        log.info("Kill JVM requested");
        log.info(shutdownCmd.toString());
        log.info("Stop Receiving Feeds");
        // EbsLiveMarketDataServiceFactory.getEbsLiveMarketDataService().stopReceivingFeeds(sendToServerProxy);
        JVMUtils.killJVM(log, false, true, new Exception(shutdownCmd.getReason()));
    }

    private class ServerProxyEventCallback implements LBMSourceEventCallback {
        public int onSourceEvent(Object arg, LBMSourceEvent sourceEvent) {
            try {
                switch (sourceEvent.type()) {
                case LBM.SRC_EVENT_CONNECT:
                    currentNumberOfReceivers.incrementAndGet();
                    log.info("[" + currentNumberOfReceivers + "] Receiver CONNECTED on Topic " + senderTopic + " [" + sourceEvent.dataString() + "]");
                    messageSenderReady = true;
                    break;
                case LBM.SRC_EVENT_DISCONNECT:
                    currentNumberOfReceivers.decrementAndGet();
                    log.info("[" + currentNumberOfReceivers + "] Receiver DISCONNECTED on Topic " + senderTopic + " [" + sourceEvent.dataString() + "]");
                    ShutdownCmd shutdownCmd = new ShutdownCmd(ComponentName.SERVER_PROXY, CommonConstants.VALUE_COMPONENT_NAME);
                    shutdownCmd.setReason(ComponentName.SERVER_PROXY.toString() + " Receiver DISCONNECTED");
                    KillJVM(shutdownCmd, false);
                    break;
                default:
                    break;
                }
                return 0;
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
    }

}
