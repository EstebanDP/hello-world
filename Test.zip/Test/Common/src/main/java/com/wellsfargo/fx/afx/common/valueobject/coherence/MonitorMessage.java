package com.wellsfargo.fx.afx.common.valueobject.coherence;

import java.io.Serializable;
import java.util.Date;

@SuppressWarnings("serial")
public class MonitorMessage implements Serializable {

    private Date date;
    private String message;
    
    public MonitorMessage(Date date, String message) {
    	this.date = date;
    	this.message = message;
    }
    
	public void setDate(Date date) {
		this.date = date;
	}
	
	public Date getDate() {
		return date;
	}
	
	public void setMessage(String message) {
		this.message = message;
	}
	
	public String getMessage() {
		return message;
	}
}
