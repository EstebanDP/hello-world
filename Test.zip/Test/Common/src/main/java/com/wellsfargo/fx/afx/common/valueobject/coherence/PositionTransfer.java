package com.wellsfargo.fx.afx.common.valueobject.coherence;

import java.io.Serializable;
import java.util.Date;

import com.wellsfargo.fx.afx.common.valueobject.Side;

@SuppressWarnings("serial")
public class PositionTransfer implements Serializable {
	
    private String positionTransferBuffetId;
    private String currencyPair;
    private double quantity;
    private double ctrQuantity;
    private String rate;
    private String source;
    private String bookFrom;
    private String bookTo;
    private String portfolio;
    private String userId;
    private String reasonForReject;
    private boolean rejectedTransfer;
    private Side side;
    private String reason;
    private Date transferCreationTime;
    private Date afxTime;
    private int tradeCounter; // used by GUI

    public String getPositionTransferBuffetId() {
        return positionTransferBuffetId;
    }

    public void setPositionTransferBuffetId(String positionTransferBuffetId) {
        this.positionTransferBuffetId = positionTransferBuffetId;
    }

    public String getCurrencyPair() {
        return currencyPair;
    }

    public void setCurrencyPair(String currencyPair) {
        this.currencyPair = currencyPair;
    }

    public double getQuantity() {
        return quantity;
    }

    public void setQuantity(double quantity) {
        this.quantity = quantity;
    }
    
    public double getCtrQuantity() {
        return ctrQuantity;
    }

    public void setCtrQuantity(double ctrQuantity) {
        this.ctrQuantity = ctrQuantity;
    }

    public String getRate() {
        return rate;
    }

    public void setRate(String rate) {
        this.rate = rate;
    }

    public Date getTransferCreationTime() {
        return transferCreationTime;
    }

    public void setTransferCreationTime(Date transferCreationTime) {
        this.transferCreationTime = transferCreationTime;
    }
    
    public Date getAfxTime() {
        return afxTime;
    }

    public void setAfxTime(Date afxTime) {
        this.afxTime = afxTime;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getSource() {
        return source;
    }

    public void setBookFrom(String bookFrom) {
		this.bookFrom = bookFrom;
	}

	public String getBookFrom() {
		return bookFrom;
	}

	public void setBookTo(String bookTo) {
		this.bookTo = bookTo;
	}

	public String getBookTo() {
		return bookTo;
	}
	
	public void setPortfolio(String portfolio) {
		this.portfolio = portfolio;
	}

	public String getPortfolio() {
		return portfolio;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserId() {
		return userId;
	}
	
	public void setRejectedTransfer(boolean rejectedTransfer) {
		this.rejectedTransfer = rejectedTransfer;
	}

	public boolean isRejectedTransfer() {
		return rejectedTransfer;
	}
	
	public void setSide(Side side) {
		this.side = side;
	}

	public Side getSide() {
		return side;
	}
	
    public void setTradeCounter(int tradeCounter) {
        this.tradeCounter = tradeCounter;
    }

    public int getTradeCounter() {
        return tradeCounter;
    }
    
	public void setReason(String reason) {
		this.reason = reason;
	}

	public String getReason() {
		return reason;
	}

    public void setReasonForReject(String reasonForReject) {
		this.reasonForReject = reasonForReject;
	}

	public String getReasonForReject() {
		return reasonForReject;
	}

	public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(tradeCounter).append('\t');
        sb.append(positionTransferBuffetId).append('\t');
        sb.append(currencyPair).append('\t');
        sb.append(side.toString()).append('\t');
        sb.append(quantity).append('\t');
        sb.append(ctrQuantity).append('\t');
        sb.append(source).append('\t');
        sb.append(bookFrom).append('\t');
        sb.append(bookTo).append('\t');
        sb.append(portfolio).append('\t');
        sb.append(reason).append('\t');
        sb.append(reasonForReject).append('\t');
        sb.append(transferCreationTime.toString()).append('\t');
        sb.append(afxTime.toString()).append('\t');
        sb.append(rejectedTransfer);

        return sb.toString();
    }
}