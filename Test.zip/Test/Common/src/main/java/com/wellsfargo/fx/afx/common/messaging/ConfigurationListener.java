package com.wellsfargo.fx.afx.common.messaging;

public interface ConfigurationListener {
	
	public void onChange(String configName, String configValue);

}
