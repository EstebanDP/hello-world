package com.wellsfargo.fx.afx.common.valueobject.coherence;

import java.io.Serializable;
import java.util.Date;

@SuppressWarnings("serial")
public class CurrencyPair implements Serializable {
    private String name;
    private int ordinal;
    private int scale;
    private boolean enabled;
    private boolean updateOnGUI;
	// To avoid loops with insertion to the cache
	private boolean updateCache;
    private Currency firstCurrency;
    private Currency secondCurrency;
	private String updateUser;
	private Date updateDate;
    
	public void setName(String name) {
		this.name = name;
	}
	
	public String getName() {
		return name;
	}

	public void setOrdinal(int ordinal) {
		this.ordinal = ordinal;
	}

	public int getOrdinal() {
		return ordinal;
	}

	public void setScale(int scale) {
		this.scale = scale;
	}

	public int getScale() {
		return scale;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	public boolean isEnabled() {
		return enabled;
	}

	public void setUpdateOnGUI(boolean updateOnGUI) {
		this.updateOnGUI = updateOnGUI;
	}

	public boolean isUpdateOnGUI() {
		return updateOnGUI;
	}

	public void setUpdateCache(boolean updateCache) {
		this.updateCache = updateCache;
	}

	public boolean isUpdateCache() {
		return updateCache;
	}

	public void setFirstCurrency(Currency firstCurrency) {
		this.firstCurrency = firstCurrency;
	}

	public Currency getFirstCurrency() {
		return firstCurrency;
	}

	public void setSecondCurrency(Currency secondCurrency) {
		this.secondCurrency = secondCurrency;
	}

	public Currency getSecondCurrency() {
		return secondCurrency;
	}

	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}

	public String getUpdateUser() {
		return updateUser;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	public Date getUpdateDate() {
		return updateDate;
	}
}
