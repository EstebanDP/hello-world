package com.wellsfargo.fx.afx.common.valueobject.coherence;

import java.io.Serializable;
import java.util.Date;

import com.wellsfargo.fx.afx.common.valueobject.ComponentName;

@SuppressWarnings("serial")
public class Configuration implements Serializable {
    private ComponentName componentName;
    private String configType;
    private String configurationName;
    private String configurationValue;
    private String userName;
    private String description;
    private Date updateDate;
    private boolean saveToDatabase;
    
    public ComponentName getComponentName() {
        return componentName;
    }

    public void setComponentName(ComponentName componentName) {
        this.componentName = componentName;
    }

    public void setConfigType(String configType) {
		this.configType = configType;
	}

	public String getConfigType() {
		return configType;
	}

	public String getConfigurationName() {
        return configurationName;
    }

    public void setConfigurationName(String configurationName) {
        this.configurationName = configurationName;
    }

    public String getConfigurationValue() {
        return configurationValue;
    }

    public void setConfigurationValue(String configurationValue) {
        this.configurationValue = configurationValue;
    }

    public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	public Date getUpdateDate() {
		return updateDate;
	}

	public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
    
	public void setSaveToDatabase(boolean saveToDatabase) {
		this.saveToDatabase = saveToDatabase;
	}

	public boolean isSaveToDatabase() {
		return saveToDatabase;
	}
    
	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("Component Name: ").append(componentName.toString()).append('\n');
		sb.append("Configuration Type: ").append(configType).append('\n');
		sb.append("Save to Database: ").append(saveToDatabase).append('\n');
		sb.append("Configuration Name: ").append(configurationName).append('\n');
		sb.append("Configuration Value: ").append(configurationValue.toString()).append('\n');
		sb.append("User Name: ").append(userName.toString()).append('\n');
		sb.append("Update Date: ").append(updateDate.toString()).append('\n');
		sb.append("Description: ").append(description.toString());
		
		return sb.toString();
	}
}
