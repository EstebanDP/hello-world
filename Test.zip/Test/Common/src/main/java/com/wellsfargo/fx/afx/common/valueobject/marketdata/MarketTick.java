package com.wellsfargo.fx.afx.common.valueobject.marketdata;

import java.util.ArrayList;
import java.util.List;

import com.wellsfargo.fx.afx.common.util.Util;
import com.wellsfargo.fx.afx.common.valueobject.CurrencyPair;
import com.wellsfargo.fx.afx.common.valueobject.MessageType;
import com.wellsfargo.fx.afx.common.valueobject.ValueObject;

public class MarketTick extends ValueObject {

    // TODO (Ravi) use unique id(snapshot time) in log statements
    private static final byte version = 1;
    private long tickReceivedTime;
    private long sentTime;
    private String snapShotTime;
    private String circuit;
    private List<CurrencyPairDelta> currencyDeltas = new ArrayList<CurrencyPairDelta>();

    public String getCircuit() {
        return circuit;
    }

    public void setCircuit(String circuit) {
        this.circuit = circuit;
    }

    public long getTickReceivedTime() {
        return tickReceivedTime;
    }

    public void setTickReceivedTime(long tickReceivedTime) {
        this.tickReceivedTime = tickReceivedTime;
    }

    public String getSnapShotTime() {
        return snapShotTime;
    }

    public void setSnapShotTime(String msgTime) {
        this.snapShotTime = msgTime;
    }

    public long getSentTime() {
        return sentTime;
    }

    public void setSentTime(long sentTime) {
        this.sentTime = sentTime;
    }

    public CurrencyPairDelta getCurrencyPairDelta(CurrencyPair currencyPair) {
        for (CurrencyPairDelta cpd : currencyDeltas) {
            if (cpd.getCurrencyPair() == currencyPair) {
                return cpd;
            }
        }
        return null;
    }

    @Override
    public byte[] toBytes() {
        int length = 1 + 1 + 8 + 8 + snapShotTime.length() + 1 + 1;
        for (CurrencyPairDelta delta : currencyDeltas) {
            length += delta.getByteLength();
        }

        byte[] bytes = new byte[length];

        int pos = 0;
        bytes[pos++] = MessageType.MARKET_TICK;
        bytes[pos++] = version;
        pos = Util.writeLongToByteArray(tickReceivedTime, bytes, pos);
        pos = Util.writeLongToByteArray(sentTime, bytes, pos);
        pos = Util.writeStringToByteArray(snapShotTime, bytes, pos);

        bytes[pos++] = (byte) currencyDeltas.size();
        for (CurrencyPairDelta delta : currencyDeltas) {
            pos = delta.writeBytes(bytes, pos);
        }

        return bytes;
    }

    @Override
    public int readFrom(byte[] bytes) {
        int pos = 2; // skip type and version
        tickReceivedTime = Util.readLongFromBytes(bytes, pos);
        pos += 8;
        sentTime = Util.readLongFromBytes(bytes, pos);
        pos += 8;

        int msgTimeLength = bytes[pos++];
        snapShotTime = Util.readStringFromBytes(bytes, msgTimeLength, pos);
        pos += msgTimeLength;

        int length = bytes[pos++];
        for (int i = 0; i < length; i++) {
            CurrencyPairDelta delta = new CurrencyPairDelta();
            pos = delta.readFrom(bytes, pos);
            currencyDeltas.add(delta);
        }

        return pos;
    }

    public void addEBSMarketCurrencyDeltas(CurrencyPairDelta ebsMarketCurrencyDelta) {
        currencyDeltas.add(ebsMarketCurrencyDelta);
    }

    public List<CurrencyPairDelta> getEBSMarketCurrencyDeltasList() {
        return currencyDeltas;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append('\t').append(tickReceivedTime).append('\t');
        sb.append(sentTime).append('\t');
        sb.append(snapShotTime).append('\n');
        for (CurrencyPairDelta delta : currencyDeltas) {
            delta.appendToString(sb);
        }
        return sb.toString();
    }

    public static class CurrencyPairDelta {

        private CurrencyPair currencyPair;
        private short bitmap;
        private float bid;
        private float offer;
        private float bidQuantity;
        private float offerQuantity;
        private float bid2;
        private float offer2;
        private float bidQuantity2;
        private float offerQuantity2;
        private float bid3;
        private float offer3;
        private float bidQuantity3;
        private float offerQuantity3;
        private float paid;
        private float given;

        private static final int FIELD_BID = 1;
        private static final int FIELD_OFFER = 2;
        private static final int FIELD_BID_QUANTITY = 4;
        private static final int FIELD_OFFER_QUANTITY = 8;

        private static final int FIELD_BID_2 = 16;
        private static final int FIELD_OFFER_2 = 32;
        private static final int FIELD_BID_QUANTITY_2 = 64;
        private static final int FIELD_OFFER_QUANTITY_2 = 128;

        private static final int FIELD_BID_3 = 256;
        private static final int FIELD_OFFER_3 = 512;
        private static final int FIELD_BID_QUANTITY_3 = 1024;
        private static final int FIELD_OFFER_QUANTITY_3 = 2048;

        private static final int FIELD_PAID = 4096;
        private static final int FIELD_GIVEN = 8192;

        public int getByteLength() {
            int length = 1 + 2;
            if (hasBid()) {
                length += 4;
            }
            if (hasOffer()) {
                length += 4;
            }
            if (hasBidQuantity()) {
                length += 4;
            }
            if (hasOfferQuantity()) {
                length += 4;
            }

            if (hasBid2()) {
                length += 4;
            }
            if (hasOffer2()) {
                length += 4;
            }
            if (hasBidQuantity2()) {
                length += 4;
            }
            if (hasOfferQuantity2()) {
                length += 4;
            }

            if (hasBid3()) {
                length += 4;
            }
            if (hasOffer3()) {
                length += 4;
            }
            if (hasBidQuantity3()) {
                length += 4;
            }
            if (hasOfferQuantity3()) {
                length += 4;
            }
            if (hasPaid()) {
                length += 4;
            }
            if (hasGiven()) {
                length += 4;
            }

            return length;
        }

        public int readFrom(byte[] bytes, int pos) {
            currencyPair = CurrencyPair.valueOf(bytes[pos++]);

            bitmap = Util.readShortFromBytes(bytes, pos);
            pos += 2;

            if (hasBid()) {
                bid = Util.readFloatFromBytes(bytes, pos);
                pos += 4;
            }
            if (hasOffer()) {
                offer = Util.readFloatFromBytes(bytes, pos);
                pos += 4;
            }
            if (hasBidQuantity()) {
                bidQuantity = Util.readFloatFromBytes(bytes, pos);
                pos += 4;
            }
            if (hasOfferQuantity()) {
                offerQuantity = Util.readFloatFromBytes(bytes, pos);
                pos += 4;
            }

            if (hasBid2()) {
                bid2 = Util.readFloatFromBytes(bytes, pos);
                pos += 4;
            }
            if (hasOffer2()) {
                offer2 = Util.readFloatFromBytes(bytes, pos);
                pos += 4;
            }
            if (hasBidQuantity2()) {
                bidQuantity2 = Util.readFloatFromBytes(bytes, pos);
                pos += 4;
            }
            if (hasOfferQuantity2()) {
                offerQuantity2 = Util.readFloatFromBytes(bytes, pos);
                pos += 4;
            }

            if (hasBid3()) {
                bid3 = Util.readFloatFromBytes(bytes, pos);
                pos += 4;
            }
            if (hasOffer3()) {
                offer3 = Util.readFloatFromBytes(bytes, pos);
                pos += 4;
            }
            if (hasBidQuantity3()) {
                bidQuantity3 = Util.readFloatFromBytes(bytes, pos);
                pos += 4;
            }
            if (hasOfferQuantity3()) {
                offerQuantity3 = Util.readFloatFromBytes(bytes, pos);
                pos += 4;
            }
            if (hasPaid()) {
                paid = Util.readFloatFromBytes(bytes, pos);
                pos += 4;
            }
            if (hasGiven()) {
                given = Util.readFloatFromBytes(bytes, pos);
                pos += 4;
            }

            return pos;
        }

        public int writeBytes(byte[] bytes, int pos) {
            bytes[pos++] = (byte) currencyPair.ordinal();
            pos = Util.writeShortToByteArray(bitmap, bytes, pos);
            if (hasBid()) {
                pos = Util.writeFloatToByteArray(bid, bytes, pos);
            }
            if (hasOffer()) {
                pos = Util.writeFloatToByteArray(offer, bytes, pos);
            }
            if (hasBidQuantity()) {
                pos = Util.writeFloatToByteArray(bidQuantity, bytes, pos);
            }
            if (hasOfferQuantity()) {
                pos = Util.writeFloatToByteArray(offerQuantity, bytes, pos);
            }

            if (hasBid2()) {
                pos = Util.writeFloatToByteArray(bid2, bytes, pos);
            }
            if (hasOffer2()) {
                pos = Util.writeFloatToByteArray(offer2, bytes, pos);
            }
            if (hasBidQuantity2()) {
                pos = Util.writeFloatToByteArray(bidQuantity2, bytes, pos);
            }
            if (hasOfferQuantity2()) {
                pos = Util.writeFloatToByteArray(offerQuantity2, bytes, pos);
            }

            if (hasBid3()) {
                pos = Util.writeFloatToByteArray(bid3, bytes, pos);
            }
            if (hasOffer3()) {
                pos = Util.writeFloatToByteArray(offer3, bytes, pos);
            }
            if (hasBidQuantity3()) {
                pos = Util.writeFloatToByteArray(bidQuantity3, bytes, pos);
            }
            if (hasOfferQuantity3()) {
                pos = Util.writeFloatToByteArray(offerQuantity3, bytes, pos);
            }
            if (hasPaid()) {
                pos = Util.writeFloatToByteArray(paid, bytes, pos);
            }
            if (hasGiven()) {
                pos = Util.writeFloatToByteArray(given, bytes, pos);
            }
            return pos;
        }

        public CurrencyPair getCurrencyPair() {
            return currencyPair;
        }

        public void setCurrencyPair(String currencyPair) {
            this.currencyPair = CurrencyPair.valueOf(currencyPair.replace('/', '_'));
        }

        public void setCurrencyPair(CurrencyPair currencyPair) {
            this.currencyPair = currencyPair;
        }

        public float getBid() {
            return bid;
        }

        public void setBid(float bid) {
            this.bid = bid;
            bitmap = (short) (bitmap | FIELD_BID);
        }

        public boolean hasBid() {
            return (bitmap & FIELD_BID) > 0;
        }

        public float getOffer() {
            return offer;
        }

        public void setOffer(float offer) {
            this.offer = offer;
            bitmap = (short) (bitmap | FIELD_OFFER);
        }

        public boolean hasOffer() {
            return (bitmap & FIELD_OFFER) > 0;
        }

        public float getBidQuantity() {
            return bidQuantity;
        }

        public void setBidQuantity(float bidQuantity) {
            this.bidQuantity = bidQuantity;
            bitmap = (short) (bitmap | FIELD_BID_QUANTITY);
        }

        public boolean hasBidQuantity() {
            return (bitmap & FIELD_BID_QUANTITY) > 0;
        }

        public float getOfferQuantity() {
            return offerQuantity;
        }

        public void setOfferQuantity(float offerQuantity) {
            this.offerQuantity = offerQuantity;
            bitmap = (short) (bitmap | FIELD_OFFER_QUANTITY);
        }

        public boolean hasOfferQuantity() {
            return (bitmap & FIELD_OFFER_QUANTITY) > 0;
        }

        public float getBid2() {
            return bid2;
        }

        public void setBid2(float bid2) {
            this.bid2 = bid2;
            bitmap = (short) (bitmap | FIELD_BID_2);
        }

        public boolean hasBid2() {
            return (bitmap & FIELD_BID_2) > 0;
        }

        public float getOffer2() {
            return offer2;
        }

        public void setOffer2(float offer2) {
            this.offer2 = offer2;
            bitmap = (short) (bitmap | FIELD_OFFER_2);
        }

        public boolean hasOffer2() {
            return (bitmap & FIELD_OFFER_2) > 0;
        }

        public float getBidQuantity2() {
            return bidQuantity2;
        }

        public void setBidQuantity2(float bidQuantity2) {
            this.bidQuantity2 = bidQuantity2;
            bitmap = (short) (bitmap | FIELD_BID_QUANTITY_2);
        }

        public boolean hasBidQuantity2() {
            return (bitmap & FIELD_BID_QUANTITY_2) > 0;
        }

        public float getOfferQuantity2() {
            return offerQuantity2;
        }

        public void setOfferQuantity2(float offerQuantity2) {
            this.offerQuantity2 = offerQuantity2;
            bitmap = (short) (bitmap | FIELD_OFFER_QUANTITY_2);
        }

        public boolean hasOfferQuantity2() {
            return (bitmap & FIELD_OFFER_QUANTITY_2) > 0;
        }

        public float getBid3() {
            return bid3;
        }

        public void setBid3(float bid3) {
            this.bid3 = bid3;
            bitmap = (short) (bitmap | FIELD_BID_3);
        }

        public boolean hasBid3() {
            return (bitmap & FIELD_BID_3) > 0;
        }

        public float getOffer3() {
            return offer3;
        }

        public void setOffer3(float offer3) {
            this.offer3 = offer3;
            bitmap = (short) (bitmap | FIELD_OFFER_3);
        }

        public boolean hasOffer3() {
            return (bitmap & FIELD_OFFER_3) > 0;
        }

        public float getBidQuantity3() {
            return bidQuantity3;
        }

        public void setBidQuantity3(float bidQuantity3) {
            this.bidQuantity3 = bidQuantity3;
            bitmap = (short) (bitmap | FIELD_BID_QUANTITY_3);
        }

        public boolean hasBidQuantity3() {
            return (bitmap & FIELD_BID_QUANTITY_3) > 0;
        }

        public float getOfferQuantity3() {
            return offerQuantity3;
        }

        public void setOfferQuantity3(float offerQuantity3) {
            this.offerQuantity3 = offerQuantity3;
            bitmap = (short) (bitmap | FIELD_OFFER_QUANTITY_3);
        }

        public boolean hasOfferQuantity3() {
            return (bitmap & FIELD_OFFER_QUANTITY_3) > 0;
        }

        public boolean hasPaid() {
            return (bitmap & FIELD_PAID) > 0;
        }

        public float getPaid() {
            return paid;
        }

        public void setPaid(float paid) {
            this.paid = paid;
            bitmap = (short) (bitmap | FIELD_PAID);
        }

        public boolean hasGiven() {
            return (bitmap & FIELD_GIVEN) > 0;
        }

        public float getGiven() {
            return given;
        }

        public void setGiven(float given) {
            this.given = given;
            bitmap = (short) (bitmap | FIELD_GIVEN);
        }

        public void appendToString(StringBuilder sb) {
            sb.append("\t").append(currencyPair);
            sb.append("\t\t");

            if (hasBid()) {
                sb.append(currencyPair.getFormattedString(getBid()));
            } else {
                sb.append('-');
            }
            sb.append("\t");

            if (hasOffer()) {
                sb.append(currencyPair.getFormattedString(getOffer()));
            } else {
                sb.append('-');
            }
            sb.append("\t");

            if (hasBidQuantity()) {
                sb.append(getBidQuantity());
            } else {
                sb.append('-');
            }
            sb.append("\t");

            if (hasOfferQuantity()) {
                sb.append(getOfferQuantity());
            } else {
                sb.append('-');
            }

            sb.append('\n');

            // sb.append('\t');
            // if (hasPaid()) {
            // sb.append(paid);
            // } else {
            // sb.append('-');
            // }
            // sb.append('\t');
            //
            // if (hasGiven()) {
            // sb.append(given);
            // } else {
            // sb.append('-');
            // }
            // sb.append('\t');

            // sb.append("\n\t\t");
            // if (hasBid2()) {
            // sb.append(getBid2());
            // } else {
            // sb.append('-');
            // }
            // sb.append("\t");
            //
            // if (hasOffer2()) {
            // sb.append(getOffer2());
            // } else {
            // sb.append('-');
            // }
            // sb.append("\t");
            //
            // if (hasBidQuantity2()) {
            // sb.append(getBidQuantity2());
            // } else {
            // sb.append('-');
            // }
            // sb.append("\t");
            //
            // if (hasOfferQuantity2()) {
            // sb.append(getOfferQuantity2());
            // } else {
            // sb.append('-');
            // }
            //
            // sb.append("\n\t\t");
            // if (hasBid3()) {
            // sb.append(getBid3());
            // } else {
            // sb.append('-');
            // }
            // sb.append("\t");
            //
            // if (hasOffer3()) {
            // sb.append(getOffer3());
            // } else {
            // sb.append('-');
            // }
            // sb.append("\t");
            //
            // if (hasBidQuantity3()) {
            // sb.append(getBidQuantity3());
            // } else {
            // sb.append('-');
            // }
            // sb.append("\t");
            //
            // if (hasOfferQuantity3()) {
            // sb.append(getOfferQuantity3());
            // } else {
            // sb.append('-');
            // }

            // sb.append("\n");
        }

        public String toString() {
            StringBuilder sb = new StringBuilder();
            appendToString(sb);
            return sb.toString();
        }

    }

}
