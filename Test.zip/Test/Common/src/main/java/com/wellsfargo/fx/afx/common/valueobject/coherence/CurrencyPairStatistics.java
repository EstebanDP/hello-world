package com.wellsfargo.fx.afx.common.valueobject.coherence;

import java.io.Serializable;
import java.util.Map;

import javolution.util.FastMap;

@SuppressWarnings("serial")
public final class CurrencyPairStatistics implements Serializable {

    private Map<String, OrderRatios> orderFillRatios = new FastMap<String, OrderRatios>();

    public void incrementOrderFilled(String currencyPair, int count) {
        OrderRatios or = getOrderRatios(currencyPair);
        or.incrementFilled(count);
    }

    public void incrementOrderPartiallyFilled(String currencyPair, int count) {
        OrderRatios or = getOrderRatios(currencyPair);
        or.incrementPartiallyFilled(count);
    }

    public void incrementOrderTotal(String currencyPair, int count) {
        OrderRatios or = getOrderRatios(currencyPair);
        or.incrementTotal(count);
    }

    public void incrementOrderCancelled(String currencyPair, int count) {
        OrderRatios or = getOrderRatios(currencyPair);
        or.incrementCancelled(count);
    }

    public void incrementOrderRejectedByExchange(String currencyPair, int count) {
        OrderRatios or = getOrderRatios(currencyPair);
        or.incrementRejectedByExchange(count);
    }

    public void incrementOrderRejectedByThroughput(String currencyPair, int count) {
        OrderRatios or = getOrderRatios(currencyPair);
        or.incrementRejectedByThroughput(count);
    }

    public void incrementOrderRejectedByLatency(String currencyPair, int count) {
        OrderRatios or = getOrderRatios(currencyPair);
        or.incrementRejectedByLatency(count);
    }

    public void incrementOrderRejectedByValidation(String currencyPair, int count) {
        OrderRatios or = getOrderRatios(currencyPair);
        or.incrementRejectedByValidation(count);
    }

    public Map<String, OrderRatios> getOrderFillRatios() {
        return orderFillRatios;
    }

    private OrderRatios getOrderRatios(String currencyPair) {
        OrderRatios or = orderFillRatios.get(currencyPair);
        if (or == null) {
            or = new OrderRatios();
            orderFillRatios.put(currencyPair, or);
        }
        return or;
    }

    public String toString() {
    	StringBuilder sb = new StringBuilder();
    	for (String ccyPair : getOrderFillRatios().keySet()) {
    		sb.append("*************************\n").append("Currency: ").append(ccyPair).append("\n").append(getOrderRatios(ccyPair).toString());
    	}
    	return sb.toString();
    }
}
