package com.wellsfargo.fx.afx.common.valueobject;

public enum ComponentName {
    NONE, GUI, ALL, MARKET_DATA_GATEWAY, STRATEGY, POSITION_MANAGER, ORDER_ROUTING_GATEWAY, SERVER_PROXY, CLIENT_PROXY, MARKET_TICK_SIMULATOR, 
    CNX_ORDER_ROUTING_GATEWAY, CNX_MARKET_DATA_GATEWAY, INTEGRAL_MARKET_DATA_GATEWAY, INTEGRAL_ORDER_ROUTING_GATEWAY, POSITION_MANAGER_ECOM, GFX_API, GLOBAL_STATUS;

    public static ComponentName valueOf(final int ordinal) {
        if (ordinal == NONE.ordinal()) {
            return NONE;
        } else if (ordinal == GUI.ordinal()) {
            return GUI;
        } else if (ordinal == ALL.ordinal()) {
            return ALL;
        } else if (ordinal == MARKET_DATA_GATEWAY.ordinal()) {
            return MARKET_DATA_GATEWAY;
        } else if (ordinal == STRATEGY.ordinal()) {
            return STRATEGY;
        } else if (ordinal == POSITION_MANAGER.ordinal()) {
            return POSITION_MANAGER;
        } else if (ordinal == ORDER_ROUTING_GATEWAY.ordinal()) {
            return ORDER_ROUTING_GATEWAY;
        } else if (ordinal == SERVER_PROXY.ordinal()) {
            return SERVER_PROXY;
        } else if (ordinal == CLIENT_PROXY.ordinal()) {
            return CLIENT_PROXY;
        } else if (ordinal == MARKET_TICK_SIMULATOR.ordinal()) {
            return MARKET_TICK_SIMULATOR;
        } else if (ordinal == CNX_ORDER_ROUTING_GATEWAY.ordinal()) {
            return CNX_ORDER_ROUTING_GATEWAY;
        } else if (ordinal == CNX_MARKET_DATA_GATEWAY.ordinal()) {
            return CNX_MARKET_DATA_GATEWAY;
        } else if (ordinal == POSITION_MANAGER_ECOM.ordinal()) {
            return POSITION_MANAGER_ECOM;
        } else if (ordinal == INTEGRAL_MARKET_DATA_GATEWAY.ordinal()) {
            return INTEGRAL_MARKET_DATA_GATEWAY;
        } else if (ordinal == INTEGRAL_ORDER_ROUTING_GATEWAY.ordinal()) {
            return INTEGRAL_ORDER_ROUTING_GATEWAY;
        } else if (ordinal == GFX_API.ordinal()) {
            return GFX_API;
        } else if (ordinal == GLOBAL_STATUS.ordinal()) {
            return GLOBAL_STATUS;
        }
        return null;
    }
    
    public static ComponentName getByName(String name) {
        return valueOf(name);
    }
}