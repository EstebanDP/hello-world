package com.wellsfargo.fx.afx.common.valueobject.orderdata;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;

import com.wellsfargo.fx.afx.common.util.CommonConstants;
import com.wellsfargo.fx.afx.common.util.ConfigurationLoader;
import com.wellsfargo.fx.afx.common.util.Util;
import com.wellsfargo.fx.afx.common.valueobject.ComponentType;
import com.wellsfargo.fx.afx.common.valueobject.Currency;
import com.wellsfargo.fx.afx.common.valueobject.CurrencyPair;
import com.wellsfargo.fx.afx.common.valueobject.Exchange;
import com.wellsfargo.fx.afx.common.valueobject.ExecutionType;
import com.wellsfargo.fx.afx.common.valueobject.MessageType;
import com.wellsfargo.fx.afx.common.valueobject.OrderAction;
import com.wellsfargo.fx.afx.common.valueobject.OrderStatus;
import com.wellsfargo.fx.afx.common.valueobject.OrderType;
import com.wellsfargo.fx.afx.common.valueobject.Side;
import com.wellsfargo.fx.afx.common.valueobject.TransactionAction;
import com.wellsfargo.fx.afx.common.valueobject.ValueObject;
import com.wellsfargo.fx.afx.common.valueobject.gui.PositionInfo;
import com.wellsfargo.fx.afx.common.valueobject.gui.PositionInfo.PositionDetail;

public class TransactionRequest extends ValueObject {
    // private static Logger log = LoggerFactory.getLogger("");
	private static final ComponentType componentType = ComponentType.getByName(ConfigurationLoader.getInstance().getString(CommonConstants.CONST_COMPONENT_TYPE));
    private static final MathContext mc = new MathContext(10, RoundingMode.HALF_DOWN);
    private static final String DELIMITER = "|";
    private static final byte version = 1;
    private int strategyId;
    private int groupId;
    private long tickReceivedTime;
    private long responseReceivedTime;
    private String snapshotTime;
    private float expectedPnL = CommonConstants.CONST_NA;
    private float initialArbPoints = CommonConstants.CONST_NA;
    private float expectedArbPoints = CommonConstants.CONST_NA;
    private float actualArbPoints = CommonConstants.CONST_NA;
    private ExecutionType type;
    private boolean checkTimeDelay = true;
    private boolean checkTimeDelay2 = false;
    private List<Order> orders = new ArrayList<Order>();
    private List<TransactionRequest> childTransactions = new ArrayList<TransactionRequest>();
    TransactionAction action = TransactionAction.SUBMIT_ORDERS;
    private transient TransactionRequest parent;

    public TransactionRequest() {

    }

    public int getStrategyId() {
        return strategyId;
    }

    public synchronized void setStrategyId(int strategyId) {
        this.strategyId = strategyId;
        for (Order order : orders) {
            order.setStrategyId(strategyId);
        }
    }

    public int getGroupId() {
        return groupId;
    }

    public synchronized void setGroupId(int groupId) {
        this.groupId = groupId;
        for (Order order : orders) {
            order.setGroupId(groupId);
        }
    }

    public String getTransactionId() {
        return strategyId + DELIMITER + groupId;
    }

    public boolean isLocal() {
        return type == ExecutionType.RESIDUAL;
    }

    public ExecutionType getExecutionType() {
        return type;
    }

    public void setExecutionType(ExecutionType type) {
        this.type = type;
    }

    public boolean isParent() {
        return parent == null;
    }

    protected TransactionRequest getParent() {
        return parent;
    }

    protected void setParent(TransactionRequest parent) {
        this.parent = parent;
    }

    public long getTickReceivedTime() {
        return tickReceivedTime;
    }

    public void setTickReceivedTime(long tickReceivedTime) {
        this.tickReceivedTime = tickReceivedTime;
    }

    public String getSnapshotTime() {
        return snapshotTime;
    }

    public void setSnapshotTime(String snapshotTime) {
        this.snapshotTime = snapshotTime;
    }

    public synchronized boolean isPending() {
        for (Order order : orders) {
            if (order.getOrderStatus() == OrderStatus.NONE) {
                return true;
            }
        }
        return false;
    }

    protected synchronized int getLength() {
        int length = 1 + 1 + 4 + 4 + 8 + 8 + snapshotTime.length() + 1 + 4 + 4 + 4 + 4 + 1 + 1 + 1 + 1 + 1 + 1;
        for (Order order : orders) {
            length += order.getByteLength();
        }
        for (TransactionRequest trans : childTransactions) {
            length += trans.getLength();
        }
        return length;
    }

    @Override
    public synchronized byte[] toBytes() {
        int length = getLength();

        byte[] bytes = new byte[length];
        int pos = 0;
        bytes[pos++] = MessageType.TRANSACTION_REQUEST;
        bytes[pos++] = version;
        pos = Util.writeIntToByteArray(strategyId, bytes, pos);
        pos = Util.writeIntToByteArray(groupId, bytes, pos);
        pos = Util.writeLongToByteArray(tickReceivedTime, bytes, pos);
        pos = Util.writeLongToByteArray(responseReceivedTime, bytes, pos);
        pos = Util.writeStringToByteArray(snapshotTime, bytes, pos);
        pos = Util.writeFloatToByteArray(expectedPnL, bytes, pos);
        pos = Util.writeFloatToByteArray(initialArbPoints, bytes, pos);
        pos = Util.writeFloatToByteArray(expectedArbPoints, bytes, pos);
        pos = Util.writeFloatToByteArray(actualArbPoints, bytes, pos);
        bytes[pos++] = (byte) type.ordinal();
        bytes[pos++] = (byte) action.ordinal();
        bytes[pos++] = Util.booleanToByte(checkTimeDelay);
        bytes[pos++] = Util.booleanToByte(checkTimeDelay2);

        bytes[pos++] = (byte) orders.size();
        for (Order order : orders) {
            pos = order.writeBytes(bytes, pos);
        }

        bytes[pos++] = (byte) childTransactions.size();
        for (TransactionRequest trans : childTransactions) {
            byte[] childBytes = trans.toBytes();
            System.arraycopy(childBytes, 0, bytes, pos, childBytes.length);
            pos += childBytes.length;
        }
        // log.debug(toString());
        return bytes;
    }

    @Override
    public synchronized int readFrom(byte[] bytes) {
        int pos = 2; // skip type and version
        strategyId = Util.readIntFromBytes(bytes, pos);
        pos += 4;
        groupId = Util.readIntFromBytes(bytes, pos);
        pos += 4;
        tickReceivedTime = Util.readLongFromBytes(bytes, pos);
        pos += 8;
        responseReceivedTime = Util.readLongFromBytes(bytes, pos);
        pos += 8;
        int length = bytes[pos++];
        snapshotTime = Util.readStringFromBytes(bytes, length, pos);
        pos += length;
        expectedPnL = Util.readFloatFromBytes(bytes, pos);
        pos += 4;
        initialArbPoints = Util.readFloatFromBytes(bytes, pos);
        pos += 4;
        expectedArbPoints = Util.readFloatFromBytes(bytes, pos);
        pos += 4;
        actualArbPoints = Util.readFloatFromBytes(bytes, pos);
        pos += 4;
        type = ExecutionType.valueOf(bytes[pos++]);
        action = TransactionAction.valueOf(bytes[pos++]);
        checkTimeDelay = Util.byteToBoolean(bytes[pos++]);
        checkTimeDelay2 = Util.byteToBoolean(bytes[pos++]);

        length = bytes[pos++];
        for (int i = 0; i < length; i++) {
            Order order = new Order(strategyId, groupId);
            pos = order.readFrom(bytes, pos);
            orders.add(order);
        }
        length = bytes[pos++];
        int childPos = pos;
        for (int i = 0; i < length; i++) {
            byte[] childBytes = new byte[bytes.length - childPos];
            System.arraycopy(bytes, childPos, childBytes, 0, childBytes.length);
            TransactionRequest trans = new TransactionRequest();
            addChildTransactionRequest(trans);
            childPos = trans.readFrom(childBytes);
            pos += childPos;
            bytes = childBytes;
        }

        // log.debug(toString());
        return pos;
    }

    public synchronized String toString() {
        StringBuilder tb = new StringBuilder();
        tb.append("[Transaction Request] ");
        tb.append(strategyId).append('\t');
        tb.append(groupId).append('\t');
        tb.append(tickReceivedTime).append('\t');
        tb.append(snapshotTime).append('\t');
        tb.append("isComplete:").append(iscomplete()).append('\t');
        tb.append(action).append('\t');
        
        if (componentType.equals(ComponentType.ARB)) {
            tb.append(expectedPnL).append('\t');
            tb.append(initialArbPoints).append('\t');
            tb.append(expectedArbPoints).append('\t');
            tb.append(actualArbPoints);        	
        }

        for (Order order : orders) {
            tb.append("\n\t[Order] ");
            order.appendToString(tb);
        }

        if (childTransactions.size() > 0) {
            tb.append("\n[Child Transactions: ");
            for (TransactionRequest trans : childTransactions) {
                tb.append(trans.toString());
            }
        }
        return tb.toString();
    }

    public synchronized List<Order> getOrderList() {
        return orders;
    }

    public synchronized void addOrder(Order order) {
        order.setStrategyId(strategyId);
        order.setGroupId(groupId);
        if (parent != null) {
            order.setParentTransactionId(parent.getTransactionId());
        } else {
            order.setParentTransactionId(getTransactionId());
        }
        orders.add(order);
    }

    public synchronized Order getOrder(int orderId) {
        for (Order order : orders) {
            if (order.getOrderId() == orderId) {
                return order;
            }
        }
        return null;
    }

    public synchronized Order getOrder(CurrencyPair currencyPair) {
        for (Order order : orders) {
            if (order.getCurrencyPair() == currencyPair) {
                return order;
            }
        }
        return null;
    }

    public synchronized Integer getOrderCount() {
        return orders.size();
    }

    public synchronized void addChildTransactionRequest(TransactionRequest transactionRequest) {
        transactionRequest.setParent(this);
        childTransactions.add(transactionRequest);
    }

    public List<TransactionRequest> getChildTransactionRequests() {
        return childTransactions;
    }

    public synchronized int getExchangeOrderCount(Exchange exchange) {
        int count = 0;
        for (Order order : orders) {
            if (order.getExchange() == exchange) {
                count++;
            }
        }
        return count;
    }

    public synchronized ExchangeRequest getExchangeOrderRequest(Exchange exchange) {
        ExchangeRequest request = new ExchangeRequest();
        request.setExchange(exchange);
        request.setStrategyId(strategyId);
        request.setGroupId(groupId);
        request.setTickReceivedTime(tickReceivedTime);
        request.setSnapshotTime(snapshotTime);
        request.setType(type);
        request.setCheckTimeDelay(checkTimeDelay);
        request.setCheckTimeDelay2(checkTimeDelay2);

        for (Order order : orders) {
            if (order.getExchange() == exchange && (order.getAction() == OrderAction.SUBMIT || order.getAction() == OrderAction.CANCEL)) {
                request.addOrder((Order) order.clone());
            }

        }
        return request;
    }

    public synchronized void updateOrder(Order updatedOrder) {
        // TODO (Esteban) check if all looping can be avoided
        boolean replaced = false;
        for (Order order : orders) {
            if (order.getOrderId() == updatedOrder.getOrderId()) {
                orders.remove(order);
                orders.add(updatedOrder);
                replaced = true;
                break;
            }
        }

        if (!replaced) {
            throw new RuntimeException("Order " + updatedOrder.getOrderId() + " is not a current order in the transaction " + getTransactionId());
        }
    }

    public synchronized boolean iscomplete() {
        for (Order order : orders) {
            if (order.getOrderStatus() == OrderStatus.NONE) {
                return false;
            }
        }

        PositionInfo pi = getPositions();
        boolean complete = !pi.hasResidualPositions();
        return complete;
    }

    public synchronized PositionInfo getPositions() {
        PositionInfo pi = new PositionInfo();
        for (Order order : orders) {
            if (order.getFillQuantity() > 0) {
                addPosition(pi, order);
            }
        }

        for (TransactionRequest trans : childTransactions) {
            pi.addPositions(trans.getPositions());
        }
        return pi;
    }

    /**
     * This includes only positions created by orders that were executed on the exchanges and not the ones that were internally matched
     * 
     * @return
     */
    private synchronized PositionInfo getExecutedPositions() {
        PositionInfo pi = new PositionInfo();
        for (Order order : orders) {
            if (order.getFillQuantity() > 0 && order.getOrderType() != OrderType.INTERNAL) {
                addPosition(pi, order);
            }
        }
        for (TransactionRequest trans : childTransactions) {
            pi.addPositions(trans.getExecutedPositions());
        }
        return pi;
    }

    public PositionInfo getGeneratedResidualPositions() {
        return getExecutedPositions();
    }

    public float getExpectedPnL() {
        return expectedPnL;
    }

    public void setExpectedPnL(float expectedPnL) {
        this.expectedPnL = expectedPnL;
    }

    public float getActualPnL() {
        if (iscomplete()) {
            PositionDetail pd = getPositions().getPositionDetail(Currency.USD);
            if (pd != null) {
                return pd.getPosition().floatValue() * 1000000;
            } else {
                return 0f;
            }
        }
        return CommonConstants.CONST_NA;
    }

    public float getInitialArbPoints() {
        return initialArbPoints;
    }

    public void setInitialArbPoints(float initialArbPoints) {
        this.initialArbPoints = initialArbPoints;
    }

    public float getExpectedArbPoints() {
        return expectedArbPoints;
    }

    public void setExpectedArbPoints(float expectedArbPoints) {
        this.expectedArbPoints = expectedArbPoints;
    }

    public float getActualArbPoints() {
        return actualArbPoints;
    }

    public void setActualArbPoints(float actualArbPoints) {
        this.actualArbPoints = actualArbPoints;
    }

    public synchronized boolean isExecutionComplete() {
        if (isLocal()) {
            for (Order order : orders) {
                if (order.getOrderStatus() == OrderStatus.NONE) {
                    return false;
                }
            }
            return true;
        } else {
            return !getPositions().hasWholePositions();
        }
    }

    private void addPosition(PositionInfo positionInfo, Order order) {
        float quantity = order.getSide() == Side.BUY ? order.getFillQuantity() : -order.getFillQuantity();
        CurrencyPair currencyPair = order.getCurrencyPair();
        float rate = order.getFilledPrice();

        BigDecimal bd = new BigDecimal(Float.toString(quantity), mc);
        addPosition(positionInfo, currencyPair.getFirstCurrency(), bd);
        bd = new BigDecimal(Float.toString(quantity), mc).multiply(new BigDecimal("-1"), mc);
        bd = bd.multiply(new BigDecimal(Float.toString(rate)), mc);
        addPosition(positionInfo, currencyPair.getSecondCurrency(), bd);
    }

    private void addPosition(PositionInfo positionInfo, Currency currency, BigDecimal amount) {
        PositionDetail pd = positionInfo.getPositionDetail(currency);
        if (pd == null) {
            pd = new PositionDetail(currency);
            positionInfo.addPositionDetail(pd);
            pd.setPosition(amount);
        } else {
            pd.setPosition(pd.getPosition().add(amount));
        }
    }

    public synchronized void muteOrders() {
        for (Order order : orders) {
            order.setAction(OrderAction.NONE);
        }
    }

    public TransactionAction getAction() {
        return action;
    }

    public void setAction(TransactionAction action) {
        this.action = action;
    }

    public long getResponseReceivedTime() {
        return responseReceivedTime;
    }

    public void setResponseReceivedTime(long responseReceivedTime) {
        this.responseReceivedTime = responseReceivedTime;
    }

    public boolean checkTimeDelay() {
        return checkTimeDelay;
    }

    public void setCheckTimeDelay(boolean checkTimeDelay) {
        this.checkTimeDelay = checkTimeDelay;
    }

    public boolean checkTimeDelay2() {
        return checkTimeDelay2;
    }

    public void setCheckTimeDelay2(boolean checkTimeDelay2) {
        this.checkTimeDelay2 = checkTimeDelay2;
    }

    public boolean showInGui() {
        if (ExecutionType.AGGRESSIVE == type) {
            return orders.size() > 1 || orders.get(0).getOrderStatus() == OrderStatus.FILLED;
        } else if (ExecutionType.PASSIVE == type) {
            return true;
        } else if (ExecutionType.RESIDUAL == type) {
            return orders.get(0).getOrderStatus() != OrderStatus.REJECTED_BECAUSE_THROUGHPUT_LIMIT_REACHED;
        }
        return true;
    }

    public boolean hasCancelledOrders() {
        for (Order order : orders) {
            if (order.getOrderStatus() == OrderStatus.CANCELLED) {
                return true;
            }
        }
        return false;
    }

    public boolean hasAllOrderNumbers() {
        for (Order order : orders) {
            if (!order.hasOrderId()) {
                return false;
            }
        }
        return true;
    }
}
