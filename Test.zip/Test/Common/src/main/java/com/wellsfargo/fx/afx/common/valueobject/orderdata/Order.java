package com.wellsfargo.fx.afx.common.valueobject.orderdata;

import java.util.StringTokenizer;

import com.wellsfargo.fx.afx.common.util.Util;
import com.wellsfargo.fx.afx.common.valueobject.CurrencyPair;
import com.wellsfargo.fx.afx.common.valueobject.Exchange;
import com.wellsfargo.fx.afx.common.valueobject.MessageType;
import com.wellsfargo.fx.afx.common.valueobject.OrderAction;
import com.wellsfargo.fx.afx.common.valueobject.OrderStatus;
import com.wellsfargo.fx.afx.common.valueobject.OrderType;
import com.wellsfargo.fx.afx.common.valueobject.Side;
import com.wellsfargo.fx.afx.common.valueobject.TimeInForce;
import com.wellsfargo.fx.afx.common.valueobject.ValueObject;

public class Order extends ValueObject implements Cloneable {
    private static final char DELIMITER = '|';
    private int strategyId;
    private int groupId;
    private Exchange exchange = Exchange.EBS;
    private int orderId = -1;
    private OrderAction action = OrderAction.NONE;
    private TimeInForce timeInForce = TimeInForce.IOC;
    private CurrencyPair currencyPair;
    private float targetPrice = -Float.MIN_VALUE;
    private float marketPrice = -Float.MIN_VALUE;
    private float filledPrice = -Float.MIN_VALUE;
    private float orderQuantity = -Float.MIN_VALUE;
    private float fillQuantity = -Float.MIN_VALUE;
    private OrderStatus orderStatus = OrderStatus.NONE;
    private OrderType orderType = OrderType.LIMIT;
    private Side side;
    private boolean intentionalMatching;
    private long responseReceivedTime;
    private String parentTransactionId = "";
    private boolean piggyBackCancellation;
    private boolean aggressiveLeadingLeg;
    private String referenceTransaction = "";

    private transient long sentTime;
    private transient long acceptedTime;

    public Order(int strategyId, int groupId) {
        this.strategyId = strategyId;
        this.groupId = groupId;
    }

    public Order() {

    }

    public int getByteLength() {
        return 4 + 4 + 1 + 1 + 1 + 4 + 1 + 1 + 1 + 4 + 4 + 4 + 4 + 4 + 1 + 1 + 1 + 1 + 8 + parentTransactionId.length() + 1 + 1 + 1
                + referenceTransaction.length() + 1;
    }

    public void appendToString(StringBuilder tb) {
        tb.append(orderId).append('\t');
        tb.append(action).append('\t');
        tb.append(timeInForce).append('\t');
        tb.append(currencyPair.toString()).append('\t');
        tb.append(currencyPair.getFormattedString(marketPrice)).append('\t');
        tb.append(currencyPair.getFormattedString(targetPrice)).append('\t');
        tb.append(currencyPair.getFormattedString(filledPrice)).append('\t');
        tb.append(Util.getAmountAsString(orderQuantity)).append('\t');
        tb.append(Util.getAmountAsString(fillQuantity)).append('\t');
        tb.append(orderStatus).append('\t');
        tb.append(orderType).append('\t');
        tb.append(side).append('\t');
        tb.append("im: ").append(intentionalMatching).append('\t');
        tb.append(responseReceivedTime).append('\t');
        tb.append(parentTransactionId).append('\t');
        tb.append("piggyCancl: ").append(piggyBackCancellation).append('\t');
        tb.append("Aggressive Leading leg: ").append(aggressiveLeadingLeg).append('\t');
        tb.append("Reference Transaction: ").append(referenceTransaction).append('\t');
    }

    @Override
    public int readFrom(byte[] bytes) {
        return readFrom(bytes, 0);
    }

    @Override
    public byte[] toBytes() {
        byte[] bytes = new byte[getByteLength()];
        writeBytes(bytes, 0);
        return bytes;
    }

    public int readFrom(byte[] bytes, int pos) {
        pos += 2;
        strategyId = Util.readIntFromBytes(bytes, pos);
        pos += 4;
        groupId = Util.readIntFromBytes(bytes, pos);
        pos += 4;
        exchange = Exchange.valueOf(bytes[pos++]);
        orderId = Util.readIntFromBytes(bytes, pos);
        pos += 4;
        action = OrderAction.valueOf(bytes[pos++]);
        timeInForce = TimeInForce.valueOf(bytes[pos++]);
        currencyPair = CurrencyPair.valueOf(bytes[pos++]);
        targetPrice = Util.readFloatFromBytes(bytes, pos);
        pos += 4;
        marketPrice = Util.readFloatFromBytes(bytes, pos);
        pos += 4;
        filledPrice = Util.readFloatFromBytes(bytes, pos);
        pos += 4;
        orderQuantity = Util.readFloatFromBytes(bytes, pos);
        pos += 4;
        fillQuantity = Util.readFloatFromBytes(bytes, pos);
        pos += 4;

        orderStatus = OrderStatus.valueOf(bytes[pos++]);
        orderType = OrderType.valueOf(bytes[pos++]);
        side = Side.valueOf(bytes[pos++]);
        intentionalMatching = Util.byteToBoolean(bytes[pos++]);
        responseReceivedTime = Util.readLongFromBytes(bytes, pos);
        pos += 8;
        int length = bytes[pos++];
        parentTransactionId = Util.readStringFromBytes(bytes, length, pos);
        pos += length;
        piggyBackCancellation = Util.byteToBoolean(bytes[pos++]);
        aggressiveLeadingLeg = Util.byteToBoolean(bytes[pos++]);
        length = bytes[pos++];
        referenceTransaction = Util.readStringFromBytes(bytes, length, pos);
        pos += length;
        return pos;
    }

    public int writeBytes(byte[] bytes, int pos) {
        bytes[pos++] = MessageType.ORDER;
        bytes[pos++] = 1;
        pos = Util.writeIntToByteArray(strategyId, bytes, pos);
        pos = Util.writeIntToByteArray(groupId, bytes, pos);
        bytes[pos++] = (byte) exchange.ordinal();
        pos = Util.writeIntToByteArray(orderId, bytes, pos);
        bytes[pos++] = (byte) action.ordinal();
        bytes[pos++] = (byte) timeInForce.ordinal();
        bytes[pos++] = (byte) currencyPair.ordinal();
        pos = Util.writeFloatToByteArray(targetPrice, bytes, pos);
        pos = Util.writeFloatToByteArray(marketPrice, bytes, pos);
        pos = Util.writeFloatToByteArray(filledPrice, bytes, pos);
        pos = Util.writeFloatToByteArray(orderQuantity, bytes, pos);
        pos = Util.writeFloatToByteArray(fillQuantity, bytes, pos);
        bytes[pos++] = (byte) orderStatus.ordinal();
        bytes[pos++] = (byte) orderType.ordinal();
        bytes[pos++] = (byte) side.ordinal();
        bytes[pos++] = Util.booleanToByte(intentionalMatching);
        pos = Util.writeLongToByteArray(responseReceivedTime, bytes, pos);
        pos = Util.writeStringToByteArray(parentTransactionId, bytes, pos);
        bytes[pos++] = Util.booleanToByte(piggyBackCancellation);
        bytes[pos++] = Util.booleanToByte(aggressiveLeadingLeg);
        pos = Util.writeStringToByteArray(referenceTransaction, bytes, pos);
        return pos;
    }

    public void updateOrder(ExchangeOrderResponse response) {
        setOrderStatus(response.getOrderStatus());
        setFillQuantity(response.getQuantityFilled());
        setFilledPrice(response.getPriceFilled());
    }

    public String getCompositeOrderId() {
        StringBuilder sb = new StringBuilder();
        sb.append(orderId).append(DELIMITER);
        sb.append(strategyId).append(DELIMITER);
        sb.append(groupId);
        return sb.toString();
    }

    public int getOrderId() {
        if (orderId < 0) {
            throw new RuntimeException("Order id requested before it is set");
        }
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public boolean hasOrderId() {
        return orderId >= 0;
    }

    public int getStrategyId() {
        return strategyId;
    }

    public void setStrategyId(int strategyId) {
        this.strategyId = strategyId;
    }

    public int getGroupId() {
        return groupId;
    }

    public void setGroupId(int groupId) {
        this.groupId = groupId;
    }

    public String getTransactionId() {
        StringBuilder tb = new StringBuilder();
        tb.append(strategyId).append(DELIMITER);
        tb.append(groupId);
        return tb.toString();
    }

    public Exchange getExchange() {
        return exchange;
    }

    public void setExchange(Exchange exchange) {
        this.exchange = exchange;
    }

    public OrderAction getAction() {
        return action;
    }

    public void setAction(OrderAction action) {
        this.action = action;
    }

    public TimeInForce getTimeInForce() {
        return timeInForce;
    }

    public void setTimeInForce(TimeInForce tif) {
        this.timeInForce = tif;
    }

    public boolean isIoc() {
        return timeInForce == TimeInForce.IOC;
    }

    public CurrencyPair getCurrencyPair() {
        return currencyPair;
    }

    public void setCurrencyPair(String currencyPair) {
        this.currencyPair = CurrencyPair.valueOf(currencyPair);
    }

    public void setCurrencyPair(CurrencyPair currencyPair) {
        this.currencyPair = currencyPair;
    }

    public float getTargetPrice() {
        return targetPrice;
    }

    public void setTargetPrice(float targetPrice) {
        this.targetPrice = targetPrice;
    }

    public float getMarketPrice() {
        return marketPrice;
    }

    public void setFilledPrice(float filledPrice) {
        this.filledPrice = filledPrice;
    }

    public float getFilledPrice() {
        return filledPrice;
    }

    public void setMarketPrice(float marketPrice) {
        this.marketPrice = marketPrice;
    }

    public float getOrderQuantity() {
        if (orderQuantity >= 0) {
            return orderQuantity;
        } else {
            System.err.println(toString());
            throw new RuntimeException("Unexpected state - Order quantity requested before it is set");
        }
    }

    public void setOrderQuantity(float orderQuantity) {
        this.orderQuantity = orderQuantity;
    }

    public float getFillQuantity() {
        if (fillQuantity < 0) {
            System.err.println(toString());
            throw new RuntimeException("Unexpected state - Fill quantity requested before it is set");
        } else {
            return fillQuantity;
        }
    }

    public void setFillQuantity(float fillQuantity) {
        if (fillQuantity < 0) {
            System.err.println(toString());
            throw new RuntimeException("Fill quantity cannot be less than 0.");
        }
        this.fillQuantity = fillQuantity;
    }

    public Side getSide() {
        return side;
    }

    public void setSide(Side side) {
        this.side = side;
    }

    public OrderStatus getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(OrderStatus orderStatus) {
        this.orderStatus = orderStatus;
    }

    public boolean isLimitOrder() {
        return orderType == OrderType.LIMIT;
    }

    public OrderType getOrderType() {
        return orderType;
    }

    public void setOrderType(OrderType orderType) {
        this.orderType = orderType;
    }

    public long getSentTime() {
        return sentTime;
    }

    public void setSentTime(long sentTime) {
        this.sentTime = sentTime;
    }

    public long getAcceptedTime() {
        return acceptedTime;
    }

    public void setAcceptedTime(long acceptedTime) {
        this.acceptedTime = acceptedTime;
    }

    public long getResponseReceivedTime() {
        return responseReceivedTime;
    }

    public void setResponseReceivedTime(long responseReceivedTime) {
        this.responseReceivedTime = responseReceivedTime;
    }

    public boolean isIntentionalMatching() {
        return intentionalMatching;
    }

    public void setIntentionalMatching(boolean intentionalMatching) {
        this.intentionalMatching = intentionalMatching;
    }

    public String getParentTransactionId() {
        return parentTransactionId;
    }

    void setParentTransactionId(String parentTransactionId) {
        this.parentTransactionId = parentTransactionId;
    }

    public int getParentStrategyId() {
        StringTokenizer tokenizer = new StringTokenizer(parentTransactionId, "|");
        if (tokenizer.hasMoreTokens()) {
            return Integer.parseInt(tokenizer.nextToken());
        }
        return -1;
    }

    public int getParentGroupId() {
        StringTokenizer tokenizer = new StringTokenizer(parentTransactionId, "|");

        if (tokenizer.hasMoreTokens()) {
            tokenizer.nextToken();
            if (tokenizer.hasMoreTokens()) {
                return Integer.parseInt(tokenizer.nextToken());
            }
        }
        return -1;
    }

    public boolean isPiggyBackCancellation() {
        return piggyBackCancellation;
    }

    public void setPiggyBackCancellation(boolean piggyBackCancellation) {
        this.piggyBackCancellation = piggyBackCancellation;
    }

    public String getReferenceTransaction() {
        return referenceTransaction;
    }

    public boolean isAggressiveLeadingLeg() {
        return aggressiveLeadingLeg;
    }

    public void setAggressiveLeadingLeg(boolean leadingLeg) {
        this.aggressiveLeadingLeg = leadingLeg;
    }

    public void setReferenceTransaction(String referenceTransaction) {
        this.referenceTransaction = referenceTransaction;
    }

    public Object clone() {
        try {
            return super.clone();
        } catch (CloneNotSupportedException e) {
            throw new RuntimeException("Unexpected state - unable to clone Order", e);
        }
    }

    public String toString() {
        StringBuilder tb = new StringBuilder();
        tb.append("[Order] ");
        appendToString(tb);
        return tb.toString();
    }
}
