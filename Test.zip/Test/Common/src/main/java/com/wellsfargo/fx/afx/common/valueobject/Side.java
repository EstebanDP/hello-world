package com.wellsfargo.fx.afx.common.valueobject;

public enum Side {
    BUY, SELL;

    public static Side valueOf(byte ordinal) {
        if (ordinal == BUY.ordinal()) {
            return BUY;
        } else if (ordinal == SELL.ordinal()) {
            return SELL;
        }
        return null;
    }

    public Side getOtherSide() {
        if (this == Side.BUY) {
            return SELL;
        } else if (this == Side.SELL) {
            return BUY;
        }
        return null;
    }

}
