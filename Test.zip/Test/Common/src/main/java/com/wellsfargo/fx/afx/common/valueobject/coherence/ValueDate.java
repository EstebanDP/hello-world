package com.wellsfargo.fx.afx.common.valueobject.coherence;

import java.io.Serializable;

import com.wellsfargo.fx.afx.common.valueobject.CurrencyPair;

@SuppressWarnings("serial")
public class ValueDate implements Serializable {
	
	private CurrencyPair currencyPair;
	private String tradeDate;
	private String valueDate;
	
	
	public CurrencyPair getCurrencyPair() {
		return currencyPair;
	}
	
	public void setCurrencyPair(CurrencyPair currencyPair) {
		this.currencyPair = currencyPair;
	}
	
	public String getTradeDate() {
		return tradeDate;
	}
	
	public void setTradeDate(String tradeDate) {
		this.tradeDate = tradeDate;
	}
	
	public String getValueDate() {
		return valueDate;
	}
	
	public void setValueDate(String valueDate) {
		this.valueDate = valueDate;
	}
}
