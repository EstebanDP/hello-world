package com.wellsfargo.fx.afx.common.persistence.model;

import java.math.BigDecimal;
import java.sql.Date;

public class FxSpotRange {
	private int spotRangeId;
	private String type;
	private BigDecimal maxAmount;
	private String updateUser;
	private Date updateTime;
	
	public void setSpotRangeId(int spotRangeId) {
		this.spotRangeId = spotRangeId;
	}
	
	public int getSpotRangeId() {
		return spotRangeId;
	}
	
	public void setType(String type) {
		this.type = type;
	}
	
	public String getType() {
		return type;
	}
	
	public void setMaxAmount(BigDecimal maxAmount) {
		this.maxAmount = maxAmount;
	}
	
	public BigDecimal getMaxAmount() {
		return maxAmount;
	}

	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}

	public String getUpdateUser() {
		return updateUser;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}
}