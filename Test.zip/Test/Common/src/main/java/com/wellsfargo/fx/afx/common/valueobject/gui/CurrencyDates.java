package com.wellsfargo.fx.afx.common.valueobject.gui;

import com.wellsfargo.fx.afx.common.util.Util;
import com.wellsfargo.fx.afx.common.valueobject.CurrencyPair;
import com.wellsfargo.fx.afx.common.valueobject.MessageType;
import com.wellsfargo.fx.afx.common.valueobject.ValueObject;

public class CurrencyDates extends ValueObject {
    private static final byte version = 1;
    private CurrencyPair currencyPair;
    private String tradeDate = "";
    private String valueDate = "";

    public CurrencyPair getCurrencyPair() {
        return currencyPair;
    }

    public void setCurrencyPair(CurrencyPair currencyPair) {
        this.currencyPair = currencyPair;
    }

    public String getTradeDate() {
        return tradeDate;
    }

    public void setTradeDate(String tradeDate) {
        this.tradeDate = tradeDate;
    }

    public String getValueDate() {
        return valueDate;
    }

    public void setValueDate(String valueDate) {
        this.valueDate = valueDate;
    }

    @Override
    public int readFrom(byte[] bytes) {
        int pos = 2; // skip type and version
        currencyPair = CurrencyPair.valueOf(bytes[pos++]);
        int length = bytes[pos++];
        tradeDate = Util.readStringFromBytes(bytes, length, pos);
        pos += length;
        length = bytes[pos++];
        valueDate = Util.readStringFromBytes(bytes, length, pos);
        pos += length;
        return pos;
    }

    @Override
    public byte[] toBytes() {
        int pos = 0;
        byte[] bytes = new byte[1 + 1 + 1 + 1 + tradeDate.length() + 1 + valueDate.length()];
        bytes[pos++] = MessageType.CURRENCY_DATES;
        bytes[pos++] = version;
        bytes[pos++] = (byte) currencyPair.ordinal();
        pos = Util.writeStringToByteArray(tradeDate, bytes, pos);
        pos = Util.writeStringToByteArray(valueDate, bytes, pos);
        return bytes;
    }

    public synchronized String toString() {
        StringBuilder tb = new StringBuilder();
        tb.append("Value Dates: ");
        tb.append(currencyPair.toString()).append('\t');
        tb.append(valueDate).append('\t');
        tb.append(tradeDate);
        return tb.toString();
    }
}
