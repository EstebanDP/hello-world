package com.wellsfargo.fx.afx.common.valueobject;

import com.wellsfargo.fx.afx.common.util.Util;

public class ShutdownCmd extends ValueObject {

    private static final byte version = 1;
    private ComponentName componentRequestFrom;
    private ComponentName componentRequestTo;
    private String reason;

    public ShutdownCmd() {
    }

    public ShutdownCmd(ComponentName componentNameRequestFrom, ComponentName componentNameRequestTo) {
        this.componentRequestFrom = componentNameRequestFrom;
        this.componentRequestTo = componentNameRequestTo;
    }

    @Override
    public int readFrom(byte[] bytes) {
        int pos = 2; // skip type and version
        componentRequestFrom = ComponentName.valueOf(bytes[pos++]);
        componentRequestTo = ComponentName.valueOf(bytes[pos++]);

        int strLength = bytes[pos++];
        reason = Util.readStringFromBytes(bytes, strLength, pos);
        pos += strLength;

        return pos;
    }

    @Override
    public byte[] toBytes() {
        int length = 1 + 1 + 1 + 1 + 1 + reason.length();
        byte[] bytes = new byte[length];

        int pos = 0;
        bytes[pos++] = MessageType.SHUTDOWN_CMD;
        bytes[pos++] = version;
        bytes[pos++] = (byte) componentRequestFrom.ordinal();
        bytes[pos++] = (byte) componentRequestTo.ordinal();
        pos = Util.writeStringToByteArray(reason, bytes, pos);

        return bytes;
    }

    public void setComponentRequestFrom(ComponentName componentRequestFrom) {
        this.componentRequestFrom = componentRequestFrom;
    }

    public ComponentName getcomponentRequestFrom() {
        return this.componentRequestFrom;
    }

    public void setComponentRequestTo(ComponentName componentRequestTo) {
        this.componentRequestTo = componentRequestTo;
    }

    public ComponentName getcomponentRequestTo() {
        return this.componentRequestTo;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getReason() {
        return this.reason;
    }

    public String toString() {
        String str = "\n********* Shutdown Cmd *********";
        str += "\nRequest From: " + componentRequestFrom.toString();
        str += "\nRequest To: " + componentRequestTo.toString();

        if (reason != null && reason.length() > 0) {
            str += "\nReason: " + reason;
        }

        return str;
    }
}
