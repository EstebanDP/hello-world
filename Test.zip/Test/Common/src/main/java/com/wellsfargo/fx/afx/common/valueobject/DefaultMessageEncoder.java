package com.wellsfargo.fx.afx.common.valueobject;

import com.wellsfargo.fx.afx.common.messaging.MessageEncoder;

public class DefaultMessageEncoder implements MessageEncoder {

	@Override
	public byte[] encode(Object message) {
		ValueObject vo = (ValueObject) message;
		return vo.toBytes();
	}

}
