package com.wellsfargo.fx.afx.common.util;

public interface LoggerConstants {

	public static final String COMMON = "Common";
    public static final String MARKET_DATA_GATEWAY = "MarketDataGateway";

    public static final String CLIENT_PROXY = "ClientProxy";
    public static final String QUICKFIXj = "QuickFixJ";

    public static final String LOGGER_MSG_PLACE_HOLDER = "%";
}
