package com.wellsfargo.fx.afx.common.valueobject.orderdata;

import java.util.ArrayList;
import java.util.List;

import com.wellsfargo.fx.afx.common.util.Util;
import com.wellsfargo.fx.afx.common.valueobject.Exchange;
import com.wellsfargo.fx.afx.common.valueobject.ExecutionType;
import com.wellsfargo.fx.afx.common.valueobject.MessageType;
import com.wellsfargo.fx.afx.common.valueobject.OrderStatus;
import com.wellsfargo.fx.afx.common.valueobject.ValueObject;

public class ExchangeRequest extends ValueObject {
    // private static Logger log = LoggerFactory.getLogger("");
    private static final byte version = 1;
    private Exchange exchange;
    private int strategyId;
    private int groupId;
    private ExecutionType type;
    private long tickReceivedTime;
    private String snapshotTime;
    private boolean checkTimeDelay;
    private boolean checkTimeDelay2;
    private List<Order> orders = new ArrayList<Order>();

    public ExchangeRequest() {

    }

    public void setExchange(Exchange exchange) {
        this.exchange = exchange;
    }

    public Exchange getExchange() {
        return exchange;
    }

    public int getStrategyId() {
        return strategyId;
    }

    public void setStrategyId(int strategyId) {
        this.strategyId = strategyId;
    }

    public int getGroupId() {
        return groupId;
    }

    public void setGroupId(int groupId) {
        this.groupId = groupId;
    }

    public String getTransactionId() {
        return strategyId + "|" + groupId;
    }

    public boolean isLocal() {
        return !type.isArb();
    }

    public void setType(ExecutionType type) {
        this.type = type;
    }

    public ExecutionType getType() {
        return type;
    }

    public long getTickReceivedTime() {
        return tickReceivedTime;
    }

    public void setTickReceivedTime(long tickReceivedTime) {
        this.tickReceivedTime = tickReceivedTime;
    }

    public String getSnapshotTime() {
        return snapshotTime;
    }

    public void setSnapshotTime(String snapshotTime) {
        this.snapshotTime = snapshotTime;
    }

    public synchronized boolean isPending() {
        for (Order order : orders) {
            if (order.getOrderStatus() == OrderStatus.NONE) {
                return true;
            }
        }
        return false;
    }

    @Override
    public synchronized byte[] toBytes() {
        int length = 1 + 1 + 1 + 4 + 4 + 1 + 8 + snapshotTime.length() + 1 + 1 + 1 + 1;
        for (Order order : orders) {
            length += order.getByteLength();
        }

        byte[] bytes = new byte[length];
        int pos = 0;
        bytes[pos++] = MessageType.EXCHANGE_ORDER_REQUEST;
        bytes[pos++] = version;
        bytes[pos++] = (byte) exchange.ordinal();
        pos = Util.writeIntToByteArray(strategyId, bytes, pos);
        pos = Util.writeIntToByteArray(groupId, bytes, pos);
        bytes[pos++] = (byte) type.ordinal();
        pos = Util.writeLongToByteArray(tickReceivedTime, bytes, pos);
        pos = Util.writeStringToByteArray(snapshotTime, bytes, pos);
        bytes[pos++] = Util.booleanToByte(checkTimeDelay);
        bytes[pos++] = Util.booleanToByte(checkTimeDelay2);
        bytes[pos++] = (byte) orders.size();
        for (Order order : orders) {
            pos = order.writeBytes(bytes, pos);
        }
        // log.debug(toString());
        return bytes;
    }

    @Override
    public synchronized int readFrom(byte[] bytes) {
        int pos = 2; // skip type and version
        exchange = Exchange.valueOf(bytes[pos++]);
        strategyId = Util.readIntFromBytes(bytes, pos);
        pos += 4;
        groupId = Util.readIntFromBytes(bytes, pos);
        pos += 4;
        type = ExecutionType.valueOf(bytes[pos++]);
        tickReceivedTime = Util.readLongFromBytes(bytes, pos);
        pos += 8;
        int length = bytes[pos++];
        snapshotTime = Util.readStringFromBytes(bytes, length, pos);
        pos += length;
        checkTimeDelay = Util.byteToBoolean(bytes[pos++]);
        checkTimeDelay2 = Util.byteToBoolean(bytes[pos++]);

        length = bytes[pos++];
        for (int i = 0; i < length; i++) {
            Order order = new Order(strategyId, groupId);
            pos = order.readFrom(bytes, pos);
            orders.add(order);
        }
        // log.debug(toString());
        return pos;
    }

    public synchronized String toString() {
        StringBuilder tb = new StringBuilder();
        tb.append(System.currentTimeMillis()).append(": ");
        tb.append("Exchange Request: ");
        tb.append(exchange).append('\t');
        tb.append(strategyId).append('\t');
        tb.append(groupId).append('\t');
        tb.append(type).append('\t');
        tb.append(checkTimeDelay).append('\t');
        tb.append(checkTimeDelay2).append('\t');
        tb.append(tickReceivedTime).append('\n');
        for (Order order : orders) {
            order.appendToString(tb);
            tb.append('\n');
        }
        return tb.toString();
    }

    public synchronized Order getOrders(int i) {
        return orders.get(i);
    }

    public List<Order> getOrderList() {
        return orders;
    }

    public synchronized void addOrder(Order order) {
        orders.add(order);
    }

    public synchronized Order getOrder(int orderId) {
        for (Order order : orders) {
            if (order.getOrderId() == orderId) {
                return order;
            }
        }
        return null;
    }

    public synchronized Integer getOrderCount() {
        return orders.size();
    }

    public boolean checkTimeDelay() {
        return checkTimeDelay;
    }

    public void setCheckTimeDelay(boolean checkTimeDelay) {
        this.checkTimeDelay = checkTimeDelay;
    }

    public boolean checkTimeDelay2() {
        return checkTimeDelay2;
    }

    public void setCheckTimeDelay2(boolean checkTimeDelay2) {
        this.checkTimeDelay2 = checkTimeDelay2;
    }

}
