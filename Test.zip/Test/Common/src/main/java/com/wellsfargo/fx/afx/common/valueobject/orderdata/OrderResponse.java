package com.wellsfargo.fx.afx.common.valueobject.orderdata;

import com.wellsfargo.fx.afx.common.util.Util;
import com.wellsfargo.fx.afx.common.valueobject.CurrencyPair;
import com.wellsfargo.fx.afx.common.valueobject.MessageType;
import com.wellsfargo.fx.afx.common.valueobject.ValueObject;

public class OrderResponse extends ValueObject {
    // private static Logger log = LoggerFactory.getLogger("");
    private static final String DELIMITER = "|";
    private static final byte version = 1;
    private int orderId;
    private int strategyId;
    private int groupId;
    private CurrencyPair currencyPair;

    @Override
    public byte[] toBytes() {
        int length = 1 + 1 + 4 + 4 + 4 + 1;
        byte[] bytes = new byte[length];

        int pos = 0;
        bytes[pos++] = MessageType.ORDER_RESPONSE;
        bytes[pos++] = version;
        pos = Util.writeIntToByteArray(orderId, bytes, pos);
        pos = Util.writeIntToByteArray(strategyId, bytes, pos);
        pos = Util.writeIntToByteArray(groupId, bytes, pos);
        bytes[pos++] = (byte) currencyPair.ordinal();
        // log.debug(toString());
        return bytes;
    }

    @Override
    public int readFrom(byte[] bytes) {
        int pos = 2; // skip type and version
        orderId = Util.readIntFromBytes(bytes, pos);
        pos += 4;
        strategyId = Util.readIntFromBytes(bytes, pos);
        pos += 4;
        groupId = Util.readIntFromBytes(bytes, pos);
        pos += 4;
        currencyPair = CurrencyPair.valueOf(bytes[pos++]);
        // log.debug(toString());
        return pos;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(System.currentTimeMillis()).append(": ");
        sb.append("Order Response: ").append("\t");
        sb.append(orderId).append("\t");
        sb.append(strategyId).append("\t");
        sb.append(groupId).append("\t");
        sb.append(currencyPair).append("\t");
        return sb.toString();
    }

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public int getStrategyId() {
        return strategyId;
    }

    public void setStrategyId(int strategyId) {
        this.strategyId = strategyId;
    }

    public int getGroupId() {
        return groupId;
    }

    public void setGroupId(int groupId) {
        this.groupId = groupId;
    }

    public CurrencyPair getCurrencyPair() {
        return currencyPair;
    }

    public void setCurrencyPair(CurrencyPair currencyPair) {
        this.currencyPair = currencyPair;
    }

    public String getTransactionId() {
        return strategyId + DELIMITER + groupId;
    }

}
