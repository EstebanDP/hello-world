package com.wellsfargo.fx.afx.common.persistence.model;

import java.util.Date;

public class Currency {
	private int ordinal;
	private String currency;
	private boolean baseCcyForUsd;
	private String updateUser;
	private Date updateDate;

	public void setOrdinal(int ordinal) {
		this.ordinal = ordinal;
	}

	public int getOrdinal() {
		return ordinal;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getCurrency() {
		return currency;
	}

	public void setBaseCcyForUsd(boolean baseCcyForUsd) {
		this.baseCcyForUsd = baseCcyForUsd;
	}

	public boolean isBaseCcyForUsd() {
		return baseCcyForUsd;
	}

	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}

	public String getUpdateUser() {
		return updateUser;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	public Date getUpdateDate() {
		return updateDate;
	}
}
