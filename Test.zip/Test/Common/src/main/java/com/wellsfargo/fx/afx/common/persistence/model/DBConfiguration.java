package com.wellsfargo.fx.afx.common.persistence.model;

import java.util.Date;

public class DBConfiguration {
	private String dbName;
	private String url;
	private String driver;
	private String userName;
	private String password;
	private String updateUser;
	private Date updateDate;
	
	public void setDbName(String dbName) {
		this.dbName = dbName;
	}
	
	public String getDbName() {
		return dbName;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getUrl() {
		return url;
	}

	public void setDriver(String driver) {
		this.driver = driver;
	}

	public String getDriver() {
		return driver;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserName() {
		return userName;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPassword() {
		return password;
	}

	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}

	public String getUpdateUser() {
		return updateUser;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	public Date getUpdateDate() {
		return updateDate;
	}
}
