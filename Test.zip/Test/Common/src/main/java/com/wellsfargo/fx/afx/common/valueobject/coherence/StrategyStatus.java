package com.wellsfargo.fx.afx.common.valueobject.coherence;

import java.io.Serializable;

@SuppressWarnings("serial")
public class StrategyStatus implements Serializable {

    private int strategyId;
    private boolean paused;
    private boolean stopped;
    private String reasonForPause;

    public int getStrategyId() {
        return strategyId;
    }

    public void setStrategyId(int strategyId) {
        this.strategyId = strategyId;
    }

    public boolean isPaused() {
        return paused;
    }

    public void setPaused(boolean paused) {
        this.paused = paused;
    }

    public boolean isStopped() {
        return stopped;
    }

    public void setStopped(boolean stopped) {
        this.stopped = stopped;
    }

    public String getReasonForPause() {
        return reasonForPause;
    }

    public void setReasonForPause(String reasonForPause) {
        this.reasonForPause = reasonForPause;
    }

}
