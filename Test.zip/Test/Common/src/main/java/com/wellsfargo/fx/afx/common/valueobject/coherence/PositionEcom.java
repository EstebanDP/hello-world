package com.wellsfargo.fx.afx.common.valueobject.coherence;

import java.io.Serializable;
import java.math.BigDecimal;

@SuppressWarnings("serial")
public class PositionEcom implements Serializable {
	
	private String currency;
    private int scale = 6;
    private BigDecimal position;
    private BigDecimal usdEquivalentPosition;
    private float pnl;
    
	public String getCurrency() {
		return currency;
	}
	
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	
	public int getScale() {
		return scale;
	}
	
	public void setScale(int scale) {
		this.scale = scale;
	}
	
	public BigDecimal getPosition() {
		return position;
	}
	
	public void setPosition(BigDecimal position) {
		this.position = position;
	}
	
	public BigDecimal getUsdEquivalentPosition() {
		return usdEquivalentPosition;
	}
	
	public void setUsdEquivalentPosition(BigDecimal usdEquivalentPosition) {
		this.usdEquivalentPosition = usdEquivalentPosition;
	}

	public void setPnl(float pnl) {
		this.pnl = pnl;
	}

	public float getPnl() {
		return pnl;
	}
	
	public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(currency).append(":\t");
        sb.append(position).append('\t');
        sb.append(usdEquivalentPosition).append('\t');
        sb.append(pnl).append('\t');

        return sb.toString();
    }
}
