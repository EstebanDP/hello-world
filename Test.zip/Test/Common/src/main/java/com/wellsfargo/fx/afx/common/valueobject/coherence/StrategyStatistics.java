package com.wellsfargo.fx.afx.common.valueobject.coherence;

import java.io.Serializable;
import java.util.Map;

import javolution.util.FastMap;

@SuppressWarnings("serial")
public final class StrategyStatistics implements Serializable {

    private Map<Integer, OrderRatios> orderFillRatios = new FastMap<Integer, OrderRatios>();
    private Map<Integer, FillRatio> transactionFillRatios = new FastMap<Integer, FillRatio>();

    public void incrementOrderFilled(int strategyId, int count) {
        OrderRatios or = getOrderRatios(strategyId);
        or.incrementFilled(count);
    }

    public void incrementOrderTotal(int strategyId, int count) {
        OrderRatios or = getOrderRatios(strategyId);
        or.incrementTotal(count);
    }

    public void incrementOrderCancelled(int strategyId, int count) {
        OrderRatios or = getOrderRatios(strategyId);
        or.incrementCancelled(count);
    }

    public void incrementOrderRejectedByExchange(int strategyId, int count) {
        OrderRatios or = getOrderRatios(strategyId);
        or.incrementRejectedByExchange(count);
    }

    public void incrementOrderRejectedByThroughput(int strategyId, int count) {
        OrderRatios or = getOrderRatios(strategyId);
        or.incrementRejectedByThroughput(count);
    }

    public void incrementOrderRejectedByLatency(int strategyId, int count) {
        OrderRatios or = getOrderRatios(strategyId);
        or.incrementRejectedByLatency(count);
    }

    public void incrementOrderRejectedByValidation(int strategyId, int count) {
        OrderRatios or = getOrderRatios(strategyId);
        or.incrementRejectedByValidation(count);
    }

    public void incrementTransactionTotal(int strategyId, int count) {
        FillRatio fr = getTransactionRatios(strategyId);
        fr.incrementDenominatorCount(count);
    }

    public void incrementTransactionFilled(int strategyId, int count) {
        FillRatio fr = getTransactionRatios(strategyId);
        fr.incrementNumeratorCount(count);
    }

    public Map<Integer, OrderRatios> getOrderFillRatios() {
        return orderFillRatios;
    }

    public Map<Integer, FillRatio> getTransactionFillRatios() {
        return transactionFillRatios;
    }

    private OrderRatios getOrderRatios(int strategyId) {
        OrderRatios or = orderFillRatios.get(strategyId);
        if (or == null) {
            or = new OrderRatios();
            orderFillRatios.put(strategyId, or);
        }
        return or;
    }

    private FillRatio getTransactionRatios(int strategyId) {
        FillRatio fr = transactionFillRatios.get(strategyId);
        if (fr == null) {
            fr = new FillRatio();
            transactionFillRatios.put(strategyId, fr);
        }
        return fr;
    }

}
