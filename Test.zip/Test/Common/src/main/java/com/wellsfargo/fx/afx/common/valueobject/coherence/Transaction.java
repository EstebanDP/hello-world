package com.wellsfargo.fx.afx.common.valueobject.coherence;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.wellsfargo.fx.afx.common.util.CommonConstants;
import com.wellsfargo.fx.afx.common.valueobject.Exchange;
import com.wellsfargo.fx.afx.common.valueobject.ExecutionType;
import com.wellsfargo.fx.afx.common.valueobject.OrderAction;
import com.wellsfargo.fx.afx.common.valueobject.OrderStatus;
import com.wellsfargo.fx.afx.common.valueobject.OrderType;
import com.wellsfargo.fx.afx.common.valueobject.Side;
import com.wellsfargo.fx.afx.common.valueobject.TimeInForce;
import com.wellsfargo.fx.afx.common.valueobject.TransactionAction;

@SuppressWarnings("serial")
public class Transaction implements Serializable {

    private int guiRowId;
    private int strategyId;
    private int groupId;
    private String snapshotTime;
    private ExecutionType executionType;
    private float expectedPnL = CommonConstants.CONST_NA;
    private float actualPnL = CommonConstants.CONST_NA;
    private float initialArbPoints = CommonConstants.CONST_NA;
    private float expectedArbPoints = CommonConstants.CONST_NA;
    private float actualArbPoints = CommonConstants.CONST_NA;
    private boolean completed = false;
    private boolean showInGui = false;
    private List<Order> orders = new ArrayList<Order>();
    TransactionAction action;

    public int getGuiRowId() {
        return guiRowId;
    }

    public void setGuiRowId(int guiRowId) {
        this.guiRowId = guiRowId;
    }

    public int getStrategyId() {
        return strategyId;
    }

    public void setStrategyId(int strategyId) {
        this.strategyId = strategyId;
    }

    public int getGroupId() {
        return groupId;
    }

    public void setGroupId(int groupId) {
        this.groupId = groupId;
    }

    public String getSnapshotTime() {
        return snapshotTime;
    }

    public void setSnapshotTime(String snapshotTime) {
        this.snapshotTime = snapshotTime;
    }

    public ExecutionType getExecutionType() {
        return executionType;
    }

    public void setExecutionType(ExecutionType executionType) {
        this.executionType = executionType;
    }

    public float getExpectedPnL() {
        return expectedPnL;
    }

    public void setExpectedPnL(float expectedPnL) {
        this.expectedPnL = expectedPnL;
    }

    public float getActualPnL() {
        return actualPnL;
    }

    public void setActualPnL(float actualPnL) {
        this.actualPnL = actualPnL;
    }

    public float getInitialArbPoints() {
        return initialArbPoints;
    }

    public void setInitialArbPoints(float initialArbPoints) {
        this.initialArbPoints = initialArbPoints;
    }

    public float getExpectedArbPoints() {
        return expectedArbPoints;
    }

    public void setExpectedArbPoints(float expectedArbPoints) {
        this.expectedArbPoints = expectedArbPoints;
    }

    public float getActualArbPoints() {
        return actualArbPoints;
    }

    public void setActualArbPoints(float actualArbPoints) {
        this.actualArbPoints = actualArbPoints;
    }

    public boolean isCompleted() {
        return completed;
    }

    public void setCompleted(boolean completed) {
        this.completed = completed;
    }

    public List<Order> getOrders() {
        return orders;
    }

    public void setOrders(List<Order> orders) {
        this.orders = orders;
    }

    public void addOrder(Order order) {
        this.orders.add(order);
    }

    public TransactionAction getAction() {
        return (action == null) ? TransactionAction.SUBMIT_ORDERS : action;
    }

    public void setAction(TransactionAction action) {
        this.action = action;
    }

    public boolean showInGui() {
        return showInGui;
    }

    public void setShowInGui(boolean showInGui) {
        this.showInGui = showInGui;
    }

    public synchronized boolean isPending() {
        for (Order order : orders) {
            if (order.getOrderStatus() == OrderStatus.NONE) {
                return true;
            }
        }
        return false;
    }

    public class Order implements Serializable {
        private int strategyId;
        private int groupId;
        private Exchange exchange;
        private int orderId = -1;
        private OrderAction action = OrderAction.NONE;
        private TimeInForce timeInForce;
        private String currencyPair;
        private float targetPrice = -Float.MIN_VALUE;
        private float marketPrice = -Float.MIN_VALUE;
        private float filledPrice = -Float.MIN_VALUE;
        private float orderQuantity;
        private float fillQuantity;
        private OrderStatus orderStatus = OrderStatus.NONE;
        private OrderType orderType;
        private Side side;
        private boolean intentionalMatching = false;
        private String referenceTransaction = "";

        public int getStrategyId() {
            return strategyId;
        }

        public void setStrategyId(int strategyId) {
            this.strategyId = strategyId;
        }

        public int getGroupId() {
            return groupId;
        }

        public void setGroupId(int groupId) {
            this.groupId = groupId;
        }

        public Exchange getExchange() {
            return (exchange == null) ? Exchange.EBS : exchange;
        }

        public void setExchange(Exchange exchange) {
            this.exchange = exchange;
        }

        public int getOrderId() {
            return orderId;
        }

        public void setOrderId(int orderId) {
            this.orderId = orderId;
        }

        public OrderAction getAction() {
            return action;
        }

        public void setAction(OrderAction action) {
            this.action = action;
        }

        public TimeInForce getTimeInForce() {
            return (timeInForce == null) ? TimeInForce.IOC : timeInForce;
        }

        public void setTimeInForce(TimeInForce timeInForce) {
            this.timeInForce = timeInForce;
        }

        public String getCurrencyPair() {
            return currencyPair;
        }

        public void setCurrencyPair(String currencyPair) {
            this.currencyPair = currencyPair;
        }

        public float getTargetPrice() {
            return targetPrice;
        }

        public void setTargetPrice(float targetPrice) {
            this.targetPrice = targetPrice;
        }

        public float getMarketPrice() {
            return marketPrice;
        }

        public void setMarketPrice(float marketPrice) {
            this.marketPrice = marketPrice;
        }

        public float getFilledPrice() {
            return filledPrice;
        }

        public void setFilledPrice(float filledPrice) {
            this.filledPrice = filledPrice;
        }

        public float getOrderQuantity() {
            return orderQuantity;
        }

        public void setOrderQuantity(float orderQuantity) {
            this.orderQuantity = orderQuantity;
        }

        public float getFillQuantity() {
            return fillQuantity;
        }

        public void setFillQuantity(float fillQuantity) {
            this.fillQuantity = fillQuantity;
        }

        public OrderStatus getOrderStatus() {
            return orderStatus;
        }

        public void setOrderStatus(OrderStatus orderStatus) {
            this.orderStatus = orderStatus;
        }

        public OrderType getOrderType() {
            return (orderType == null) ? OrderType.LIMIT : orderType;
        }

        public void setOrderType(OrderType orderType) {
            this.orderType = orderType;
        }

        public Side getSide() {
            return side;
        }

        public void setSide(Side side) {
            this.side = side;
        }

        public boolean isIntentionalMatching() {
            return intentionalMatching;
        }

        public void setIntentionalMatching(boolean intentionalMatching) {
            this.intentionalMatching = intentionalMatching;
        }

        public String getReferenceTransaction() {
            return referenceTransaction;
        }

        public void setReferenceTransaction(String referenceTransaction) {
            this.referenceTransaction = referenceTransaction;
        }

    }

}
