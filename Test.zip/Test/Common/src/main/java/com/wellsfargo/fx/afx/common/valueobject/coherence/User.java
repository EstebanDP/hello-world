package com.wellsfargo.fx.afx.common.valueobject.coherence;

import java.io.Serializable;

@SuppressWarnings("serial")
public class User implements Serializable {
	
	private String userName;
	private String password;
	private UserRole userRole;
	

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public UserRole getUserRole() {
		return userRole;
	}

	public void setUserRole(UserRole userRole) {
		this.userRole = userRole;
	}
	

	public static enum UserRole {
		WRITE, READ_ONLY;
	}
	
}
