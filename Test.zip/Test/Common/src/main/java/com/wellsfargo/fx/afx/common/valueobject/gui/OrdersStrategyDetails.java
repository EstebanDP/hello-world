package com.wellsfargo.fx.afx.common.valueobject.gui;

import com.wellsfargo.fx.afx.common.util.Util;
import com.wellsfargo.fx.afx.common.valueobject.MessageType;
import com.wellsfargo.fx.afx.common.valueobject.ValueObject;

public class OrdersStrategyDetails extends ValueObject {

    private static final byte version = 1;
    private int strategyId;
    private int orderCount;
    private int dealCount;
    private int transactions;
    private int filledTransactions;

    public int getStrategyId() {
        return strategyId;
    }

    public void setStrategyId(int strategyID) {
        this.strategyId = strategyID;
    }

    public int getOrderCount() {
        return orderCount;
    }

    public void setOrderCount(int orderCount) {
        this.orderCount = orderCount;
    }

    public int getDealCount() {
        return dealCount;
    }

    public void setDealCount(int dealCount) {
        this.dealCount = dealCount;
    }

    public int getTransactions() {
        return transactions;
    }

    public void setTransactions(int transactions) {
        this.transactions = transactions;
    }

    public int getFilledTransactions() {
        return filledTransactions;
    }

    public void setFilledTransactions(int filledTransactions) {
        this.filledTransactions = filledTransactions;
    }

    @Override
    public int readFrom(byte[] bytes) {
        int pos = 2; // skip type and version
        strategyId = Util.readIntFromBytes(bytes, pos);
        pos += 4;
        orderCount = Util.readIntFromBytes(bytes, pos);
        pos += 4;
        dealCount = Util.readIntFromBytes(bytes, pos);
        pos += 4;
        transactions = Util.readIntFromBytes(bytes, pos);
        pos += 4;
        filledTransactions = Util.readIntFromBytes(bytes, pos);
        pos += 4;
        return pos;
    }

    public int getByteLength() {
    	return 1 + 1 + 4 + 4 + 4 + 4 + 4;
    }

    @Override
    public byte[] toBytes() {
        int byteLength = getByteLength();
        byte[] bytes = new byte[byteLength];
        int pos = 0;
        bytes[pos++] = MessageType.DEALS_PER_STRATEGY_DETAILS;
        bytes[pos++] = version;
        pos = Util.writeIntToByteArray(strategyId, bytes, pos);
        pos = Util.writeIntToByteArray(orderCount, bytes, pos);
        pos = Util.writeIntToByteArray(dealCount, bytes, pos);
        pos = Util.writeIntToByteArray(transactions, bytes, pos);
        pos = Util.writeIntToByteArray(filledTransactions, bytes, pos);
        return bytes;
    }
}
