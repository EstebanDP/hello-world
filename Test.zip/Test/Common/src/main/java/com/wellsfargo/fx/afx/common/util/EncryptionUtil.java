package com.wellsfargo.fx.afx.common.util;

import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;

public class EncryptionUtil {
	
	private static EncryptionUtil self;
	private StandardPBEStringEncryptor encryptor;
	
	static {
		self = new EncryptionUtil();
	}
	
	
	private EncryptionUtil() {
		encryptor = new StandardPBEStringEncryptor();
		encryptor.setPassword("afxecom");
		encryptor.setAlgorithm("PBEWithMD5AndDES");
	}
	
	public static EncryptionUtil getInstance() {
		return self;
	}
	
	public String encrypt(String plainInput) {
		return encryptor.encrypt(plainInput);
	}
	
	public String decrypt(String encryptedInput) {
		return encryptor.decrypt(encryptedInput);
	}

}
