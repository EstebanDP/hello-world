package com.wellsfargo.fx.afx.common.valueobject.gui;

import com.wellsfargo.fx.afx.common.util.Util;
import com.wellsfargo.fx.afx.common.valueobject.MessageType;
import com.wellsfargo.fx.afx.common.valueobject.ValueObject;

public class OrdersCurrencyPairDetails extends ValueObject {

    private static final byte version = 1;
    private String currencyPair;
    private int strategyID;
    private int orderCount;
    private int dealCount = 0;

    public String getCurrencyPair() {
        return currencyPair;
    }

    public void setCurrencyPair(String currencyPair) {
        this.currencyPair = currencyPair;
    }

    public int getStrategyId() {
        return strategyID;
    }

    public void setStrategyID(int strategyID) {
        this.strategyID = strategyID;
    }

    public int getOrderCount() {
        return orderCount;
    }

    public void setOrderCount(int orderCount) {
        this.orderCount = orderCount;
    }

    public int getDealCount() {
        return dealCount;
    }

    public void setDealCount(int dealCount) {
        this.dealCount = dealCount;
    }

    @Override
    public int readFrom(byte[] bytes) {
        int pos = 2; // skip type and version
        strategyID = Util.readIntFromBytes(bytes, pos);
        pos += 4;
        orderCount = Util.readIntFromBytes(bytes, pos);
        pos += 4;
        dealCount = Util.readIntFromBytes(bytes, pos);
        pos += 4;
        int length = bytes[pos++];
        currencyPair = Util.readStringFromBytes(bytes, length, pos);
        pos += length;
        return pos;
    }

    public int getByteLength() {
    	return 1 + 1 + 4 + 4 + 4 + currencyPair.length() + 1;
    }

    @Override
    public byte[] toBytes() {
        int byteLength = getByteLength();
        byte[] bytes = new byte[byteLength];
        int pos = 0;
        bytes[pos++] = MessageType.DEALS_PER_CCY_PAIR_DETAILS;
        bytes[pos++] = version;
        pos = Util.writeIntToByteArray(strategyID, bytes, pos);
        pos = Util.writeIntToByteArray(orderCount, bytes, pos);
        pos = Util.writeIntToByteArray(dealCount, bytes, pos);
        Util.writeStringToByteArray(currencyPair, bytes, pos);
        return bytes;
    }
}
