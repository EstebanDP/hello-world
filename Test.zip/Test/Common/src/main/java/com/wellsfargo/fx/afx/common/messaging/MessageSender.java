package com.wellsfargo.fx.afx.common.messaging;

public interface MessageSender {
	public void send(byte[] bytes);

	public String getTopicName();
}
