package com.wellsfargo.fx.afx.common.valueobject;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.wellsfargo.fx.afx.common.persistence.dao.CurrencyDAO;
import com.wellsfargo.fx.afx.common.util.CommonConstants;

public class Currency {
    private static final Map<String, Currency> nameCurrencyMap = new HashMap<String, Currency>();
    private static final Map<Integer, Currency> ordinalToCurrencyMap = new HashMap<Integer, Currency>();
    private static final List<String> baseCurrenciesForUsd = new ArrayList<String>();

    static {
        loadCurrencies();
    }

    public static final Currency USD = nameCurrencyMap.get("USD");

    private static void loadCurrencies() {      
        try {
        	if (!CommonConstants.VALUE_COMPONENT_NAME.equals(ComponentName.GUI)) {
               	ArrayList<com.wellsfargo.fx.afx.common.persistence.model.Currency> currencyList = new CurrencyDAO().getAllCurrencies();
               	com.wellsfargo.fx.afx.common.persistence.model.Currency currency = null;
            	for (int index = 0; index < currencyList.size(); index++) {
            		currency = currencyList.get(index);
            		addNewCurrency(new Currency(currency.getOrdinal(), currency.getCurrency(), currency.isBaseCcyForUsd()));
            	}
        	}
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Fatal - cannot load currency: " + e);
            System.exit(-1);
        }
    }

    public static void addNewCurrency(Currency currency) {
        nameCurrencyMap.put(currency.getName(), currency);
        ordinalToCurrencyMap.put(currency.ordinal, currency);
        
        if (currency.isBaseCcyForUsd()) {
        	baseCurrenciesForUsd.add(currency.getName());
        }
	}
    
	public static Collection<Currency> values() {
        return nameCurrencyMap.values();
    }

	private final String name;
    private final int ordinal;
    private final boolean baseCcyForUsd;
    
    public Currency(int ordinal, String name, boolean baseCcyForUsd) {
        this.ordinal = ordinal;
        this.name = name;
        this.baseCcyForUsd = baseCcyForUsd;
    }

    public static Currency valueOf(int ordinal) {
        return ordinalToCurrencyMap.get(ordinal);
    }

    public static Currency valueOf(String name) {
        return nameCurrencyMap.get(name);
    }

    public static Currency getByName(String name) {
        return valueOf(name);
    }

    public String getName() {
        return name;
    }
    
    public boolean isBaseCcyForUsd() {
    	return baseCcyForUsd;
    }

    public int ordinal() {
        return ordinal;
    }

    public boolean isUsdBasedCurrencyPair() {
        for (String ccy : baseCurrenciesForUsd) {
            if (name.equals(ccy)) {
                return false;
            }
        }
        return true;
    }

    public CurrencyPair getUsdCurrencyPair() {
        String name = isUsdBasedCurrencyPair() ? "USD/" + toString() : toString() + "/USD";
        return CurrencyPair.valueOf(name);
    }

    public String toString() {
        return name;
    }
}
