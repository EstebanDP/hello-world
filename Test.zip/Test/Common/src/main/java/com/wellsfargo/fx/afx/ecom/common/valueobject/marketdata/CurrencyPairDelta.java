package com.wellsfargo.fx.afx.ecom.common.valueobject.marketdata;

import com.wellsfargo.fx.afx.common.util.Util;
import com.wellsfargo.fx.afx.common.valueobject.CurrencyPair;
import com.wellsfargo.fx.afx.common.valueobject.MessageType;
import com.wellsfargo.fx.afx.common.valueobject.ValueObject;

public final class CurrencyPairDelta extends ValueObject {

    public enum Action {
        NEW, DELETE;

        public static Action valueOf(int ordinal) {
            if (NEW.ordinal() == ordinal) {
                return NEW;
            } else if (DELETE.ordinal() == ordinal) {
                return DELETE;
            }
            return null;
        }

    }

    public enum BookSide {
        BID, OFFER;

        public static BookSide valueOf(int ordinal) {
            if (BID.ordinal() == ordinal) {
                return BID;
            } else if (OFFER.ordinal() == ordinal) {
                return OFFER;
            }
            return null;
        }

    }

    private static byte messageType = MessageType.MARKET_DATA_DELTA;
    private static byte version = 1;
    private CurrencyPair currencyPair;
    private Action action;
    private float price;
    private float quantity;
    private BookSide bookSide;
    private String snapshotTime;
    private long tickReceivedTime;

    public CurrencyPairDelta() {

    }

    public CurrencyPairDelta(CurrencyPair currencyPair, BookSide bookSide, Action action, float price) {
        this.currencyPair = currencyPair;
        this.bookSide = bookSide;
        this.action = action;
        this.price = price;
    }

    public CurrencyPairDelta(CurrencyPair currencyPair, BookSide bookSide, Action action, float price, float quantity) {
        this(currencyPair, bookSide, action, price);
        this.quantity = quantity;
    }

    public CurrencyPair getCurrencyPair() {
        return currencyPair;
    }

    public Action getAction() {
        return action;
    }

    public float getPrice() {
        return price;
    }

    public float getQuantity() {
        return quantity;
    }

    public BookSide getBookSide() {
        return bookSide;
    }
    
    public String getSnapshotTime() {
        return snapshotTime;
    }
    
    public void setAction(Action action) {
    	this.action = action;
    }

    public void setSnapshotTime(String snapshotTime) {
        this.snapshotTime = snapshotTime;
    }

    public long getTickReceivedTime() {
        return tickReceivedTime;
    }

    public void setTickReceivedTime(long tickReceivedTime) {
        this.tickReceivedTime = tickReceivedTime;
    }

    @Override
    public int readFrom(byte[] bytes) {
        return readFrom(bytes, 0);
    }

    public int readFrom(byte[] bytes, int pos) {
        pos += 2;
        currencyPair = CurrencyPair.valueOf(bytes[pos++]);
        action = Action.valueOf(bytes[pos++]);
        price = Util.readFloatFromBytes(bytes, pos);
        pos += 4;
        quantity = Util.readFloatFromBytes(bytes, pos);
        pos += 4;

        bookSide = BookSide.valueOf(bytes[pos++]);

        int length = bytes[pos++];
        snapshotTime = Util.readStringFromBytes(bytes, length, pos);
        pos += length;

        tickReceivedTime = Util.readLongFromBytes(bytes, pos);
        pos += 8;

        return pos;
    }

    @Override
    public byte[] toBytes() {
        byte[] bytes = new byte[getByteLength()];
        int pos = 0;
        writeBytes(bytes, pos);
        return bytes;
    }

    public int writeBytes(byte[] bytes, int pos) {
        bytes[pos++] = messageType;
        bytes[pos++] = version;
        bytes[pos++] = (byte) currencyPair.ordinal();
        bytes[pos++] = (byte) action.ordinal();
        pos = Util.writeFloatToByteArray(price, bytes, pos);
        pos = Util.writeFloatToByteArray(quantity, bytes, pos);
        bytes[pos++] = (byte) bookSide.ordinal();
        pos = Util.writeStringToByteArray(snapshotTime, bytes, pos);
        pos = Util.writeLongToByteArray(tickReceivedTime, bytes, pos);
        return pos;
    }

    public int getByteLength() {
        return 2 + 1 + 1 + 4 + 4 + 1 + snapshotTime.length() + 1 + 8;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        appendToString(sb);
        return sb.toString();
    }

    public void appendToString(StringBuilder sb) {
        sb.append(currencyPair).append('\t');
        sb.append(action).append('\t');
        sb.append(price).append('\t');
        sb.append(bookSide).append('\t');
        sb.append(quantity).append('\t');
        sb.append(snapshotTime).append('\t');
        sb.append(tickReceivedTime).append('\t');
    }

}