package com.wellsfargo.fx.afx.common.valueobject.marketdata;

import com.wellsfargo.fx.afx.common.util.CommonConstants;
import com.wellsfargo.fx.afx.common.valueobject.CurrencyPair;
import com.wellsfargo.fx.afx.common.valueobject.Exchange;
import com.wellsfargo.fx.afx.common.valueobject.marketdata.MarketTick.CurrencyPairDelta;

public class CurrencyPairSnapshot implements Cloneable {
    private CurrencyPair currencyPair;
    private Exchange source;
    private long tickReceivedTime;
    private String snapshotTime;
    private float bid = CommonConstants.CONST_NA;
    private float offer = CommonConstants.CONST_NA;
    private float bidQuantity = CommonConstants.CONST_NA;
    private float offerQuantity = CommonConstants.CONST_NA;
    private float bid2 = CommonConstants.CONST_NA;
    private float offer2 = CommonConstants.CONST_NA;
    private float bidQuantity2 = CommonConstants.CONST_NA;
    private float offerQuantity2 = CommonConstants.CONST_NA;
    private float bid3 = CommonConstants.CONST_NA;
    private float offer3 = CommonConstants.CONST_NA;
    private float bidQuantity3 = CommonConstants.CONST_NA;
    private float offerQuantity3 = CommonConstants.CONST_NA;
    private float paid = CommonConstants.CONST_NA;
    private float given = CommonConstants.CONST_NA;

    public CurrencyPairSnapshot(CurrencyPair currencyPair) {
        this.currencyPair = currencyPair;
    }

    public CurrencyPairSnapshot(String currencyPair) {
        setCurrencyPair(currencyPair);
    }

    public CurrencyPair getCurrencyPair() {
        return currencyPair;
    }

    public void setCurrencyPair(String currencyPair) {
        this.currencyPair = CurrencyPair.valueOf(currencyPair.replace('/', '_'));
    }

    public Exchange getSource() {
        return source;
    }

    public void setSource(Exchange source) {
        this.source = source;
    }

    public long getTickReceivedTime() {
        return tickReceivedTime;
    }

    public void setTickReceivedTime(long tickReceivedTime) {
        this.tickReceivedTime = tickReceivedTime;
    }

    public String getSnapshotTime() {
        return snapshotTime;
    }

    public void setSnapshotTime(String snapshotTime) {
        this.snapshotTime = snapshotTime;
    }

    public float getBid() {
        return bid;
    }

    public void setBid(float bid) {
        this.bid = bid;
    }

    public float getOffer() {
        return offer;
    }

    public void setOffer(float offer) {
        this.offer = offer;
    }

    public float getBidQuantity() {
        return bidQuantity;
    }

    public void setBidQuantity(float bidQuantity) {
        this.bidQuantity = bidQuantity;
    }

    public float getOfferQuantity() {
        return offerQuantity;
    }

    public void setOfferQuantity(float offerQuantity) {
        this.offerQuantity = offerQuantity;
    }

    public float getBid2() {
        return bid2;
    }

    public void setBid2(float bid2) {
        this.bid2 = bid2;
    }

    public float getOffer2() {
        return offer2;
    }

    public void setOffer2(float offer2) {
        this.offer2 = offer2;
    }

    public float getBidQuantity2() {
        return bidQuantity2;
    }

    public void setBidQuantity2(float bidQuantity2) {
        this.bidQuantity2 = bidQuantity2;
    }

    public float getOfferQuantity2() {
        return offerQuantity2;
    }

    public void setOfferQuantity2(float offerQuantity2) {
        this.offerQuantity2 = offerQuantity2;
    }

    public float getBid3() {
        return bid3;
    }

    public void setBid3(float bid3) {
        this.bid3 = bid3;
    }

    public float getOffer3() {
        return offer3;
    }

    public void setOffer3(float offer3) {
        this.offer3 = offer3;
    }

    public float getBidQuantity3() {
        return bidQuantity3;
    }

    public void setBidQuantity3(float bidQuantity3) {
        this.bidQuantity3 = bidQuantity3;
    }

    public float getOfferQuantity3() {
        return offerQuantity3;
    }

    public void setOfferQuantity3(float offerQuantity3) {
        this.offerQuantity3 = offerQuantity3;
    }

    public float getPaid() {
        return paid;
    }

    public void setPaid(float paid) {
        this.paid = paid;
    }

    public float getGiven() {
        return given;
    }

    public void setGiven(float given) {
        this.given = given;
    }

    public void mergeFrom(CurrencyPairDelta update) {
        if (update.hasBid()) {
            setBid(update.getBid());
        }
        if (update.hasOffer()) {
            setOffer(update.getOffer());
        }
        if (update.hasBidQuantity()) {
            setBidQuantity(update.getBidQuantity());
        }
        if (update.hasOfferQuantity()) {
            setOfferQuantity(update.getOfferQuantity());
        }

        if (update.hasBid2()) {
            setBid2(update.getBid2());
        }
        if (update.hasOffer2()) {
            setOffer2(update.getOffer2());
        }
        if (update.hasBidQuantity2()) {
            setBidQuantity2(update.getBidQuantity2());
        }
        if (update.hasOfferQuantity2()) {
            setOfferQuantity2(update.getOfferQuantity2());
        }

        if (update.hasBid3()) {
            setBid3(update.getBid3());
        }
        if (update.hasOffer3()) {
            setOffer3(update.getOffer3());
        }
        if (update.hasBidQuantity3()) {
            setBidQuantity3(update.getBidQuantity3());
        }
        if (update.hasOfferQuantity3()) {
            setOfferQuantity3(update.getOfferQuantity3());
        }
        if (update.hasPaid()) {
            setPaid(update.getPaid());
        }
        if (update.hasGiven()) {
            setGiven(update.getGiven());
        }

    }

    public void appendToString(StringBuilder sb) {
        sb.append("\t").append(currencyPair);
        sb.append("\t\t");

        sb.append(getBid());
        sb.append("\t");

        sb.append(getOffer());
        sb.append("\t");

        sb.append(getBidQuantity());
        sb.append("\t");

        sb.append(getOfferQuantity());

        sb.append("\n");
    }

    public Object clone() {
        try {
            return super.clone();
        } catch (CloneNotSupportedException e) {
            throw new RuntimeException("Unexpected state. Clone should be available but got CloneNotSupportedException", e);
        }
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(currencyPair);

        sb.append("\t\t");
        sb.append(getBid());
        sb.append("\t");

        sb.append(getOffer());
        sb.append("\t");

        sb.append(getBidQuantity());
        sb.append("\t");

        sb.append(getOfferQuantity());
        sb.append("\n");

        sb.append("\t\t");
        sb.append(getBid2());
        sb.append("\t");

        sb.append(getOffer2());
        sb.append("\t");

        sb.append(getBidQuantity2());
        sb.append("\t");

        sb.append(getOfferQuantity2());
        sb.append("\n");

        sb.append("\t\t");
        sb.append(getBid3());
        sb.append("\t");

        sb.append(getOffer3());
        sb.append("\t");

        sb.append(getBidQuantity3());
        sb.append("\t");

        sb.append(getOfferQuantity3());
        sb.append("\n");

        return sb.toString();
    }
}
