#!/bin/bash

ps -ef | grep lbmrd | awk '{print $2}' | xargs kill -9
