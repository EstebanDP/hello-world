#!/bin/bash

function countdown
{
        local OLD_IFS="${IFS}"
        IFS=":"
        local ARR=( $1 )
        local SECONDS=$((  (ARR[0] * 60 * 60) + (ARR[1] * 60) + ARR[2]  ))
        local START=$(date +%s)
        local END=$((START + SECONDS))
        local CUR=$START

        while [[ $CUR -lt $END ]]
        do
                CUR=$(date +%s)
                LEFT=$((END-CUR))

                printf "\r%02d:%02d:%02d" \
                        $((LEFT/3600)) $(( (LEFT/60)%60)) $((LEFT%60))

                sleep 1
        done
        IFS="${OLD_IFS}"
        echo "        "
}



echo "Setting local variables for JVM arguments and environment"
if [ "`hostname`" == "wppra99a0440" ]; then
	export ENV="PROD"
else
	export ENV="PROD_HA"
fi
export JAVA_ARGUMENTS="-client -Xcomp -Xms512m -Xmx512m"
export DB_ARGUMENTS="-DafxDatabaseName=AFXECOM -DafxDriver=com.microsoft.sqlserver.jdbc.SQLServerDriver -DafxURL=jdbc:sqlserver://WPPWD01V0213.wellsfargo.com:11000 -DafxUserName=AFX_RW -DafxPassword=WbVHQpftBmAAOnNTeJ35iexIFGfttFXa"
export LD_LIBRARY_PATH=/apps/afxecom/29West/UMP_5.2/Linux-glibc-2.5-x86_64/lib
export LBM_LICENSE_FILENAME=/apps/afxecom/29West/ume_license.txt

echo "AFX will start with the following settings:"
echo "JVM arguments: "$JAVA_ARGUMENTS
echo "DB arguments: "$DB_ARGUMENTS
echo "Environment: "$ENV

#read -p "Press ENTER to start Client Proxy"
ClientProxy/startClientProxy.sh $ENV $JAVA_ARGUMENTS $DB_ARGUMENTS

echo "  "
echo "Time left for Client Proxy to finish initializing (Do NOT press any key)"
countdown "00:01:10"
echo "  "

#read -p "Press ENTER to start Server Proxy"
ServerProxy/startServerProxy.sh $ENV $JAVA_ARGUMENTS $DB_ARGUMENTS

echo "  "
echo "Time left for Server Proxy to finish initializing (Do NOT press any key)"
countdown "00:00:20"
echo "  "

#read -p "Press ENTER to start MDG, ORG, and PM"
IntegralMarketDataGateway/startIntegralMarketDataGateway.sh $ENV $JAVA_ARGUMENTS $DB_ARGUMENTS

PositionManagerEcom/startPositionManagerEcom.sh $ENV $JAVA_ARGUMENTS $DB_ARGUMENTS

IntegralOrderRoutingGateway/startIntegralOrderRoutingGateway.sh $ENV $JAVA_ARGUMENTS $DB_ARGUMENTS
