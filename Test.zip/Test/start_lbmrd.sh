#!/bin/bash

base_dir="/apps/afxecom"

export LD_LIBRARY_PATH=$base_dir/29West/UMP_5.2/Linux-glibc-2.5-x86_64/lib
export LBM_LICENSE_FILENAME=$base_dir/29West/ume_license.txt

$base_dir/29West/UMP_5.2/Linux-glibc-2.5-x86_64/bin/lbmrd &
