#!/bin/bash

cd IntegralMarketDataGateway
args=("$@")
log_level="-Dlogging.level=debug"
optional_jvm_args="-DENV=${args[0]} -Dcomponent.name=INTEGRAL_MARKET_DATA_GATEWAY -DverifyNumberOfVariablesToLoad=29"
java_path="/apps/afxecom/java/jdk1.6.0_20/jre/bin"

today=$(date +"%Y%m%d_%H%M%S")
stdoutPath="./Logs/"

if [ ! -d $stdoutPath ]
then
	mkdir $stdoutPath
fi

echo "Copying "${args[0]}" property files..."
cp environment/${args[0]}/* environment/.

echo "Starting Integral Market Data Gateway..."

$java_path/java ${args[1]} ${args[2]} ${args[3]} ${args[4]} ${args[5]} ${args[6]} ${args[7]} ${args[8]} ${args[9]} $optional_jvm_args $log_level -jar IntegralMarketDataGateway.jar >& $stdoutPath/integralmdg_stdout_$today.txt &
