package com.wellsfargo.fx.afx.marketdata.integral.util;

import java.io.PrintStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import quickfix.Log;
import quickfix.SessionID;

import com.wellsfargo.fx.afx.common.util.LoggerConstants;

public class AFXLog implements Log {
    private static final Logger logger = LoggerFactory.getLogger(LoggerConstants.QUICKFIXj);

    // private static final String EVENT_CATEGORY = "event";
    // private static final String OUTGOING_CATEGORY = "outgoing";
    // private static final String INCOMING_CATEGORY = "incoming";
    // private PrintStream out;
    // private final SessionID sessionID;
    private final boolean incoming;
    private final boolean outgoing;
    private final boolean events;
    // private final boolean includeMillis;
    private boolean logHeartbeats;

    AFXLog(boolean incoming, boolean outgoing, boolean events, boolean logHeartbeats, boolean includeMillis, SessionID sessionID, PrintStream out) {
        this.incoming = incoming;
        this.outgoing = outgoing;
        this.events = events;
        this.logHeartbeats = logHeartbeats;
    }

    @Override
    public void clear() {

    }

    @Override
    public void onEvent(String message) {
        if (events) {
            logger.info(" - " + message.toString());
        }
    }

    @Override
    public void onIncoming(String message) {
        if (incoming) {
            if (logHeartbeats) {
                logger.info("<- " + message);
            } else if (!message.contains("35=0")) {
                logger.info("<- " + message);
            }
        }
    }

    @Override
    public void onOutgoing(String message) {
        if (outgoing) {
            if (logHeartbeats) {
                logger.info("-> " + message);
            } else if (!message.contains("35=0")) {
                logger.info("-> " + message);
            }
        }
    }

    @Override
    public void onErrorEvent(String message) {
        logger.info("<- " + message);
    }
}
