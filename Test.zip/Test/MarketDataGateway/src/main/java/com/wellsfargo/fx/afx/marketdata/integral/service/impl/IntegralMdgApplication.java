package com.wellsfargo.fx.afx.marketdata.integral.service.impl;

import java.text.DateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.TimeZone;
import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.atomic.AtomicInteger;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import quickfix.Application;
import quickfix.DoNotSend;
import quickfix.FieldNotFound;
import quickfix.Group;
import quickfix.IncorrectDataFormat;
import quickfix.IncorrectTagValue;
import quickfix.Message;
import quickfix.RejectLogon;
import quickfix.SessionID;
import quickfix.UnsupportedMessageType;
import quickfix.field.MsgType;
import quickfix.fix43.MarketDataIncrementalRefresh;
import quickfix.fix43.MessageCracker;

import com.wellsfargo.fx.afx.common.messaging.MessageSender;
import com.wellsfargo.fx.afx.common.messaging.impl.MessagingManagerFactory;
import com.wellsfargo.fx.afx.common.util.LoggerConstants;
import com.wellsfargo.fx.afx.common.valueobject.CurrencyPair;
import com.wellsfargo.fx.afx.common.valueobject.Exchange;
import com.wellsfargo.fx.afx.common.valueobject.JVMStatusEnum;
import com.wellsfargo.fx.afx.ecom.common.valueobject.marketdata.CurrencyPairDelta;
import com.wellsfargo.fx.afx.ecom.common.valueobject.marketdata.CurrencyPairDelta.Action;
import com.wellsfargo.fx.afx.ecom.common.valueobject.marketdata.CurrencyPairDelta.BookSide;
import com.wellsfargo.fx.afx.ecom.common.valueobject.marketdata.EcomMarketTick;
import com.wellsfargo.fx.afx.marketdata.integral.manager.ConnectionManager;
import com.wellsfargo.fx.afx.marketdata.integral.util.IntegralMarketDataGatewayConstants;
import com.wellsfargo.fx.afx.marketdata.integral.valueobject.Account;

public class IntegralMdgApplication implements Application {

    private static final Logger log = LoggerFactory.getLogger(LoggerConstants.MARKET_DATA_GATEWAY);
    private static final DateFormat timeFormatter = DateFormat.getTimeInstance(DateFormat.FULL);
    static {
        timeFormatter.setTimeZone(TimeZone.getTimeZone("GMT:00"));
    }

    private MessageSender deltaSender = MessagingManagerFactory.getMessagingManager().getSenderForTopic(IntegralMarketDataGatewayConstants.VALUE_INTEGRAL_MARKET_DATA_TOPIC);
    private MessageCracker consumer;
    private ConnectionManager connectionManager;
    private CyclicBarrier marketDataRequestBarrier;
    private AtomicInteger fixLoginCounter = new AtomicInteger(0);

    private Map<String, CurrencyPairDelta> marketIdMap = new HashMap<String, CurrencyPairDelta>(); //<marketID,delta>

    public IntegralMdgApplication() {
        consumer = new MessageConsumer();
    }

    @Override
    public void fromAdmin(Message message, SessionID sessionId) throws FieldNotFound, IncorrectDataFormat, IncorrectTagValue, RejectLogon {
        String messageType = message.getHeader().getString(MsgType.FIELD);
        if (messageType.equals(MsgType.REJECT)) {
            shutDownApp(message, new RuntimeException("Reject message received from Integral"));
        } else if (messageType.equals(MsgType.LOGOUT)) {
            if (message.isSetField(58) && message.getString(58).contains("authentication failure")) {
                shutDownApp(message, new RuntimeException("Authentication Error - Please verify account id and password"));
            }
        }
    }

    @Override
    public void fromApp(Message message, SessionID sessionId) throws FieldNotFound, IncorrectDataFormat, IncorrectTagValue, UnsupportedMessageType {
        try {
            consumer.crack43((quickfix.fix43.Message) message, sessionId);
        } catch (Exception e) {
        	log.info("Error while processing the message - " + e.getMessage());
            shutDownApp(message, e);
        }
    }

    @Override
    public void onCreate(SessionID sessionId) {
        log.info("FIX Session created: " + sessionId.toString());
    }

    @Override
    public void onLogon(SessionID sessionId) {
        log.info("Session " + sessionId.getSenderCompID() + " successfully logged in.");
        
        fixLoginCounter.incrementAndGet();
        Account account = Account.getAccount(sessionId.getSessionQualifier());
        account.loggedin();
        
        if (fixLoginCounter.get() == connectionManager.getAccounts().size()) {
            //fixLoginCounter.set(0);
            try {
				marketDataRequestBarrier.await();
			} catch (InterruptedException e) {
				log.debug(e.getMessage());
			} catch (BrokenBarrierException e) {
				log.debug(e.getMessage());
			}
        }
    }

    @Override
    public void onLogout(SessionID sessionId) {
        IntegralMarketDataServiceFactory.getIntegralMarketDataService().changeStatus(JVMStatusEnum.UP, "Logout requested from Integral", true, false);
        Account.getAccount(sessionId.getSessionQualifier()).loggedOut();
        fixLoginCounter.set(0);
        EcomMarketTick marketTick = new EcomMarketTick();
        marketTick.setExchange(Exchange.INTEGRAL);
        marketTick.setSnapShotTime(timeFormatter.format(new Date()));
        marketTick.setClearRates(true);
        deltaSender.send(marketTick.toBytes());
    }

    @Override
    public void toAdmin(Message message, SessionID sessionId) {
        try {
            if (message.getHeader().getChar(35) == 'A') {
                Account account = Account.getAccount(sessionId.getSessionQualifier());
                message.setString(553, account.getName());
                message.setString(554, account.getPassword());
            }
        } catch (FieldNotFound e) {
            e.printStackTrace();
        }
    }

    @Override
    public void toApp(Message message, SessionID sessionId) throws DoNotSend {
    }

    public void setConnectionManager(ConnectionManager connectionManager) {
        this.connectionManager = connectionManager;
    }

    class MessageConsumer extends MessageCracker {

        public void crack43(quickfix.fix43.Message message, SessionID sessionID) throws UnsupportedMessageType, FieldNotFound, IncorrectTagValue {
            MsgType msgType = new MsgType();
            message.getHeader().getField(msgType);

            String msgTypeValue = msgType.getValue();

            if (msgTypeValue.equals(MarketDataIncrementalRefresh.MSGTYPE)) {
                onMessage((MarketDataIncrementalRefresh) message, sessionID);
            } else {
                shutDownApp(message, new RuntimeException("Unexpected message received"));
            }
        }

        public void onMessage(MarketDataIncrementalRefresh message, SessionID sessionId) {
            try {
                EcomMarketTick marketTick = new EcomMarketTick();
                marketTick.setExchange(Exchange.INTEGRAL);
                marketTick.setSnapShotTime(message.getHeader().getString(52));
                CurrencyPairDelta delta = null;
                
                for (Group group : message.getGroups(268)) {
                	String marketId = group.getString(278);
                	
                	if (group.getInt(279) == 2) { //delete
                		delta = marketIdMap.remove(marketId); 
                		delta.setAction(CurrencyPairDelta.Action.DELETE);
                	} else {
                		float price = Double.valueOf(group.getDouble(270)).floatValue();
                        float quantity = Double.valueOf(group.getDouble(271)).floatValue();
                        CurrencyPair cp = CurrencyPair.getByName(group.getString(55));
                        boolean bid = group.getInt(269) == 0;
                        
                        delta = new CurrencyPairDelta(cp, bid ? BookSide.BID : BookSide.OFFER, Action.NEW, price, quantity);
                        marketIdMap.put(marketId, delta);
                	}
                	delta.setSnapshotTime(message.getHeader().getString(52));
                    delta.setTickReceivedTime(System.nanoTime());
                    marketTick.addCurrencyDelta(delta);
                }
                deltaSender.send(marketTick.toBytes());
            } catch (RuntimeException e) {
                e.printStackTrace();
                log.info(e.getMessage());
                log.info(message.toString());
                throw e;
            } catch (FieldNotFound e) {
                e.printStackTrace();
                log.info(e.getMessage());
                log.info(message.toString());
                throw new RuntimeException("Unable to handle message: " + message.toString());
            }
        }

    }
    
    public void setMarketDataRequestBarrier(CyclicBarrier marketDataRequestBarrier) {
        this.marketDataRequestBarrier = marketDataRequestBarrier;
    }

    private void shutDownApp(Message message, Exception exception) {
        log.info("Error detected with message: " + message.toString());
    }
}
