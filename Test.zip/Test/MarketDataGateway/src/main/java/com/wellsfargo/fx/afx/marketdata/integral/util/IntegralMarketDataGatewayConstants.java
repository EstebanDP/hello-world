package com.wellsfargo.fx.afx.marketdata.integral.util;


public interface IntegralMarketDataGatewayConstants {

	public static final String VALUE_INTEGRAL_MARKET_DATA_TOPIC = "INTEGRAL.MDG";
	
    public static final boolean VALUE_INCOMING_MSGS_LOG = true;
    
    public static final boolean VALUE_OUTGOING_MSGS_LOG = true;
    
    public static final boolean VALUE_EVENT_LOG = true;
    
    public static final boolean VALUE_HEARTBEAT_LOG = true;
    
	public static final boolean VALUE_LOG_ACCOUNT_SETTINGS = true;

    public static final int VALUE_TIME_TO_WAIT_BEFORE_START = 2000;

    public static final boolean VALUE_START_WITHOUT_SERVER_PROXY = true;
    
    public static final String VALUE_LOGON_USERNAME = "Trader13";
    
    public static final String VALUE_LOGON_PASSWORD = "P7xBFrf4H+JK2s8wuKWMgp83xxa2H41z";
    
    public static final int VALUE_MARKET_DEPTH = 0;
    
    public static final boolean VALUE_AGGREGATED_BOOK = true;
    
    public static final String VALUE_DELIVER_TO_COMP_ID = "ALL";
   
}
