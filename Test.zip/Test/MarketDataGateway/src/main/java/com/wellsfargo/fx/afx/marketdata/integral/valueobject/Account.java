package com.wellsfargo.fx.afx.marketdata.integral.valueobject;

import java.util.ArrayList;
import java.util.List;

import javolution.util.FastList;

import com.wellsfargo.fx.afx.common.util.CommonConstants;

public final class Account {
    private static List<Account> accounts = new FastList<Account>();

    private String name;
    private String password;
    private List<String> subscribedCurrencyPairs = new ArrayList<String>();

    private enum Status {
        LOGGED_IN, LOGGED_OUT;
    };

    private Status status = Status.LOGGED_OUT;

    public static Account getAccount(String accountName) {
        for (Account account : accounts) {
            if (account.getName().equals(accountName)) {
                return account;
            }
        }
        return null;

    }

    public Account() {
        accounts.add(this);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public List<String> getSubscribedCurrencyPairs() {
        return subscribedCurrencyPairs;
    }

    public void addSubscribedCurrencyPairs(String subscribedCurrencyPair) {
        subscribedCurrencyPairs.add(subscribedCurrencyPair);
    }

    public void loggedin() {
    	status = Status.LOGGED_IN;
    }

    public void loggedOut() {
    	status = Status.LOGGED_OUT;
    }

    public String getAccountSettings() {
        String currentSettings = CommonConstants.CONST_SEPARATOR + " " + getName() + " Current Settings " + CommonConstants.CONST_SEPARATOR;
        currentSettings += "\n Status: " + status;
        currentSettings += "\nSubscribedCurrencyPairs: " + getSubscribedCurrencyPairs();
        return currentSettings;
    }

}
