package com.wellsfargo.fx.afx.marketdata.integral.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import quickfix.field.AggregatedBook;
import quickfix.field.MDEntryType;
import quickfix.field.MDReqID;
import quickfix.field.MDUpdateType;
import quickfix.field.MarketDepth;
import quickfix.field.Product;
import quickfix.field.SecurityType;
import quickfix.field.SubscriptionRequestType;
import quickfix.field.Symbol;
import quickfix.fix43.MarketDataRequest;

import com.wellsfargo.fx.afx.common.valueobject.CurrencyPair;


public class FixMessageUtil {

    private static FixMessageUtil self;

    static {
        self = new FixMessageUtil();
    }

    public static FixMessageUtil getInstance() {
        return self;
    }

    public List<MarketDataRequest> createMarketDataRequest43(Collection<CurrencyPair> currencyPairs) {
        List<MarketDataRequest> requests = new ArrayList<MarketDataRequest>();
        for (CurrencyPair ccyPair : currencyPairs) {
            quickfix.fix43.MarketDataRequest request = new quickfix.fix43.MarketDataRequest();
            request.set(new MDReqID(ccyPair.toString())); // field 262
            request.set(new SubscriptionRequestType('1')); // field 263
            request.set(new MarketDepth(IntegralMarketDataGatewayConstants.VALUE_MARKET_DEPTH)); // field 264
            request.set(new MDUpdateType(MDUpdateType.INCREMENTAL_REFRESH)); // field 265
            request.setString(128, IntegralMarketDataGatewayConstants.VALUE_DELIVER_TO_COMP_ID); //field 128
            request.set(new AggregatedBook(IntegralMarketDataGatewayConstants.VALUE_AGGREGATED_BOOK)); // field 266
            MarketDataRequest.NoMDEntryTypes noMDEntryTypes0 = new MarketDataRequest.NoMDEntryTypes();
            noMDEntryTypes0.set(new MDEntryType('0')); // field 269
            MarketDataRequest.NoMDEntryTypes noMDEntryTypes1 = new MarketDataRequest.NoMDEntryTypes();
            noMDEntryTypes1.set(new MDEntryType('1')); // field 269
            request.addGroup(noMDEntryTypes0); // field 267
            request.addGroup(noMDEntryTypes1); // field 267

            MarketDataRequest.NoRelatedSym noRelatedSym = new MarketDataRequest.NoRelatedSym();
            noRelatedSym.set(new Symbol(ccyPair.toString())); // field 55
            noRelatedSym.setInt(460, Product.CURRENCY); //field 460
            noRelatedSym.setString(167, SecurityType.FOREIGN_EXCHANGE_CONTRACT); //field 167
            request.addGroup(noRelatedSym); // field 146
            
            requests.add(request);
        }
        return requests;
    }

}
