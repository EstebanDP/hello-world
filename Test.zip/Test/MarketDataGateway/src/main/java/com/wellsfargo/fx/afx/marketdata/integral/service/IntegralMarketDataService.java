package com.wellsfargo.fx.afx.marketdata.integral.service;

import com.wellsfargo.fx.afx.common.component.BaseComponentService;

public interface IntegralMarketDataService extends BaseComponentService {

}
