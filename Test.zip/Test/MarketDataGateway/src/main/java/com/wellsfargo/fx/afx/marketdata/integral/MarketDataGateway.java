package com.wellsfargo.fx.afx.marketdata.integral;

import com.wellsfargo.fx.afx.common.util.AFXThread;
import com.wellsfargo.fx.afx.marketdata.integral.service.IntegralMarketDataService;
import com.wellsfargo.fx.afx.marketdata.integral.service.impl.IntegralMarketDataServiceFactory;

public class MarketDataGateway {

    public static void main(String[] args) {
    	Thread.currentThread().setUncaughtExceptionHandler(new AFXThread.AFXUncaughtExceptionHandler());
        IntegralMarketDataService mds = IntegralMarketDataServiceFactory.getIntegralMarketDataService();
        mds.start(null);
    }

}
