package com.wellsfargo.fx.afx.marketdata.integral.service.impl;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CyclicBarrier;

import javolution.context.LogContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import quickfix.Session;
import quickfix.fix43.MarketDataRequest;

import com.wellsfargo.fx.afx.common.component.AbstractComponentService;
import com.wellsfargo.fx.afx.common.util.AFXThread;
import com.wellsfargo.fx.afx.common.util.LoggerConstants;
import com.wellsfargo.fx.afx.common.valueobject.CurrencyPair;
import com.wellsfargo.fx.afx.common.valueobject.JVMStatusEnum;
import com.wellsfargo.fx.afx.ecom.common.sp.ServerProxyCommunicationManager;
import com.wellsfargo.fx.afx.ecom.common.sp.ServerProxyCommunicationManagerFactory;
import com.wellsfargo.fx.afx.marketdata.integral.manager.ConnectionManager;
import com.wellsfargo.fx.afx.marketdata.integral.manager.impl.ConnectionManagerFactory;
import com.wellsfargo.fx.afx.marketdata.integral.service.IntegralMarketDataService;
import com.wellsfargo.fx.afx.marketdata.integral.util.FixMessageUtil;
import com.wellsfargo.fx.afx.marketdata.integral.util.IntegralMarketDataGatewayConstants;
import com.wellsfargo.fx.afx.marketdata.integral.valueobject.Account;

public class IntegralMarketDataServiceImpl extends AbstractComponentService implements IntegralMarketDataService {

    private static final Logger log = LoggerFactory.getLogger(LoggerConstants.MARKET_DATA_GATEWAY);

    private final ConnectionManager connectionManager;

    private CyclicBarrier marketDataRequestBarrier;
    private ServerProxyCommunicationManager spcm;

    public IntegralMarketDataServiceImpl() {
        LogContext.enter(LogContext.NULL);
        connectionManager = ConnectionManagerFactory.getConnectionManager();
    }

    @Override
    protected boolean doStart() {
        spcm = ServerProxyCommunicationManagerFactory.getServerProxyCommunicationManager();
        spcm.start();
        if (IntegralMarketDataGatewayConstants.VALUE_START_WITHOUT_SERVER_PROXY) {
            init(null);
        }
        return true;
    }

    @Override
    protected boolean doStop() {
        for (Iterator<String> i = connectionManager.getAccounts().keySet().iterator(); i.hasNext();) {
            Account account = connectionManager.getAccounts().get(i.next());
            log.info("Requesting DISCONNECT for account: " + account.getName());
            connectionManager.disconnect(account);
        }
        return true;
    }

    @Override
    protected boolean doInit() {
        // init connections
        marketDataRequestBarrier = new CyclicBarrier(1, new AFXThread(new MarketDataRequestRunnable()));
        connectionManager.setMarketDataRequestBarrier(marketDataRequestBarrier);
        connectionManager.start(); // establish session-level connection
        return false;
    }

    @Override
    protected boolean doPostWarmUp() {
        // do nothing
        return true;
    }

    @Override
    protected boolean doGo() {
        return false;
    }

    @Override
    protected void doWarmUp() {
        // do nothing
    }

    class MarketDataRequestRunnable implements Runnable {

        @Override
        public void run() {
            changeStatus(JVMStatusEnum.STANDBY, "Subscribing to Currencies", false, false);
            log.info("Going to wait " + IntegralMarketDataGatewayConstants.VALUE_TIME_TO_WAIT_BEFORE_START + " ms before starting the Market Feeds...");

			try {
			    AFXThread.sleep(IntegralMarketDataGatewayConstants.VALUE_TIME_TO_WAIT_BEFORE_START);
			} catch (InterruptedException exception) {
			    log.info(exception.getMessage());
			}

			log.info("Subscribing to currency pairs...");
            
            // Initiate subscriptions all the required currency pairs
            for (Iterator<String> i = connectionManager.getAccounts().keySet().iterator(); i.hasNext();) {
                Account account = connectionManager.getAccounts().get(i.next());
                Session session = connectionManager.getSession(account.getName());
                Collection<CurrencyPair> ccyPairs = CurrencyPair.getEnabledCurrencyPairs();
                List<MarketDataRequest> requests = FixMessageUtil.getInstance().createMarketDataRequest43(ccyPairs);
                for (MarketDataRequest request : requests) {
                    connectionManager.sendMessage(session, request);
                }
                log.info("Requesting rates for ");
                for (CurrencyPair ccyPair : ccyPairs) {
                    account.addSubscribedCurrencyPairs(ccyPair.toString());
                    log.debug(ccyPair.toString());
                }
            }

            if (IntegralMarketDataGatewayConstants.VALUE_LOG_ACCOUNT_SETTINGS) {
                for (Iterator<String> i = connectionManager.getAccounts().keySet().iterator(); i.hasNext();) {
                    log.info(connectionManager.getAccounts().get(i.next()).getAccountSettings());
                }
            }

            marketDataRequestBarrier.reset();
            changeStatus(JVMStatusEnum.RUNNING, "Integral MDG Ready to Serve", false, false);
            log.info("Ready to Serve");
        }
    }

}
