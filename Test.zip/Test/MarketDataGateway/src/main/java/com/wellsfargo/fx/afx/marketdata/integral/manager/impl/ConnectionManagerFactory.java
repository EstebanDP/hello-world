package com.wellsfargo.fx.afx.marketdata.integral.manager.impl;

import com.wellsfargo.fx.afx.marketdata.integral.manager.ConnectionManager;

public class ConnectionManagerFactory {

    private static volatile ConnectionManager instance;

    public static ConnectionManager getConnectionManager() {
        if (instance == null) {
            synchronized (ConnectionManagerFactory.class) {
                if (instance == null) {
                    instance = new ConnectionManagerIntegral();
                }
            }
        }
        return instance;
    }

}
