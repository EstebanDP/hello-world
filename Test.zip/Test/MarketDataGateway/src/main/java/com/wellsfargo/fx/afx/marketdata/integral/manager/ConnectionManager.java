package com.wellsfargo.fx.afx.marketdata.integral.manager;

import java.util.Map;
import java.util.concurrent.CyclicBarrier;

import quickfix.Message;
import quickfix.Session;

import com.wellsfargo.fx.afx.marketdata.integral.valueobject.Account;

public interface ConnectionManager {

    public void start();

    public void stop();

    public void sendMessage(Session sessionId, Message message);

    public void sendMessage(Account account, Message message);

    public boolean isRunning();

    public Map<String, Account> getAccounts();

    public Account getAccount(String accountName);

    public void setMarketDataRequestBarrier(CyclicBarrier marketDataRequestBarrier);

    public Session getSession(String sessionQualifier);

    public void disconnect(Account account);

}
