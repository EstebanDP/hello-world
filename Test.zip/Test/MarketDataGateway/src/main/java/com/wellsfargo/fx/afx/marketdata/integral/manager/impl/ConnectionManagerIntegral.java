package com.wellsfargo.fx.afx.marketdata.integral.manager.impl;

import java.io.InputStream;
import java.util.Map;
import java.util.concurrent.CyclicBarrier;

import javolution.util.FastMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import quickfix.ConfigError;
import quickfix.Connector;
import quickfix.DefaultMessageFactory;
import quickfix.LogFactory;
import quickfix.MemoryStoreFactory;
import quickfix.Message;
import quickfix.MessageFactory;
import quickfix.MessageStoreFactory;
import quickfix.RuntimeError;
import quickfix.Session;
import quickfix.SessionID;
import quickfix.SessionSettings;
import quickfix.SocketInitiator;

import com.wellsfargo.fx.afx.common.util.EncryptionUtil;
import com.wellsfargo.fx.afx.common.util.LoggerConstants;
import com.wellsfargo.fx.afx.marketdata.integral.manager.ConnectionManager;
import com.wellsfargo.fx.afx.marketdata.integral.service.impl.IntegralMdgApplication;
import com.wellsfargo.fx.afx.marketdata.integral.util.AFXLogFactory;
import com.wellsfargo.fx.afx.marketdata.integral.util.IntegralMarketDataGatewayConstants;
import com.wellsfargo.fx.afx.marketdata.integral.valueobject.Account;

public class ConnectionManagerIntegral implements ConnectionManager {
    private static Logger logger = LoggerFactory.getLogger(LoggerConstants.MARKET_DATA_GATEWAY);
    private Connector connector;
    private IntegralMdgApplication application;
    private Map<String, Account> aiAccounts;

    ConnectionManagerIntegral() {
        initConnectionSettings();
        initAccounts();
    }

    @Override
    public void start() {
        try {
            connector.start();
        } catch (ConfigError e) {
            throw new RuntimeException(e.getMessage(), e.getCause());
        } catch (RuntimeError e) {
            throw new RuntimeException(e.getMessage(), e.getCause());
        }
        logger.debug("QuickfixJ Initiator Started");
    }

    @Override
    public void stop() {
        connector.stop();
        logger.debug("QuickfixJ Initiator Stopped");
    }

    @Override
    public void sendMessage(Session session, Message message) {
        if (session.isLoggedOn()) {
            session.send(message);
        } else {
            throw new RuntimeException("Trying to send message while session not logged in: " + message);
        }
    }

    @Override
    public void sendMessage(Account account, Message message) {
        sendMessage(getSession(account.getName()), message);
    }

    @Override
    public synchronized void disconnect(Account account) {
        getSession(account.getName()).logout();
    }

    @Override
    public boolean isRunning() {
        return connector.isLoggedOn();
    }

    @Override
    public Map<String, Account> getAccounts() {
        return aiAccounts;
    }

    @Override
    public Account getAccount(String accountName) {
        return aiAccounts.get(accountName);
    }

    @Override
    public void setMarketDataRequestBarrier(CyclicBarrier marketDataRequestBarrier) {
        application.setMarketDataRequestBarrier(marketDataRequestBarrier);
    }

    private void initConnectionSettings() {
        SessionSettings sessionSettings = null;
        try {
            InputStream inputStream = ClassLoader.getSystemResourceAsStream("ai.cfg");
            if (inputStream == null) {
                throw new RuntimeException("Couldn't find the configuration file for Ai");
            }
            sessionSettings = new SessionSettings(inputStream);
            inputStream.close();
        } catch (Exception e) {
            logger.info("Error setting up Integral Ai session using configuration file");
            throw new RuntimeException(e.getMessage(), e);
        }

        MessageStoreFactory messageStoreFactory = new MemoryStoreFactory();
        MessageFactory messageFactory = new DefaultMessageFactory();

        LogFactory screenLogFactory = new AFXLogFactory(IntegralMarketDataGatewayConstants.VALUE_INCOMING_MSGS_LOG, IntegralMarketDataGatewayConstants.VALUE_OUTGOING_MSGS_LOG,
        		IntegralMarketDataGatewayConstants.VALUE_EVENT_LOG, IntegralMarketDataGatewayConstants.VALUE_HEARTBEAT_LOG);
        
        application = new IntegralMdgApplication();
        application.setConnectionManager(this);

        try {
            connector = new SocketInitiator(application, messageStoreFactory, sessionSettings, screenLogFactory, messageFactory);
        } catch (ConfigError e) {
            logger.info("Error initiating Integral AI session.");
            throw new RuntimeException(e.getMessage(), e);
        }
    }

    private void initAccounts() {
        aiAccounts = new FastMap<String, Account>(); 
        String userName = IntegralMarketDataGatewayConstants.VALUE_LOGON_USERNAME;
        String password = IntegralMarketDataGatewayConstants.VALUE_LOGON_PASSWORD;
        
        Account account = new Account();
        account.setName(userName);
        account.setPassword(EncryptionUtil.getInstance().decrypt(password));
        aiAccounts.put(userName, account);
    }

    @Override
    public Session getSession(String sessionQualifier) {
        for (SessionID sessionId : connector.getSessions()) {
            if (sessionId.getSessionQualifier().equals(sessionQualifier)) {
                return Session.lookupSession(sessionId);
            }
        }
        return null;
    }

}