package com.wellsfargo.fx.afx.marketdata.integral.service.impl;

import com.wellsfargo.fx.afx.marketdata.integral.service.IntegralMarketDataService;

public class IntegralMarketDataServiceFactory {

    private static volatile IntegralMarketDataService instance;

    public static IntegralMarketDataService getIntegralMarketDataService() {
        if (instance == null) {
            synchronized (IntegralMarketDataServiceFactory.class) {
                if (instance == null) {
                    instance = new IntegralMarketDataServiceImpl();
                }
            }
        }
        return instance;
    }

}
